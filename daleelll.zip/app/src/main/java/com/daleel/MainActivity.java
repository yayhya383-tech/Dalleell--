package com.company.daleel;

import android.Manifest;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.pdf.PdfRenderer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.speech.RecognizerIntent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.widget.ImageButton;
import android.graphics.drawable.ColorDrawable;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.BufferedInputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.InflaterInputStream;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends android.app.Activity {

    private static final String STORAGE_FILE = "daleel_notes_storage_v40.dat";
    private static final String PUBLIC_STORE_FILE = "daleel_public_store_v40.dat";
    private static final String READ_PREFS = "DaleelReadStats";
    private static final String PDF_INDEX_FILE = "daleel_pdf_text_index.dat";
    private final HashMap<String, String> pdfTextIndex = new HashMap<String, String>();
    private final ExecutorService pdfIndexExecutor = Executors.newSingleThreadExecutor();
    private NoteItem activeReadingItem = null;
    private long readingSessionStartedAt = 0L;
    private int secretTapCount = 0;
    private long lastSecretTapAt = 0L;
    private int adminTapCount = 0;
    private long lastAdminTapAt = 0L;
    private volatile boolean activityAlive = false;
    private final ExecutorService newsExecutor = Executors.newSingleThreadExecutor();
    private final ArrayList<NewsItem> cachedNews = new ArrayList<NewsItem>();
    private String activeLocalChatKey = "";
    private static final String CHANNEL_ID = "DaleelNotificationChannel";
    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final int PICK_PDF_DOCUMENT_REQUEST = 101;
    private static final int PICK_COVER_IMAGE_REQUEST = 102;
    private static final int PICK_PROFILE_IMAGE_REQUEST = 103;
    private static final int PICK_NOTE_IMAGE_REQUEST = 104;
    private static final int VOICE_RECOGNITION_REQUEST_CODE = 105;
    private static final int PICK_CHAT_IMAGE_REQUEST = 106;

    private ArrayList<NoteItem> itemsList = new ArrayList<NoteItem>();
    private ArrayList<PublicStoreBook> publicStoreList = new ArrayList<PublicStoreBook>();
    
    private String currentFilterTab = "الكل";
    private String currentBottomTab = "الرئيسية";
    private Typeface currentTypeface = Typeface.DEFAULT;
    private NoteItem activeTargetItemForCover = null;
    private NoteItem activeNoteForImage = null;

    private int OLED_BG_START = 0xFF030508;
    private int OLED_BG_END = 0xFF0A0E1A;
    private static final int NEON_BLUE = 0xFF3B82F6;
    private static final int GOLD_COLOR = 0xFFF59E0B;
    private static final int PURPLE_COLOR = 0xFF8B5CF6;
    private static final int LILAC_SOFT = 0xFFA78BFA;
    private static final int FAIENCE_GREEN = 0xFF2FBF9F;
    private int GLASS_CARD_BG = 0xAA111827;
    private int GLASS_BORDER = 0x558B5CF6;
    private int TEXT_PRIMARY = 0xFFF8FAFC;
    private int TEXT_MUTED = 0xFF94A3B8;
    private int TRACK_COLOR = 0xFF26324F;

    private ArrayList<NoteItem> filteredList = new ArrayList<NoteItem>();
    private ArrayAdapter<NoteItem> adapter;
    private FrameLayout rootContainer;
    private LinearLayout drawerPanel, mainLayout;
    private LinearLayout floatingDock;
    private LinearLayout homeExtras;
    private View overlayView;
    private EditText searchBox;
    private LinearLayout searchSuggestionsContainer;
    private float lastShownGoalProgress = -1f;
    private final HashMap<String, Bitmap> coverCache = new HashMap<String, Bitmap>();

    // Admin dashboard state: all data is cached locally so the dashboard remains usable offline.
    private static final String ADMIN_PREFS = "DaleelAdminDashboard";
    private static final String ADMIN_CACHE_FILE = "daleel_admin_dashboard_v1.json";
    private final ExecutorService adminExecutor = Executors.newSingleThreadExecutor();
    private final Handler adminHandler = new Handler(Looper.getMainLooper());
    private AdminDashboardData adminDashboardData = new AdminDashboardData();
    private String adminActiveSection = "overview";

    private String currentAppLanguage = "ar";
    private final HashMap<String, String[]> localizedStrings = new HashMap<String, String[]>();
    private final HashMap<String, String> offlineDictArToEn = new HashMap<String, String>();
    private final HashMap<String, String> offlineDictEnToAr = new HashMap<String, String>();

    @Override
    protected void attachBaseContext(Context newBase) {
        try {
            String savedLang = newBase.getSharedPreferences("DaleelUserProfile", MODE_PRIVATE)
                    .getString("app_language", "ar");
            super.attachBaseContext(updateLocaleContext(newBase, savedLang));
        } catch (Exception e) {
            super.attachBaseContext(newBase);
        }
    }

    private static Context updateLocaleContext(Context context, String langCode) {
        Locale locale = new Locale(langCode);
        Locale.setDefault(locale);
        Configuration config = new Configuration(context.getResources().getConfiguration());
        config.setLocale(locale);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            config.setLayoutDirection(locale);
        }
        return context.createConfigurationContext(config);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityAlive = true;
        try {
            requestWindowFeature(Window.FEATURE_NO_TITLE);
        } catch (Exception ignored) {}

        SharedPreferences prefs = getSharedPreferences("DaleelUserProfile", MODE_PRIVATE);
        int themeMode = prefs.getInt("app_theme_mode", 0);
        setupThemeColors(themeMode);

        currentAppLanguage = prefs.getString("app_language", "ar");
        buildLocalizationStrings();
        buildRichOfflineDictionary();

        enableImmersiveMode();
        checkAndRequestAppPermissions();
        createNotificationChannel();

        itemsList = new ArrayList<NoteItem>();
        loadNotesLocally();
        loadPdfTextIndex();
        loadPublicStoreBooks();
        loadAdminDashboardCache();

        final NoteItem sampleManuscript = new NoteItem(
                "المنطق",
                "ينقسم العلم عند أهل هذا الفن إلى تصور وتصديق:\n\nفالتصور إدراك الشيء من غير حكم عليه بنفي أو إثبات.\n\nوأما التصديق فهو إدراك الشيء مع الحكم عليه بنفي أو إثبات.",
                getDate(),
                "مخطوط"
        );
        sampleManuscript.subtitle = "الشيخ محمد رضا المظفر";
        sampleManuscript.category = "المكتبة";
        sampleManuscript.isPinned = true;
        sampleManuscript.isSaved = true;
        sampleManuscript.progressPercent = 25;
        sampleManuscript.pageCount = 198;
        sampleManuscript.fileSizeInfo = "8.7 م.ب";
        sampleManuscript.fileTypeInfo = "مخطوطة";

        boolean hasSample = false;
        for (NoteItem item : itemsList) {
            if (item.title != null && item.title.contains("المنطق")) {
                hasSample = true;
                break;
            }
        }
        if (!hasSample) {
            itemsList.add(0, sampleManuscript);
            saveNotesLocally();
        }

        rootContainer = new FrameLayout(this);
        rootContainer.setClipChildren(false);
        rootContainer.setClipToPadding(false);
        setContentView(rootContainer);
        setupMainUI();
        startPdfIndexing();
    }

    private void setupThemeColors(int mode) {
        if (mode == 2) {
            OLED_BG_START = 0xFFF1F5F9;
            OLED_BG_END = 0xFFE2E8F0;
            GLASS_CARD_BG = 0xEEFFFFFF;
            GLASS_BORDER = 0x66CBD5E1;
            TEXT_PRIMARY = 0xFF0F172A;
            TEXT_MUTED = 0xFF64748B;
            TRACK_COLOR = 0xFFCBD5E1;
        } else if (mode == 1) {
            OLED_BG_START = 0xFF000000;
            OLED_BG_END = 0xFF0F172A;
            GLASS_CARD_BG = 0xEE1E293B;
            GLASS_BORDER = 0x663B82F6;
            TEXT_PRIMARY = 0xFFFFFFFF;
            TEXT_MUTED = 0xFF94A3B8;
            TRACK_COLOR = 0xFF334155;
        } else {
            OLED_BG_START = 0xFF030508;
            OLED_BG_END = 0xFF0A0E1A;
            GLASS_CARD_BG = 0xAA111827;
            GLASS_BORDER = 0x558B5CF6;
            TEXT_PRIMARY = 0xFFF8FAFC;
            TEXT_MUTED = 0xFF94A3B8;
            TRACK_COLOR = 0xFF26324F;
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void checkAndRequestAppPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ArrayList<String> perms = new ArrayList<String>();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    perms.add(Manifest.permission.POST_NOTIFICATIONS);
                if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED)
                    perms.add(Manifest.permission.READ_MEDIA_IMAGES);
            } else {
                if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                    perms.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                    perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.RECORD_AUDIO);
            }
            if (!perms.isEmpty()) {
                try { requestPermissions(perms.toArray(new String[0]), PERMISSION_REQUEST_CODE); } catch (Exception ignored) {}
            }
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Daleel Pro v40", NotificationManager.IMPORTANCE_HIGH);
            channel.enableVibration(true);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void openDocumentDirectly(NoteItem item) {
        beginReadingSession(item);
        item.lastOpened = System.currentTimeMillis();
        saveNotesLocally();
        try {
            if (item.pdfUri != null && !item.pdfUri.isEmpty()) {
                showProfessionalPdfViewer(item);
            } else {
                showProfessionalTextReader(item);
            }
        } catch (RuntimeException ex) {
            endReadingSession(item);
            Toast.makeText(this, "تعذر فتح المستند، وتمت حماية التطبيق من الإغلاق.", Toast.LENGTH_LONG).show();
        }
    }

    private void showProfessionalPdfViewer(final NoteItem item) {
        final Dialog pdfDialog = new Dialog(this, android.R.style.Theme_Material_NoActionBar_Fullscreen);
        final FrameLayout rootLayout = new FrameLayout(this);
        rootLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));

        final SharedPreferences prefs = getSharedPreferences("DaleelPdfViewerPrefs", MODE_PRIVATE);
        final int[] viewerTheme = {prefs.getInt("pdf_theme", 0)};
        final int[] currentPage = {item.lastPage};
        final String[] pdfSearchQuery = {""};

        int bgHex = 0xFF0B0F17;
        int textHex = 0xFFFFFFFF;
        if (viewerTheme[0] == 1) { bgHex = 0xFF10172A; textHex = 0xFFF8FAFC; }
        else if (viewerTheme[0] == 2) { bgHex = 0xFFF5EFEB; textHex = 0xFF2C221E; }
        else if (viewerTheme[0] == 3) { bgHex = 0xFFF8FAFC; textHex = 0xFF0F172A; }

        rootLayout.setBackgroundColor(bgHex);

        final LinearLayout mainContainer = new LinearLayout(this);
        mainContainer.setOrientation(LinearLayout.VERTICAL);
        mainContainer.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));

        LinearLayout topToolbar = new LinearLayout(this);
        topToolbar.setOrientation(LinearLayout.HORIZONTAL);
        topToolbar.setGravity(Gravity.CENTER_VERTICAL);
        topToolbar.setPadding(20, 24, 20, 16);
        topToolbar.setBackgroundColor(bgHex);

        Button btnSearchPdf = makeGlassButton("🔍", Color.TRANSPARENT, 0, textHex, 14, 12);
        Button btnIndexPdf = makeGlassButton("☰", Color.TRANSPARENT, 0, textHex, 14, 12);
        Button btnThemePdf = makeGlassButton("💡", Color.TRANSPARENT, 0, textHex, 14, 12);
        
        LinearLayout leftIconsLayout = new LinearLayout(this);
        leftIconsLayout.setOrientation(LinearLayout.HORIZONTAL);
        leftIconsLayout.setGravity(Gravity.CENTER_VERTICAL);
        leftIconsLayout.addView(btnThemePdf);
        leftIconsLayout.addView(btnIndexPdf);
        leftIconsLayout.addView(btnSearchPdf);
        topToolbar.addView(leftIconsLayout);

        LinearLayout titleBlock = new LinearLayout(this);
        titleBlock.setOrientation(LinearLayout.VERTICAL);
        titleBlock.setGravity(Gravity.CENTER);
        titleBlock.setPadding(12, 0, 12, 0);

        TextView titleTv = new TextView(this);
        titleTv.setText(item.title);
        titleTv.setTextColor(GOLD_COLOR);
        titleTv.setTextSize(18);
        titleTv.setSingleLine(true);
        titleTv.setGravity(Gravity.CENTER);
        titleTv.setTypeface(currentTypeface, Typeface.BOLD);
        titleBlock.addView(titleTv);

        TextView authorTv = new TextView(this);
        authorTv.setText(item.subtitle != null && !item.subtitle.isEmpty() ? item.subtitle : "دليل المؤلفين");
        authorTv.setTextColor(textHex);
        authorTv.setTextSize(12);
        authorTv.setSingleLine(true);
        authorTv.setGravity(Gravity.CENTER);
        titleBlock.addView(authorTv);

        topToolbar.addView(titleBlock, new LinearLayout.LayoutParams(0, -2, 1.0f));

        Button btnBack = makeGlassButton(">", Color.TRANSPARENT, 0, textHex, 16, 12);
        topToolbar.addView(btnBack);

        mainContainer.addView(topToolbar);

        TextView pdfNameChip = new TextView(this);
        pdfNameChip.setText(item.title != null ? item.title : "ملف PDF");
        pdfNameChip.setTextColor(textHex);
        pdfNameChip.setTextSize(14);
        pdfNameChip.setTypeface(currentTypeface, Typeface.BOLD);
        pdfNameChip.setGravity(Gravity.CENTER);
        pdfNameChip.setSingleLine(true);
        pdfNameChip.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        pdfNameChip.setPadding(18, 12, 18, 12);
        pdfNameChip.setBackground(makeGlassDrawable(0xCC111827, GOLD_COLOR, 18, 2));
        LinearLayout.LayoutParams pdfNameLp = new LinearLayout.LayoutParams(-1, -2);
        pdfNameLp.setMargins(20, 0, 20, 8);
        mainContainer.addView(pdfNameChip, pdfNameLp);

        final LinearLayout searchBarLayout = new LinearLayout(this);
        searchBarLayout.setOrientation(LinearLayout.HORIZONTAL);
        searchBarLayout.setGravity(Gravity.CENTER_VERTICAL);
        searchBarLayout.setPadding(20, 8, 20, 8);
        searchBarLayout.setBackgroundColor(0xDD111827);
        searchBarLayout.setVisibility(View.GONE);

        final EditText pdfSearchInput = new EditText(this);
        pdfSearchInput.setHint("ابحث عن كلمة داخل الـ PDF...");
        pdfSearchInput.setTextColor(Color.WHITE);
        pdfSearchInput.setHintTextColor(TEXT_MUTED);
        pdfSearchInput.setTextSize(13);
        pdfSearchInput.setBackground(makeGlassDrawable(GLASS_CARD_BG, GOLD_COLOR, 16, 2));
        pdfSearchInput.setPadding(16, 10, 16, 10);
        searchBarLayout.addView(pdfSearchInput, new LinearLayout.LayoutParams(0, -2, 1.0f));

        Button btnExecSearch = makeButtonWithThickBorder("بحث وتحديد", GOLD_COLOR, 0, 0xFF1B1407, 12, 12, dp(36));
        searchBarLayout.addView(btnExecSearch);
        mainContainer.addView(searchBarLayout);

        final ZoomablePdfView pdfPageImageView = new ZoomablePdfView(this);
        LinearLayout.LayoutParams pageLp = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        pdfPageImageView.setLayoutParams(pageLp);
        mainContainer.addView(pdfPageImageView);

        final SeekBar fastPageSeek = new SeekBar(this);
        fastPageSeek.setMax(1);
        fastPageSeek.setProgress(0);
        fastPageSeek.setPadding(28, 0, 28, 0);
        fastPageSeek.setContentDescription("شريط تصفح صفحات PDF تدريجي");
        TextView seekHint = new TextView(this);
        seekHint.setText("مرر بهدوء للتنقل بين الصفحات");
        seekHint.setTextColor(TEXT_MUTED);
        seekHint.setTextSize(10);
        seekHint.setGravity(Gravity.CENTER);
        mainContainer.addView(seekHint, new LinearLayout.LayoutParams(-1, dp(20)));
        mainContainer.addView(fastPageSeek, new LinearLayout.LayoutParams(-1, dp(44)));

        LinearLayout bottomNavLayout = new LinearLayout(this);
        bottomNavLayout.setOrientation(LinearLayout.VERTICAL);
        bottomNavLayout.setPadding(24, 12, 24, dp(28));
        bottomNavLayout.setBackgroundColor(bgHex);

        final ProgressBar pageProgressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pageProgressBar.setProgressTintList(ColorStateList.valueOf(GOLD_COLOR));
        bottomNavLayout.addView(pageProgressBar, new LinearLayout.LayoutParams(-1, dp(6)));

        final TextView pageIndicatorTv = new TextView(this);
        pageIndicatorTv.setTextColor(TEXT_MUTED);
        pageIndicatorTv.setTextSize(12);
        pageIndicatorTv.setGravity(Gravity.CENTER);
        pageIndicatorTv.setPadding(0, 6, 0, 10);
        bottomNavLayout.addView(pageIndicatorTv);

        LinearLayout navButtonsRow = new LinearLayout(this);
        navButtonsRow.setOrientation(LinearLayout.HORIZONTAL);
        navButtonsRow.setGravity(Gravity.CENTER_VERTICAL);
        navButtonsRow.setWeightSum(2.0f);

        Button btnPrevPage = makeButtonWithThickBorder("الصفحة السابقة ◄", GOLD_COLOR, 0, 0xFF1B1407, 14, 24, dp(52));
        Button btnNextPage = makeButtonWithThickBorder("► الصفحة التالية", GLASS_CARD_BG, GLASS_BORDER, textHex, 14, 24, dp(52));

        LinearLayout.LayoutParams btnNavLp = new LinearLayout.LayoutParams(0, -2, 1.0f);
        btnNavLp.setMargins(6, 0, 6, 0);
        btnPrevPage.setLayoutParams(btnNavLp);
        btnNextPage.setLayoutParams(btnNavLp);

        navButtonsRow.addView(btnPrevPage);
        navButtonsRow.addView(btnNextPage);
        bottomNavLayout.addView(navButtonsRow);

        mainContainer.addView(bottomNavLayout);
        rootLayout.addView(mainContainer);
        pdfDialog.setContentView(rootLayout);
        pdfDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface dialog) {
                endReadingSession(item);
                setupMainUI();
            }
        });

        try {
            ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(Uri.parse(item.pdfUri), "r");
            if (pfd != null) {
                final PdfRenderer renderer = new PdfRenderer(pfd);
                final int totalPages = Math.max(1, renderer.getPageCount());
                item.pageCount = totalPages;
                pageProgressBar.setMax(totalPages);

                final Runnable renderPageAction = new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if (currentPage[0] < 0) currentPage[0] = 0;
                            if (currentPage[0] >= totalPages) currentPage[0] = totalPages - 1;

                            PdfRenderer.Page page = renderer.openPage(currentPage[0]);
                            int sourceWidth = page.getWidth();
                            int sourceHeight = page.getHeight();
                            int renderWidth = Math.min(sourceWidth, 1600);
                            int renderHeight = Math.max(1, (int) (sourceHeight * (renderWidth / (float) sourceWidth)));
                            Bitmap bitmap = Bitmap.createBitmap(renderWidth, renderHeight, Bitmap.Config.ARGB_8888);
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                            page.close();

                            if (!pdfSearchQuery[0].isEmpty()) {
                                Canvas canvas = new Canvas(bitmap);
                                Paint yellowPaint = new Paint();
                                yellowPaint.setColor(0x66FFEB3B);
                                yellowPaint.setStyle(Paint.Style.FILL);
                                canvas.drawRect(new RectF(bitmap.getWidth() * 0.15f, bitmap.getHeight() * 0.3f, bitmap.getWidth() * 0.85f, bitmap.getHeight() * 0.42f), yellowPaint);
                                
                                Paint borderPaint = new Paint();
                                borderPaint.setColor(Color.YELLOW);
                                borderPaint.setStyle(Paint.Style.STROKE);
                                borderPaint.setStrokeWidth(6f);
                                canvas.drawRect(new RectF(bitmap.getWidth() * 0.15f, bitmap.getHeight() * 0.3f, bitmap.getWidth() * 0.85f, bitmap.getHeight() * 0.42f), borderPaint);
                            }

                            pdfPageImageView.setImageBitmap(bitmap);
                            pageIndicatorTv.setText((currentPage[0] + 1) + " / " + totalPages);
                            pageProgressBar.setProgress(currentPage[0] + 1);
                            fastPageSeek.setProgress(currentPage[0]);
                            item.lastPage = currentPage[0];
                            item.progressPercent = (int) ((currentPage[0] + 1) * 100f / totalPages);
                            saveNotesLocally();
                        } catch (OutOfMemoryError oom) {
                            System.gc();
                            Toast.makeText(MainActivity.this, "تم تخفيف عرض الصفحة لتجنب إغلاق التطبيق.", Toast.LENGTH_SHORT).show();
                        } catch (Exception ignored) {}
                    }
                };
                fastPageSeek.setMax(Math.max(1, totalPages - 1));
                final Handler pdfSeekHandler = new Handler(Looper.getMainLooper());
                fastPageSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        if (fromUser && progress != currentPage[0]) {
                            pdfSeekHandler.removeCallbacksAndMessages(null);
                            final int requestedPage = progress;
                            pdfSeekHandler.postDelayed(new Runnable() {
                                @Override public void run() {
                                    if (requestedPage != currentPage[0]) {
                                        currentPage[0] = requestedPage;
                                        renderPageAction.run();
                                    }
                                }
                            }, 180L);
                        }
                    }
                    @Override public void onStartTrackingTouch(SeekBar seekBar) {}
                    @Override public void onStopTrackingTouch(SeekBar seekBar) {}
                });

                renderPageAction.run();

                pdfPageImageView.setOnTouchSideListener(new ZoomablePdfView.OnTouchSideListener() {
                    @Override
                    public void onTouchSide(boolean isRight) {
                        if (isRight) {
                            if (currentPage[0] < totalPages - 1) {
                                currentPage[0]++;
                                renderPageAction.run();
                            }
                        } else {
                            if (currentPage[0] > 0) {
                                currentPage[0]--;
                                renderPageAction.run();
                            }
                        }
                    }
                });

                btnSearchPdf.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (searchBarLayout.getVisibility() == View.VISIBLE) {
                            searchBarLayout.setVisibility(View.GONE);
                            pdfSearchQuery[0] = "";
                            renderPageAction.run();
                        } else {
                            searchBarLayout.setVisibility(View.VISIBLE);
                        }
                    }
                });

                btnExecSearch.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        pdfSearchQuery[0] = pdfSearchInput.getText().toString().trim();
                        if (!pdfSearchQuery[0].isEmpty()) {
                            int foundPage = findPdfPage(item, pdfSearchQuery[0], totalPages);
                            if (foundPage >= 0) {
                                currentPage[0] = foundPage;
                                Toast.makeText(MainActivity.this, "🔍 تم العثور على الكلمة في الصفحة " + (foundPage + 1), Toast.LENGTH_LONG).show();
                                renderPageAction.run();
                            } else {
                                Toast.makeText(MainActivity.this, "لم يتم العثور على الكلمة في النص المستخرج من هذا الملف.", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                });

                btnPrevPage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (currentPage[0] > 0) {
                            currentPage[0]--;
                            renderPageAction.run();
                        }
                    }
                });

                btnNextPage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (currentPage[0] < totalPages - 1) {
                            currentPage[0]++;
                            renderPageAction.run();
                        }
                    }
                });

                btnBack.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try { renderer.close(); pfd.close(); } catch (Exception ignored) {}
                        pdfDialog.dismiss();
                        setupMainUI();
                    }
                });
            }
        } catch (Exception e) {
            Toast.makeText(this, "تعذر قراءة ملف الـ PDF مباشرة.", Toast.LENGTH_SHORT).show();
        }

        btnThemePdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewerTheme[0] = (viewerTheme[0] + 1) % 4;
                prefs.edit().putInt("pdf_theme", viewerTheme[0]).apply();
                pdfDialog.dismiss();
                showProfessionalPdfViewer(item);
            }
        });

        pdfDialog.show();
    }

    private void showProfessionalTextReader(final NoteItem item) {
        final Dialog textDialog = new Dialog(this, android.R.style.Theme_Material_NoActionBar_Fullscreen);
        final FrameLayout rootLayout = new FrameLayout(this);
        rootLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));

        final SharedPreferences prefs = getSharedPreferences("DaleelTextReaderPrefs", MODE_PRIVATE);
        final int[] themeMode = {prefs.getInt("txt_theme", 0)};
        final int[] textSizeVal = {prefs.getInt("txt_size", 18)};
        final boolean[] showInlineNotes = {prefs.getBoolean("show_inline_notes", true)};
        final int bottomBarHeight = prefs.getInt("reader_bottom_bar_height", 64);

        int bgHex = 0xFF000000;
        int textHex = 0xFFFFFFFF;
        if (themeMode[0] == 1) { bgHex = 0xFF10172A; textHex = 0xFFF8FAFC; }
        else if (themeMode[0] == 2) { bgHex = 0xFFF5EFEB; textHex = 0xFF2C221E; }
        else if (themeMode[0] == 3) { bgHex = 0xFFF8FAFC; textHex = 0xFF0F172A; }

        rootLayout.setBackgroundColor(bgHex);

        final LinearLayout mainContainer = new LinearLayout(this);
        mainContainer.setOrientation(LinearLayout.VERTICAL);
        mainContainer.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));

        LinearLayout topToolbar = new LinearLayout(this);
        topToolbar.setOrientation(LinearLayout.HORIZONTAL);
        topToolbar.setGravity(Gravity.CENTER_VERTICAL);
        topToolbar.setPadding(20, 20, 20, 16);
        topToolbar.setBackgroundColor(bgHex);

        Button btnBookmark = makeGlassButton("إشارة", Color.TRANSPARENT, 0, textHex, 12, 12);
        Button btnSearch = makeGlassButton("بحث", Color.TRANSPARENT, 0, textHex, 12, 12);
        
        topToolbar.addView(btnBookmark);
        topToolbar.addView(btnSearch);

        LinearLayout glassTitleBox = new LinearLayout(this);
        glassTitleBox.setOrientation(LinearLayout.VERTICAL);
        glassTitleBox.setGravity(Gravity.CENTER);
        glassTitleBox.setPadding(24, 10, 24, 10);
        
        GradientDrawable glassBoxBg = new GradientDrawable();
        glassBoxBg.setColor(GLASS_CARD_BG);
        glassBoxBg.setCornerRadius(24f);
        glassBoxBg.setStroke(2, GLASS_BORDER);
        glassTitleBox.setBackground(glassBoxBg);

        TextView titleTv = new TextView(this);
        titleTv.setText(item.title);
        titleTv.setTextColor(textHex);
        titleTv.setTextSize(16);
        titleTv.setGravity(Gravity.CENTER);
        titleTv.setTypeface(currentTypeface, Typeface.BOLD);
        glassTitleBox.addView(titleTv);

        TextView subTv = new TextView(this);
        subTv.setText(item.subtitle);
        subTv.setTextColor(LILAC_SOFT);
        subTv.setTextSize(11);
        subTv.setGravity(Gravity.CENTER);
        glassTitleBox.addView(subTv);

        LinearLayout.LayoutParams titleBoxLp = new LinearLayout.LayoutParams(0, -2, 1.0f);
        titleBoxLp.setMargins(16, 0, 16, 0);
        topToolbar.addView(glassTitleBox, titleBoxLp);

        Button btnBackArrow = makeGlassButton("رجوع", Color.TRANSPARENT, 0, textHex, 14, 12);
        topToolbar.addView(btnBackArrow);
        mainContainer.addView(topToolbar);

        final TextView pageNumHeader = new TextView(this);
        pageNumHeader.setText("سطر 1");
        pageNumHeader.setTextColor(TEXT_MUTED);
        pageNumHeader.setTextSize(11);
        pageNumHeader.setGravity(Gravity.CENTER);
        pageNumHeader.setPadding(0, 0, 0, 8);
        mainContainer.addView(pageNumHeader);

        final ScrollView scrollView = new ScrollView(this);
        scrollView.setVerticalScrollBarEnabled(false);
        final LinearLayout textBodyLayout = new LinearLayout(this);
        textBodyLayout.setOrientation(LinearLayout.VERTICAL);
        textBodyLayout.setPadding(32, 16, 32, 40);

        TextView contentTv = new TextView(this);
        contentTv.setText(item.content);
        contentTv.setTextColor(textHex);
        contentTv.setTextSize(textSizeVal[0]);
        contentTv.setTypeface(currentTypeface);
        textBodyLayout.addView(contentTv);

        if (showInlineNotes[0] && item.readerNotes != null && !item.readerNotes.isEmpty()) {
            for (String noteText : item.readerNotes) {
                LinearLayout inlineNoteCard = new LinearLayout(this);
                inlineNoteCard.setOrientation(LinearLayout.VERTICAL);
                inlineNoteCard.setPadding(24, 20, 24, 20);
                GradientDrawable noteBg = new GradientDrawable();
                noteBg.setColor(0x222FBF9F);
                noteBg.setCornerRadius(20f);
                noteBg.setStroke(2, FAIENCE_GREEN);
                inlineNoteCard.setBackground(noteBg);
                LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
                noteLp.setMargins(0, 24, 0, 16);
                inlineNoteCard.setLayoutParams(noteLp);

                LinearLayout noteHead = new LinearLayout(this);
                noteHead.setOrientation(LinearLayout.HORIZONTAL);
                noteHead.setGravity(Gravity.CENTER_VERTICAL);

                TextView noteBadge = new TextView(this);
                noteBadge.setText("1");
                noteBadge.setTextColor(Color.WHITE);
                noteBadge.setTextSize(11);
                noteBadge.setTypeface(currentTypeface, Typeface.BOLD);
                noteBadge.setPadding(10, 2, 10, 2);
                GradientDrawable bBg = new GradientDrawable();
                bBg.setColor(FAIENCE_GREEN);
                bBg.setCornerRadius(12f);
                noteBadge.setBackground(bBg);
                noteHead.addView(noteBadge);

                TextView noteBody = new TextView(this);
                noteBody.setText("  " + noteText);
                noteBody.setTextColor(textHex);
                noteBody.setTextSize(13);
                noteHead.addView(noteBody, new LinearLayout.LayoutParams(0, -2, 1.0f));
                inlineNoteCard.addView(noteHead);

                textBodyLayout.addView(inlineNoteCard);
            }
        }

        scrollView.addView(textBodyLayout);
        mainContainer.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1.0f));

        scrollView.post(new Runnable() {
            @Override
            public void run() {
                scrollView.scrollTo(0, item.lastScrollY);
            }
        });

        scrollView.setOnScrollChangeListener(new View.OnScrollChangeListener() {
            @Override
            public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                int lineNum = Math.max(1, (scrollY / 50) + 1);
                pageNumHeader.setText("سطر " + lineNum);
            }
        });

        LinearLayout textBottomBar = new LinearLayout(this);
        textBottomBar.setOrientation(LinearLayout.HORIZONTAL);
        textBottomBar.setGravity(Gravity.CENTER_VERTICAL);
        textBottomBar.setWeightSum(3.0f);
        textBottomBar.setPadding(16, 8, 16, dp(28));
        
        GradientDrawable bottomBarStyle = new GradientDrawable();
        bottomBarStyle.setColor(bgHex);
        bottomBarStyle.setStroke(1, GLASS_BORDER);
        textBottomBar.setBackground(bottomBarStyle);

        Button btnDisplayOpts = makeButtonWithThickBorder("العرض", GLASS_CARD_BG, GLASS_BORDER, textHex, 12, 20, dp(48));
        Button btnMyNotes = makeButtonWithThickBorder("ملاحظاتي (" + item.readerNotes.size() + ")", GLASS_CARD_BG, GLASS_BORDER, textHex, 12, 20, dp(48));
        Button btnIndex = makeButtonWithThickBorder("الفهرس", GLASS_CARD_BG, GLASS_BORDER, textHex, 12, 20, dp(48));

        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(0, dp(bottomBarHeight), 1.0f);
        barLp.setMargins(6, 0, 6, 0);
        btnDisplayOpts.setLayoutParams(barLp);
        btnMyNotes.setLayoutParams(barLp);
        btnIndex.setLayoutParams(barLp);

        textBottomBar.addView(btnDisplayOpts);
        textBottomBar.addView(btnMyNotes);
        textBottomBar.addView(btnIndex);
        mainContainer.addView(textBottomBar);

        rootLayout.addView(mainContainer);
        textDialog.setContentView(rootLayout);

        textDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                endReadingSession(item);
                item.lastScrollY = scrollView.getScrollY();
                item.progressPercent = Math.min(100, Math.max(5, (int) (100f * scrollView.getScrollY() / Math.max(1, textBodyLayout.getHeight()))));
                saveNotesLocally();
                setupMainUI();
            }
        });

        btnBackArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                item.lastScrollY = scrollView.getScrollY();
                textDialog.dismiss();
            }
        });

        btnDisplayOpts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showReaderDisplayOptionsDialog(item, textDialog);
            }
        });

        btnMyNotes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showItemIndependentNotesDialog(item, textDialog);
            }
        });

        btnIndex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showReaderIndexDialog();
            }
        });

        btnBookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences bookmarkPrefs = getSharedPreferences("DaleelBookmarks", MODE_PRIVATE);
                int currentScroll = scrollView.getScrollY();
                bookmarkPrefs.edit().putInt("bookmark_" + item.title, currentScroll).apply();
                Toast.makeText(MainActivity.this, "تم حفظ الإشارة المرجعية بنجاح", Toast.LENGTH_SHORT).show();
            }
        });

        textDialog.show();
    }

    private void showReaderDisplayOptionsDialog(final NoteItem item, final Dialog parentDialog) {
        final Dialog optionsDialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(36, 40, 36, 40);
        sheet.setBackgroundColor(0xFF1E293B);

        ScrollView sv = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        TextView title = new TextView(this);
        title.setText("خيارات القراءة");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 24);
        content.addView(title);

        TextView bgLabel = new TextView(this);
        bgLabel.setText("الخلفية");
        bgLabel.setTextColor(TEXT_MUTED);
        bgLabel.setTextSize(13);
        content.addView(bgLabel);

        LinearLayout bgRow = new LinearLayout(this);
        bgRow.setOrientation(LinearLayout.HORIZONTAL);
        bgRow.setWeightSum(4.0f);
        bgRow.setPadding(0, 8, 0, 20);

        Button btnThemeBlack = makeButtonWithThickBorder("أسود", 0xFF000000, GLASS_BORDER, Color.WHITE, 12, 16, dp(48));
        Button btnThemeNight = makeButtonWithThickBorder("ليلي", 0xFF10172A, GLASS_BORDER, Color.WHITE, 12, 16, dp(48));
        Button btnThemeSepia = makeButtonWithThickBorder("بردي", 0xFFF5EFEB, GLASS_BORDER, 0xFF2C221E, 12, 16, dp(48));
        Button btnThemeDay = makeButtonWithThickBorder("نهاري", 0xFFF8FAFC, GLASS_BORDER, 0xFF0F172A, 12, 16, dp(48));

        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(0, -2, 1.0f);
        bLp.setMargins(4, 0, 4, 0);
        btnThemeBlack.setLayoutParams(bLp);
        btnThemeNight.setLayoutParams(bLp);
        btnThemeSepia.setLayoutParams(bLp);
        btnThemeDay.setLayoutParams(bLp);

        bgRow.addView(btnThemeBlack);
        bgRow.addView(btnThemeNight);
        bgRow.addView(btnThemeSepia);
        bgRow.addView(btnThemeDay);
        content.addView(bgRow);

        sv.addView(content);
        sheet.addView(sv, new LinearLayout.LayoutParams(-1, 1000));
        optionsDialog.setContentView(sheet);

        final SharedPreferences textPrefs = getSharedPreferences("DaleelTextReaderPrefs", MODE_PRIVATE);
        btnThemeBlack.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                textPrefs.edit().putInt("txt_theme", 0).apply();
                optionsDialog.dismiss();
                parentDialog.dismiss();
                showProfessionalTextReader(item);
            }
        });
        btnThemeNight.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                textPrefs.edit().putInt("txt_theme", 1).apply();
                optionsDialog.dismiss();
                parentDialog.dismiss();
                showProfessionalTextReader(item);
            }
        });
        btnThemeSepia.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                textPrefs.edit().putInt("txt_theme", 2).apply();
                optionsDialog.dismiss();
                parentDialog.dismiss();
                showProfessionalTextReader(item);
            }
        });
        btnThemeDay.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                textPrefs.edit().putInt("txt_theme", 3).apply();
                optionsDialog.dismiss();
                parentDialog.dismiss();
                showProfessionalTextReader(item);
            }
        });

        optionsDialog.show();
    }

    private void showItemIndependentNotesDialog(final NoteItem item, final Dialog parentReaderDialog) {
        final Dialog notesDialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(36, 40, 36, 40);
        sheet.setBackgroundColor(0xFF1E293B);

        TextView title = new TextView(this);
        title.setText("ملاحظات: " + item.title);
        title.setTextColor(Color.WHITE);
        title.setTextSize(16);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setPadding(0, 0, 0, 16);
        sheet.addView(title);

        ScrollView sv = new ScrollView(this);
        final LinearLayout notesListLayout = new LinearLayout(this);
        notesListLayout.setOrientation(LinearLayout.VERTICAL);

        final Runnable refreshNotesList = new Runnable() {
            @Override
            public void run() {
                notesListLayout.removeAllViews();
                if (item.readerNotes.isEmpty()) {
                    TextView emptyTv = new TextView(notesListLayout.getContext());
                    emptyTv.setText("لا توجد ملاحظات مسجلة لهذا الكتاب بعد.");
                    emptyTv.setTextColor(TEXT_MUTED);
                    emptyTv.setTextSize(13);
                    notesListLayout.addView(emptyTv);
                } else {
                    for (int i = 0; i < item.readerNotes.size(); i++) {
                        final int index = i;
                        final String nText = item.readerNotes.get(i);

                        LinearLayout card = new LinearLayout(notesListLayout.getContext());
                        card.setOrientation(LinearLayout.HORIZONTAL);
                        card.setGravity(Gravity.CENTER_VERTICAL);
                        card.setPadding(20, 16, 20, 16);
                        GradientDrawable cBg = new GradientDrawable();
                        cBg.setColor(0x333B82F6);
                        cBg.setCornerRadius(16f);
                        card.setBackground(cBg);
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                        lp.setMargins(0, 8, 0, 8);
                        card.setLayoutParams(lp);

                        TextView nTv = new TextView(card.getContext());
                        nTv.setText((index + 1) + ". " + nText);
                        nTv.setTextColor(Color.WHITE);
                        nTv.setTextSize(13);
                        card.addView(nTv, new LinearLayout.LayoutParams(0, -2, 1.0f));

                        Button btnDel = makeButtonWithThickBorder("حذف", Color.TRANSPARENT, Color.RED, Color.RED, 11, 12, dp(44));
                        btnDel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                item.readerNotes.remove(index);
                                saveNotesLocally();
                                run();
                            }
                        });
                        card.addView(btnDel);
                        notesListLayout.addView(card);
                    }
                }
            }
        };

        refreshNotesList.run();
        sv.addView(notesListLayout);
        sheet.addView(sv, new LinearLayout.LayoutParams(-1, 800));

        final EditText newNoteInput = new EditText(this);
        newNoteInput.setHint("اكتب اقتباساً أو ملاحظة جديدة...");
        newNoteInput.setTextColor(Color.WHITE);
        newNoteInput.setHintTextColor(TEXT_MUTED);
        newNoteInput.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 16, 2));
        newNoteInput.setPadding(20, 16, 20, 16);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(-1, -2);
        inputLp.setMargins(0, 16, 0, 12);
        newNoteInput.setLayoutParams(inputLp);
        sheet.addView(newNoteInput);

        Button btnAddNote = makeButtonWithThickBorder("+ إضافة الملاحظة للكتاب", FAIENCE_GREEN, 0, Color.WHITE, 13, 20, dp(48));
        sheet.addView(btnAddNote);

        btnAddNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String txt = newNoteInput.getText().toString().trim();
                if (!txt.isEmpty()) {
                    item.readerNotes.add(txt);
                    saveNotesLocally();
                    newNoteInput.setText("");
                    refreshNotesList.run();
                    Toast.makeText(MainActivity.this, "تمت إضافة الملاحظة بنجاح", Toast.LENGTH_SHORT).show();
                }
            }
        });

        notesDialog.setContentView(sheet);
        notesDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                parentReaderDialog.dismiss();
                showProfessionalTextReader(item);
            }
        });
        notesDialog.show();
    }

    private void confirmAndDeleteCard(final NoteItem item) {
        new AlertDialog.Builder(this)
                .setTitle("حذف المستند")
                .setMessage("هل أنت متأكد من رغبتك في حذف بطاقة: " + item.title + "؟")
                .setPositiveButton("نعم، احذف", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        itemsList.remove(item);
                        saveNotesLocally();
                        filterData("");
                        setupMainUI();
                        Toast.makeText(MainActivity.this, "تم حذف البطاقة بنجاح", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void showCardOptionsDialog(final NoteItem item) {
        CharSequence[] options = {"تعديل الغلاف", "مزامنة سحابية", "حذف البطاقة"};
        new AlertDialog.Builder(this)
                .setTitle(item.title)
                .setItems(options, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            activeTargetItemForCover = item;
                            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                            intent.addCategory(Intent.CATEGORY_OPENABLE);
                            intent.setType("image/*");
                            try { startActivityForResult(intent, PICK_COVER_IMAGE_REQUEST); } catch (Exception ignored) {}
                        } else if (which == 1) {
                            item.isSyncedToCloud = true;
                            saveNotesLocally();
                            Toast.makeText(MainActivity.this, "تم رفع الملف وربطه بالسحابة بنجاح", Toast.LENGTH_SHORT).show();
                        } else if (which == 2) {
                            confirmAndDeleteCard(item);
                        }
                    }
                })
                .show();
    }

    private void showAdvancedAddOptionsDialog() {
        final Dialog addDialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(36, 40, 36, 40);
        sheet.setBackgroundColor(OLED_BG_END);

        TextView title = new TextView(this);
        title.setText("إضافة محتوى جديد");
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(18);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 8);
        sheet.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("اختر من وين تبي تضيف");
        subtitle.setTextColor(TEXT_MUTED);
        subtitle.setTextSize(13);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, 24);
        sheet.addView(subtitle);

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setWeightSum(2.0f);

        LinearLayout cardBook = makeAddCardBlock("إضافة كتاب", "من مكتبتك", 0xFF0A2F1D, FAIENCE_GREEN, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addDialog.dismiss();
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/pdf");
                try { startActivityForResult(intent, PICK_PDF_DOCUMENT_REQUEST); } catch (Exception ignored) {}
            }
        });

        LinearLayout cardPdf = makeAddCardBlock("إضافة ملف PDF", "من جهازك", 0xFF0F1E36, NEON_BLUE, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addDialog.dismiss();
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/pdf");
                try { startActivityForResult(intent, PICK_PDF_DOCUMENT_REQUEST); } catch (Exception ignored) {}
            }
        });

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(0, dp(140), 1.0f);
        cardLp.setMargins(6, 6, 6, 6);
        cardBook.setLayoutParams(cardLp);
        cardPdf.setLayoutParams(cardLp);

        row1.addView(cardBook);
        row1.addView(cardPdf);
        sheet.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setWeightSum(2.0f);

        LinearLayout cardCloud = makeAddCardBlock("التخزين السحابي", "إدارة ملفاتك", 0xFF0D2838, 0xFF38BDF8, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addDialog.dismiss();
                showCloudStorageDialog();
            }
        });

        LinearLayout cardLink = makeAddCardBlock("إضافة رابط", "الصق الرابط", 0xFF1E1B38, PURPLE_COLOR, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addDialog.dismiss();
                showAddLinkDialog();
            }
        });

        cardCloud.setLayoutParams(cardLp);
        cardLink.setLayoutParams(cardLp);

        row2.addView(cardCloud);
        row2.addView(cardLink);
        sheet.addView(row2);

        addDialog.setContentView(sheet);
        addDialog.show();
    }

    private LinearLayout makeAddCardBlock(String mainText, String subText, int bgColor, int borderColor, View.OnClickListener listener) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(20, 20, 20, 20);
        box.setGravity(Gravity.CENTER);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(bgColor);
        bg.setCornerRadius(28f);
        bg.setStroke(3, borderColor);
        box.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), bg, bg));
        box.setElevation(6f);

        TextView t1 = new TextView(this);
        t1.setText(mainText);
        t1.setTextColor(Color.WHITE);
        t1.setTextSize(15);
        t1.setTypeface(currentTypeface, Typeface.BOLD);
        t1.setGravity(Gravity.CENTER);
        t1.setPadding(0, 8, 0, 4);
        box.addView(t1);

        TextView t2 = new TextView(this);
        t2.setText(subText);
        t2.setTextColor(TEXT_MUTED);
        t2.setTextSize(12);
        t2.setGravity(Gravity.CENTER);
        box.addView(t2);

        box.setOnClickListener(listener);
        return box;
    }

    private void showAppleStyleNotesDialog() {
        final NoteItem currentEditingNote = new NoteItem("", "", getDate(), "ملاحظة");
        currentEditingNote.fileTypeInfo = "ملاحظة شخصية";
        currentEditingNote.isSaved = true;
        currentEditingNote.paperColor = 0xFF000000;

        final Dialog noteDialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_Fullscreen);
        
        final LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(currentEditingNote.paperColor);
        layout.setPadding(24, 16, 24, 0);

        ScrollView scrollView = new ScrollView(this);
        scrollView.setVerticalScrollBarEnabled(false);
        final LinearLayout scrollContent = new LinearLayout(this);
        scrollContent.setOrientation(LinearLayout.VERTICAL);

        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(0, 8, 0, 12);

        Button btnBackArrow = makeButtonWithThickBorder("تم / رجوع", Color.TRANSPARENT, 0, 0xFFFFFFFF, 13, 12, dp(40));

        View tSp = new View(this);

        Button btnThreeDots = makeButtonWithThickBorder("خيارات متقدمة", Color.TRANSPARENT, 0, 0xFFFFFFFF, 12, 8, dp(40));
        Button btnPaperStyle = makeButtonWithThickBorder("الورق", Color.TRANSPARENT, 0, 0xFFFFFFFF, 12, 8, dp(40));
        Button btnShareNote = makeButtonWithThickBorder("مشاركة", Color.TRANSPARENT, 0, 0xFFFFFFFF, 12, 8, dp(40));

        LinearLayout.LayoutParams btnTopLp = new LinearLayout.LayoutParams(-2, dp(40));
        btnTopLp.setMargins(4, 0, 4, 0);
        btnThreeDots.setLayoutParams(btnTopLp);
        btnPaperStyle.setLayoutParams(btnTopLp);
        btnShareNote.setLayoutParams(btnTopLp);

        topBar.addView(btnThreeDots);
        topBar.addView(btnPaperStyle);
        topBar.addView(btnShareNote);
        topBar.addView(tSp, new LinearLayout.LayoutParams(0, 0, 1.0f));
        topBar.addView(btnBackArrow);

        scrollContent.addView(topBar);

        final EditText titleInput = new EditText(this);
        titleInput.setHint("العنوان");
        titleInput.setTextColor(0xFFFFFFFF);
        titleInput.setHintTextColor(0xFF888888);
        titleInput.setTextSize(26);
        titleInput.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        titleInput.setBackgroundColor(Color.TRANSPARENT);
        titleInput.setPadding(0, 12, 0, 8);
        scrollContent.addView(titleInput);

        LinearLayout metaRow = new LinearLayout(this);
        metaRow.setOrientation(LinearLayout.HORIZONTAL);
        metaRow.setGravity(Gravity.CENTER_VERTICAL);
        metaRow.setPadding(0, 4, 0, 12);

        TextView dateBadge = new TextView(this);
        dateBadge.setText(new SimpleDateFormat("d سبتمبر في h:mm a", new Locale("ar")).format(new Date()) + " | 0 حرف");
        dateBadge.setTextColor(0xFFCCCCCC);
        dateBadge.setTextSize(12);
        metaRow.addView(dateBadge);
        scrollContent.addView(metaRow);

        LinearLayout badgesRow = new LinearLayout(this);
        badgesRow.setOrientation(LinearLayout.HORIZONTAL);
        badgesRow.setPadding(0, 0, 0, 16);

        final Button btnLinkBook = makeButtonWithThickBorder("اربط بكتاب", 0x33FFFFFF, 0x66FFFFFF, 0xFFFFFFFF, 12, 16, dp(36));
        final Button btnTag = makeButtonWithThickBorder("+ وسم", 0x33FFFFFF, 0x66FFFFFF, 0xFFFFFFFF, 12, 16, dp(36));

        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(-2, -2);
        badgeLp.setMarginEnd(8);
        btnLinkBook.setLayoutParams(badgeLp);
        btnTag.setLayoutParams(badgeLp);

        badgesRow.addView(btnLinkBook);
        badgesRow.addView(btnTag);
        scrollContent.addView(badgesRow);

        final EditText contentInput = new EditText(this);
        contentInput.setHint("ابدأ الكتابة هنا...");
        contentInput.setTextColor(0xFFFFFFFF);
        contentInput.setHintTextColor(0xFF888888);
        contentInput.setTextSize(16);
        contentInput.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        contentInput.setBackgroundColor(Color.TRANSPARENT);
        contentInput.setGravity(Gravity.TOP);
        contentInput.setMinLines(15);
        scrollContent.addView(contentInput);

        scrollView.addView(scrollContent);
        layout.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1.0f));

        btnThreeDots.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog menuDialog = new Dialog(MainActivity.this, android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor);
                LinearLayout sheet = new LinearLayout(MainActivity.this);
                sheet.setOrientation(LinearLayout.VERTICAL);
                sheet.setPadding(36, 40, 36, 40);
                GradientDrawable dBg = new GradientDrawable();
                dBg.setColor(0xEE111827);
                dBg.setCornerRadius(32f);
                dBg.setStroke(2, GLASS_BORDER);
                sheet.setBackground(dBg);

                TextView mTitle = new TextView(MainActivity.this);
                mTitle.setText("خيارات الملاحظة المتقدمة");
                mTitle.setTextColor(Color.WHITE);
                mTitle.setTextSize(17);
                mTitle.setTypeface(currentTypeface, Typeface.BOLD);
                mTitle.setGravity(Gravity.CENTER);
                mTitle.setPadding(0, 0, 0, 20);
                sheet.addView(mTitle);

                String[] menuItems = {
                    "معلومات الملاحظة والكلمات",
                    currentEditingNote.isPinned ? "إلغاء تثبيت الملاحظة" : "تثبيت الملاحظة في الأعلى",
                    "منبه الملاحظة والتنبيهات",
                    "تغيير الخط (الخط العريض / الآيفون / الافتراضي)",
                    "حفظ نهائي ومزامنة",
                    "حذف الملاحظة"
                };

                for (int i = 0; i < menuItems.length; i++) {
                    final int index = i;
                    TextView itemTv = new TextView(MainActivity.this);
                    itemTv.setText(menuItems[i]);
                    itemTv.setTextColor(index == 5 ? Color.RED : Color.WHITE);
                    itemTv.setTextSize(14);
                    itemTv.setPadding(24, 18, 24, 18);
                    GradientDrawable itemBg = new GradientDrawable();
                    itemBg.setColor(0x22FFFFFF);
                    itemBg.setCornerRadius(16f);
                    itemTv.setBackground(itemBg);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                    lp.setMargins(0, 6, 0, 6);
                    itemTv.setLayoutParams(lp);

                    itemTv.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            menuDialog.dismiss();
                            if (index == 0) {
                                String textContent = contentInput.getText().toString().trim();
                                int wordCount = textContent.isEmpty() ? 0 : textContent.split("\\s+").length;
                                int charCount = textContent.length();
                                new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("معلومات الملاحظة")
                                    .setMessage("عدد الكلمات: " + wordCount + "\nعدد الحروف: " + charCount + "\nتاريخ الإنشاء: " + currentEditingNote.dateAdded + "\nنوع المستند: " + currentEditingNote.fileTypeInfo)
                                    .setPositiveButton("حسناً", null)
                                    .show();
                            } else if (index == 1) {
                                currentEditingNote.isPinned = !currentEditingNote.isPinned;
                                Toast.makeText(MainActivity.this, currentEditingNote.isPinned ? "تم تثبيت الملاحظة بنجاح" : "تم إلغاء التثبيت", Toast.LENGTH_SHORT).show();
                            } else if (index == 2) {
                                showAlarmManagementScreen();
                            } else if (index == 3) {
                                CharSequence[] fonts = {"الخط الافتراضي", "الخط العريض (خط الآيفون)", "خط Serif"};
                                new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("اختر نوع الخط")
                                    .setItems(fonts, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface fDialog, int fWhich) {
                                            if (fWhich == 1) {
                                                currentTypeface = Typeface.create("sans-serif-medium", Typeface.BOLD);
                                                contentInput.setTypeface(currentTypeface);
                                                titleInput.setTypeface(currentTypeface);
                                                Toast.makeText(MainActivity.this, "تم تطبيق الخط العريض بنجاح", Toast.LENGTH_SHORT).show();
                                            } else if (fWhich == 2) {
                                                currentTypeface = Typeface.SERIF;
                                                contentInput.setTypeface(currentTypeface);
                                                titleInput.setTypeface(currentTypeface);
                                            } else {
                                                currentTypeface = Typeface.DEFAULT;
                                                contentInput.setTypeface(currentTypeface);
                                                titleInput.setTypeface(currentTypeface);
                                            }
                                        }
                                    }).show();
                            } else if (index == 4) {
                                String title = titleInput.getText().toString().trim();
                                String content = contentInput.getText().toString().trim();
                                if (!title.isEmpty() || !content.isEmpty()) {
                                    if (title.isEmpty()) title = content.length() > 20 ? content.substring(0, 20) + "..." : content;
                                    currentEditingNote.title = title;
                                    currentEditingNote.content = content;
                                    itemsList.add(0, currentEditingNote);
                                    saveNotesLocally();
                                    filterData("");
                                    setupMainUI();
                                    Toast.makeText(MainActivity.this, "تم حفظ الملاحظة بنجاح", Toast.LENGTH_SHORT).show();
                                }
                                noteDialog.dismiss();
                            } else if (index == 5) {
                                Toast.makeText(MainActivity.this, "تم حذف الملاحظة", Toast.LENGTH_SHORT).show();
                                noteDialog.dismiss();
                            }
                        }
                    });
                    sheet.addView(itemTv);
                }

                menuDialog.setContentView(sheet);
                menuDialog.show();
            }
        });

        btnPaperStyle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int[] paperColorsPalette = {0xFF000000, 0xFF1A1A1A, 0xFFEAE2D0, 0xFF2F5249, 0xFF222831, 0xFF393E46};
                final Dialog paperDialog = new Dialog(MainActivity.this, android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor);
                LinearLayout pSheet = new LinearLayout(MainActivity.this);
                pSheet.setOrientation(LinearLayout.VERTICAL);
                pSheet.setPadding(36, 40, 36, 40);
                pSheet.setBackgroundColor(0xFF1E293B);

                TextView pTitle = new TextView(MainActivity.this);
                pTitle.setText("اختر ورق الملاحظة والخلفية");
                pTitle.setTextColor(Color.WHITE);
                pTitle.setTextSize(17);
                pTitle.setTypeface(currentTypeface, Typeface.BOLD);
                pTitle.setGravity(Gravity.CENTER);
                pTitle.setPadding(0, 0, 0, 20);
                pSheet.addView(pTitle);

                LinearLayout colorsRow = new LinearLayout(MainActivity.this);
                colorsRow.setOrientation(LinearLayout.HORIZONTAL);
                colorsRow.setGravity(Gravity.CENTER);

                for (int i = 0; i < paperColorsPalette.length; i++) {
                    final int cColor = paperColorsPalette[i];
                    View colorCard = new View(MainActivity.this);
                    LinearLayout.LayoutParams cpLp = new LinearLayout.LayoutParams(dp(50), dp(70));
                    cpLp.setMargins(8, 0, 8, 0);
                    colorCard.setLayoutParams(cpLp);
                    GradientDrawable cBg = new GradientDrawable();
                    cBg.setColor(cColor);
                    cBg.setCornerRadius(16f);
                    cBg.setStroke(3, cColor == currentEditingNote.paperColor ? GOLD_COLOR : GLASS_BORDER);
                    colorCard.setBackground(cBg);

                    colorCard.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            currentEditingNote.paperColor = cColor;
                            layout.setBackgroundColor(currentEditingNote.paperColor);
                            paperDialog.dismiss();
                            Toast.makeText(MainActivity.this, "تم تغيير ورق الملاحظة بنجاح", Toast.LENGTH_SHORT).show();
                        }
                    });
                    colorsRow.addView(colorCard);
                }
                pSheet.addView(colorsRow);
                paperDialog.setContentView(pSheet);
                paperDialog.show();
            }
        });

        btnShareNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, contentInput.getText().toString());
                startActivity(Intent.createChooser(shareIntent, "مشاركة الملاحظة عبر"));
            }
        });

        LinearLayout noteBottomBar = new LinearLayout(this);
        noteBottomBar.setOrientation(LinearLayout.HORIZONTAL);
        noteBottomBar.setGravity(Gravity.CENTER_VERTICAL);
        noteBottomBar.setWeightSum(5.0f);
        noteBottomBar.setPadding(8, 12, 8, dp(24));
        noteBottomBar.setBackgroundColor(currentEditingNote.paperColor);

        Button btnAddTool = makeButtonWithThickBorder("أدوات ذكية", Color.TRANSPARENT, 0, Color.WHITE, 12, 16, dp(48));
        Button btnCheckListTool = makeButtonWithThickBorder("قائمة", Color.TRANSPARENT, 0, Color.WHITE, 12, 16, dp(48));
        Button btnDrawTool = makeButtonWithThickBorder("رسم", Color.TRANSPARENT, 0, Color.WHITE, 12, 16, dp(48));
        Button btnImageTool = makeButtonWithThickBorder("صورة", Color.TRANSPARENT, 0, Color.WHITE, 12, 16, dp(48));
        Button btnAudioTool = makeButtonWithThickBorder("تسجيل صوت", Color.TRANSPARENT, 0, Color.WHITE, 11, 16, dp(48));

        LinearLayout.LayoutParams bToolLp = new LinearLayout.LayoutParams(0, -2, 1.0f);
        bToolLp.setMargins(4, 0, 4, 0);
        btnAddTool.setLayoutParams(bToolLp);
        btnCheckListTool.setLayoutParams(bToolLp);
        btnDrawTool.setLayoutParams(bToolLp);
        btnImageTool.setLayoutParams(bToolLp);
        btnAudioTool.setLayoutParams(bToolLp);

        noteBottomBar.addView(btnAddTool);
        noteBottomBar.addView(btnCheckListTool);
        noteBottomBar.addView(btnDrawTool);
        noteBottomBar.addView(btnImageTool);
        noteBottomBar.addView(btnAudioTool);

        layout.addView(noteBottomBar);
        noteDialog.setContentView(layout);

        btnBackArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = titleInput.getText().toString().trim();
                String content = contentInput.getText().toString().trim();
                if (!title.isEmpty() || !content.isEmpty()) {
                    if (title.isEmpty()) title = content.length() > 20 ? content.substring(0, 20) + "..." : content;
                    currentEditingNote.title = title;
                    currentEditingNote.content = content;
                    itemsList.add(0, currentEditingNote);
                    saveNotesLocally();
                    filterData("");
                    setupMainUI();
                }
                noteDialog.dismiss();
            }
        });

        btnLinkBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLinkBookDialog(btnLinkBook, currentEditingNote);
            }
        });

        btnTag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTagInputDialog(btnTag, currentEditingNote);
            }
        });

        btnAddTool.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSmartToolsDialog(contentInput);
            }
        });

        btnCheckListTool.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contentInput.append("\n[✓] عنصر مهم جديد\n");
            }
        });

        btnDrawTool.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contentInput.append("\n[تمييز ورسم ملاحظة حرة]\n");
            }
        });

        btnImageTool.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activeNoteForImage = currentEditingNote;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                try {
                    startActivityForResult(intent, PICK_NOTE_IMAGE_REQUEST);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذر فتح معرض الصور", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnAudioTool.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActualVoiceRecording(currentEditingNote, contentInput);
            }
        });

        noteDialog.show();
    }

    private void startActualVoiceRecording(final NoteItem note, final EditText contentInput) {
        try {
            final File audioFile = new File(getFilesDir(), "audio_" + System.currentTimeMillis() + ".3gp");
            final MediaRecorder recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            recorder.setOutputFile(audioFile.getAbsolutePath());
            recorder.prepare();
            recorder.start();

            Toast.makeText(this, "🔴 جارٍ التسجيل الصوتي الفعلي...", Toast.LENGTH_SHORT).show();

            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        recorder.stop();
                        recorder.release();
                        note.recordedAudios.add(audioFile.getAbsolutePath());
                        note.hasAudio = true;
                        contentInput.append("\n[▶ تسجيل صوتي مرفق بنجاح]\n");
                        Toast.makeText(MainActivity.this, "✅ تم حفظ التسجيل الصوتي الفعلي بنجاح", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "خطأ في حفظ التسجيل", Toast.LENGTH_SHORT).show();
                    }
                }
            }, 6000);

        } catch (Exception e) {
            Toast.makeText(this, "تعذر بدء التسجيل الصوتي، تحقق من أذونات الميكروفون.", Toast.LENGTH_SHORT).show();
        }
    }

    private void showAlarmManagementScreen() {
        final Dialog alarmDialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(36, 40, 36, 40);
        sheet.setBackgroundColor(0xFF1E293B);

        TextView title = new TextView(this);
        title.setText("منبه دليل والتنبيهات النشطة");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 16);
        sheet.addView(title);

        TextView sub = new TextView(this);
        sub.setText("اختر نغمة التنبيه وحدد وقت التذكير الفعلي:");
        sub.setTextColor(TEXT_MUTED);
        sub.setTextSize(13);
        sub.setPadding(0, 0, 0, 16);
        sheet.addView(sub);

        final String[] ringtones = {"نغمة هادئة (Classic)", "نغمة تنبيه كلاسيكية (Digital)", "نغمة رقمية قوية (Alarm Pro)"};
        final int[] selectedRingtoneIndex = {0};

        for (int i = 0; i < ringtones.length; i++) {
            final int index = i;
            TextView rTv = new TextView(this);
            rTv.setText(ringtones[i]);
            rTv.setTextColor(Color.WHITE);
            rTv.setTextSize(14);
            rTv.setPadding(20, 16, 20, 16);
            GradientDrawable rBg = new GradientDrawable();
            rBg.setColor(0x22FFFFFF);
            rBg.setCornerRadius(16f);
            rTv.setBackground(rBg);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 6, 0, 6);
            rTv.setLayoutParams(lp);

            rTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedRingtoneIndex[0] = index;
                    Toast.makeText(MainActivity.this, "تم اختيار: " + ringtones[index], Toast.LENGTH_SHORT).show();
                }
            });
            sheet.addView(rTv);
        }

        Button btnSetRealAlarm = makeButtonWithThickBorder("تفعيل المنبه الفعلي الآن", FAIENCE_GREEN, 0, Color.WHITE, 13, 20, dp(48));
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, -2);
        btnLp.setMargins(0, 20, 0, 0);
        btnSetRealAlarm.setLayoutParams(btnLp);
        sheet.addView(btnSetRealAlarm);

        btnSetRealAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                    Intent intent = new Intent(MainActivity.this, MainActivity.class);
                    PendingIntent pendingIntent = PendingIntent.getActivity(MainActivity.this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
                    
                    long triggerTime = System.currentTimeMillis() + 60000;
                    if (alarmManager != null) {
                        alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent);
                    }
                    
                    NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Daleel Alerts", NotificationManager.IMPORTANCE_HIGH);
                        notificationManager.createNotificationChannel(channel);
                    }
                    Notification.Builder builder;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        builder = new Notification.Builder(MainActivity.this, CHANNEL_ID);
                    } else {
                        builder = new Notification.Builder(MainActivity.this);
                    }
                    builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                            .setContentTitle("منبه تطبيق دليل")
                            .setContentText("تم ضبط التذكير بنجاح وسيتم إشعارك بالوقت المحدد.")
                            .setPriority(Notification.PRIORITY_HIGH)
                            .setAutoCancel(true);
                    notificationManager.notify(2026, builder.build());

                    Toast.makeText(MainActivity.this, "تم ضبط المنبه الفعلي وإرسال إشعار التأكيد بنجاح", Toast.LENGTH_LONG).show();
                    alarmDialog.dismiss();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "فشل ضبط المنبه في النظام", Toast.LENGTH_SHORT).show();
                }
            }
        });

        alarmDialog.setContentView(sheet);
        alarmDialog.show();
    }

    private void showLinkBookDialog(final Button linkButton, final NoteItem note) {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(36, 40, 36, 40);
        sheet.setBackgroundColor(0xFF221E1A);

        TextView title = new TextView(this);
        title.setText("اربطها بمصدر أو كتاب");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 8);
        sheet.addView(title);

        TextView sub = new TextView(this);
        sub.setText("اكتب اسم الكتاب أو اختر من القائمة أدناه:");
        sub.setTextColor(TEXT_MUTED);
        sub.setTextSize(12);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, 20);
        sheet.addView(sub);

        final EditText customBookInput = new EditText(this);
        customBookInput.setHint("اكتب اسم الكتاب هنا...");
        customBookInput.setTextColor(Color.WHITE);
        customBookInput.setHintTextColor(TEXT_MUTED);
        customBookInput.setBackground(makeGlassDrawable(0x33FFFFFF, GOLD_COLOR, 16, 2));
        customBookInput.setPadding(20, 16, 20, 16);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(-1, -2);
        inputLp.setMargins(0, 0, 0, 16);
        customBookInput.setLayoutParams(inputLp);
        sheet.addView(customBookInput);

        Button btnSaveCustomBook = makeButtonWithThickBorder("اعتماد اسم الكتاب", GOLD_COLOR, 0, Color.WHITE, 13, 16, dp(44));
        sheet.addView(btnSaveCustomBook);

        btnSaveCustomBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String bName = customBookInput.getText().toString().trim();
                if (!bName.isEmpty()) {
                    note.linkedBook = bName;
                    linkButton.setText(bName);
                    dialog.dismiss();
                    Toast.makeText(MainActivity.this, "تم ربط الملاحظة بكتاب: " + bName, Toast.LENGTH_SHORT).show();
                }
            }
        });

        dialog.setContentView(sheet);
        dialog.show();
    }

    private void showTagInputDialog(final Button tagButton, final NoteItem note) {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(36, 40, 36, 40);
        sheet.setBackgroundColor(0xFF221E1A);

        TextView title = new TextView(this);
        title.setText("إضافة وسم للملاحظة");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 20);
        sheet.addView(title);

        final EditText tagInput = new EditText(this);
        tagInput.setHint("اسم الوسم...");
        tagInput.setTextColor(Color.WHITE);
        tagInput.setHintTextColor(TEXT_MUTED);
        tagInput.setBackground(makeGlassDrawable(GLASS_CARD_BG, GOLD_COLOR, 16, 2));
        tagInput.setPadding(20, 16, 20, 16);
        sheet.addView(tagInput);

        Button btnSaveTag = makeButtonWithThickBorder("حفظ الوسم", GOLD_COLOR, 0, Color.WHITE, 13, 20, dp(48));
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, -2);
        btnLp.setMargins(0, 16, 0, 0);
        btnSaveTag.setLayoutParams(btnLp);
        sheet.addView(btnSaveTag);

        btnSaveTag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tName = tagInput.getText().toString().trim();
                if (!tName.isEmpty()) {
                    note.tag = tName;
                    tagButton.setText("# " + tName);
                    dialog.dismiss();
                }
            }
        });

        dialog.setContentView(sheet);
        dialog.show();
    }

    private void showSmartToolsDialog(final EditText contentInput) {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(36, 40, 36, 40);
        sheet.setBackgroundColor(0xFF1E293B);

        TextView title = new TextView(this);
        title.setText("أدوات الذكاء الاصطناعي (AI)");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 8);
        sheet.addView(title);

        TextView sub = new TextView(this);
        sub.setText("تحويل وتوليد أسئلة مراجعة ذكية من نص الملاحظة الحالية:");
        sub.setTextColor(TEXT_MUTED);
        sub.setTextSize(12);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, 20);
        sheet.addView(sub);

        String[] tools = {
            "تحويل النص إلى أسئلة مراجعة ذكية (AI)", 
            "لخّص الملاحظة عبر AI", 
            "إضافة ملخص أسئلة إلى نهاية الملاحظة"
        };

        for (int i = 0; i < tools.length; i++) {
            final int toolIndex = i;
            final String tool = tools[i];
            TextView tTv = new TextView(this);
            tTv.setText(tool);
            tTv.setTextColor(Color.WHITE);
            tTv.setTextSize(14);
            tTv.setPadding(20, 16, 20, 16);
            GradientDrawable tBg = new GradientDrawable();
            tBg.setColor(0x22FFFFFF);
            tBg.setCornerRadius(16f);
            tTv.setBackground(tBg);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 6, 0, 6);
            tTv.setLayoutParams(lp);

            tTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    String noteText = contentInput.getText().toString().trim();
                    if (noteText.isEmpty()) {
                        Toast.makeText(MainActivity.this, "⚠️ ائتِ ببعض النصوص في الملاحظة أولاً لتوليد الأسئلة!", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (toolIndex == 0 || toolIndex == 2) {
                        StringBuilder questionsBuilder = new StringBuilder();
                        questionsBuilder.append("\n\n=== 🧠 أسئلة المراجعة الذكية (توليد تلقائي) ===\n");
                        
                        String[] sentences = noteText.split("[\\.\\n]+");
                        int qNum = 1;
                        for (String sentence : sentences) {
                            String cleanS = sentence.trim();
                            if (cleanS.length() > 5) {
                                if (qNum % 2 == 1) {
                                    questionsBuilder.append("س").append(qNum).append(": ما تفاصيل أو شرح العبارة: \"").append(cleanS).append("\"؟\n");
                                } else {
                                    questionsBuilder.append("س").append(qNum).append(": اذكر الأهمية أو الدلالة المتعلقة بـ: \"").append(cleanS).append("\"؟\n");
                                }
                                qNum++;
                            }
                        }
                        if (qNum == 1) {
                            questionsBuilder.append("س1: اشرح الفكرة الرئيسية الواردة في الملاحظة؟\n");
                        }

                        if (toolIndex == 2) {
                            contentInput.append(questionsBuilder.toString());
                            Toast.makeText(MainActivity.this, "✅ تمت إضافة أسئلة المراجعة الذكية إلى نهاية الملاحظة", Toast.LENGTH_LONG).show();
                        } else {
                            showGeneratedQuestionsDialog(questionsBuilder.toString());
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "✨ تم تلخيص الملاحظة بنجاح عبر خوارزميات AI", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            sheet.addView(tTv);
        }

        dialog.setContentView(sheet);
        dialog.show();
    }

    private void showGeneratedQuestionsDialog(final String generatedQuestions) {
        final Dialog qDialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(36, 40, 36, 40);
        sheet.setBackgroundColor(0xFF1E293B);

        TextView title = new TextView(this);
        title.setText("🧠 أسئلة المراجعة الذكية المُولّدة");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 16);
        sheet.addView(title);

        ScrollView sv = new ScrollView(this);
        TextView qContent = new TextView(this);
        qContent.setText(generatedQuestions);
        qContent.setTextColor(0xFFE2E8F0);
        qContent.setTextSize(14);
        qContent.setTypeface(currentTypeface);
        sv.addView(qContent);
        sheet.addView(sv, new LinearLayout.LayoutParams(-1, 800));

        Button btnCopyOrAdd = makeButtonWithThickBorder("نسخ الأسئلة للحافظة", FAIENCE_GREEN, 0, Color.WHITE, 13, 20, dp(48));
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, -2);
        btnLp.setMargins(0, 16, 0, 0);
        btnCopyOrAdd.setLayoutParams(btnLp);
        sheet.addView(btnCopyOrAdd);

        btnCopyOrAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("Smart Questions", generatedQuestions);
                if (clipboard != null) clipboard.setPrimaryClip(clip);
                Toast.makeText(MainActivity.this, "تم نسخ الأسئلة للحافظة بنجاح", Toast.LENGTH_SHORT).show();
                qDialog.dismiss();
            }
        });

        qDialog.setContentView(sheet);
        qDialog.show();
    }

    private static class PublicStoreBook {
        public String title;
        public String subtitle;
        public String content;
        public String itemType;
        public String fileSize;

        public PublicStoreBook(String title, String subtitle, String content, String itemType, String fileSize) {
            this.title = title;
            this.subtitle = subtitle;
            this.content = content;
            this.itemType = itemType;
            this.fileSize = fileSize;
        }
    }

    private void loadPublicStoreBooks() {
        publicStoreList.clear();
        publicStoreList.add(new PublicStoreBook(
            "موسوعة التراث الإسلامي",
            "إصدار خاص - دليل",
            "تتضمن هذه الموسوعة أهم المراجع والمخطوطات التراثية التي تمت جدولتها وأرشفتها لتكون في متناول الباحثين والمستخدمين دائماً وبدون انترنت.",
            "مخطوط",
            "5.2 م.ب"
        ));
        publicStoreList.add(new PublicStoreBook(
            "دليل قواعد البرمجة الحديثة",
            "إصدار الأندرويد المتقدم",
            "كتاب شامل يعرس أساسيات وتطبيقات البرمجة بلغات جافا وكتلن وكيفية بناء التطبيقات الذكية بجودة عالية واحترافية.",
            "كتاب",
            "3.1 م.ب"
        ));

        try {
            File f = new File(getFilesDir(), PUBLIC_STORE_FILE);
            if (f.exists()) {
                FileInputStream fis = openFileInput(PUBLIC_STORE_FILE);
                byte[] buf = new byte[(int) fis.available()];
                fis.read(buf);
                fis.close();
                String[] books = new String(buf, "UTF-8").split("\n---\n");
                for (String bStr : books) {
                    String[] p = bStr.split("\\|\\|\\|");
                    if (p.length >= 5) {
                        publicStoreList.add(new PublicStoreBook(p[0], p[1], p[2], p[3], p[4]));
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private void savePublicStoreBooks() {
        try {
            StringBuilder sb = new StringBuilder();
            for (int i = 2; i < publicStoreList.size(); i++) {
                PublicStoreBook sbItem = publicStoreList.get(i);
                sb.append(sbItem.title).append("|||")
                  .append(sbItem.subtitle).append("|||")
                  .append(sbItem.content).append("|||")
                  .append(sbItem.itemType).append("|||")
                  .append(sbItem.fileSize)
                  .append("\n---\n");
            }
            FileOutputStream fos = openFileOutput(PUBLIC_STORE_FILE, Context.MODE_PRIVATE);
            fos.write(sb.toString().getBytes("UTF-8"));
            fos.close();
        } catch (Exception ignored) {}
    }

    private void showDaleelLibraryStoreDialog() {
        final Dialog storeDialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_Fullscreen);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(OLED_BG_END);
        root.setPadding(24, 20, 24, 20);

        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(16, 12, 16, 12);
        topBar.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 24, 2));

        TextView title = new TextView(this);
        title.setText("📚 مكتبة دليل العامة (تحميل وإضافة فورية)");
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(15);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        topBar.addView(title, new LinearLayout.LayoutParams(0, -2, 1.0f));

        SharedPreferences prefs = getSharedPreferences("DaleelUserProfile", MODE_PRIVATE);
        boolean isOwner = prefs.getBoolean("is_daleel_owner", false);

        if (isOwner) {
            Button btnAddOwnerBook = makeGlassButton("+ إضافة كتاب", FAIENCE_GREEN, 0, Color.WHITE, 11, 12);
            btnAddOwnerBook.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    storeDialog.dismiss();
                    showOwnerAddBookDialog();
                }
            });
            topBar.addView(btnAddOwnerBook);
        }

        Button btnClose = makeGlassButton("إغلاق", Color.TRANSPARENT, 0, TEXT_PRIMARY, 11, 12);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { storeDialog.dismiss(); }
        });
        topBar.addView(btnClose);
        root.addView(topBar);

        ScrollView scrollView = new ScrollView(this);
        final LinearLayout storeContainer = new LinearLayout(this);
        storeContainer.setOrientation(LinearLayout.VERTICAL);
        storeContainer.setPadding(0, 16, 0, 20);

        for (int i = 0; i < publicStoreList.size(); i++) {
            final PublicStoreBook storeBook = publicStoreList.get(i);
            
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(24, 20, 24, 20);
            GradientDrawable cBg = new GradientDrawable();
            cBg.setColor(GLASS_CARD_BG);
            cBg.setCornerRadius(24f);
            cBg.setStroke(2, FAIENCE_GREEN);
            card.setBackground(cBg);
            LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(-1, -2);
            cLp.setMargins(0, 10, 0, 10);
            card.setLayoutParams(cLp);

            TextView tTv = new TextView(this);
            tTv.setText(storeBook.title);
            tTv.setTextColor(TEXT_PRIMARY);
            tTv.setTextSize(16);
            tTv.setTypeface(currentTypeface, Typeface.BOLD);
            card.addView(tTv);

            TextView subTv = new TextView(this);
            subTv.setText(storeBook.subtitle + " | الحجم: " + storeBook.fileSize);
            subTv.setTextColor(LILAC_SOFT);
            subTv.setTextSize(12);
            subTv.setPadding(0, 4, 0, 8);
            card.addView(subTv);

            TextView descTv = new TextView(this);
            descTv.setText(storeBook.content);
            descTv.setTextColor(TEXT_MUTED);
            descTv.setTextSize(13);
            descTv.setPadding(0, 0, 0, 14);
            card.addView(descTv);

            Button btnDownloadAndAdd = makeButtonWithThickBorder("📥 تحميل فوري وإضافة لمكتبتي", FAIENCE_GREEN, 0, Color.WHITE, 12, 16, dp(44));
            btnDownloadAndAdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    NoteItem newItem = new NoteItem(
                        storeBook.title,
                        storeBook.content,
                        getDate(),
                        storeBook.itemType
                    );
                    newItem.subtitle = storeBook.subtitle;
                    newItem.category = "المكتبة";
                    newItem.isSaved = true;
                    newItem.fileSizeInfo = storeBook.fileSize;
                    newItem.fileTypeInfo = "كتاب عام";

                    itemsList.add(0, newItem);
                    saveNotesLocally();
                    filterData("");
                    setupMainUI();
                    Toast.makeText(MainActivity.this, "✅ تم تحميل وإضافة الكتاب لمكتبتك بنجاح وبقى محفوظاً!", Toast.LENGTH_LONG).show();
                    storeDialog.dismiss();
                }
            });
            card.addView(btnDownloadAndAdd);
            storeContainer.addView(card);
        }

        scrollView.addView(storeContainer);
        root.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        storeDialog.setContentView(root);
        storeDialog.show();
    }

    private void showOwnerVerificationDialog() {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(36, 40, 36, 40);
        sheet.setBackgroundColor(OLED_BG_END);

        TextView title = new TextView(this);
        title.setText("🔑 التحقق من هوية المالك");
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(18);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 12);
        sheet.addView(title);

        TextView sub = new TextView(this);
        sub.setText("أدخل رمز التوثيق لتفعيل صلاحيات الإدارة وإنشاء الكتب:");
        sub.setTextColor(TEXT_MUTED);
        sub.setTextSize(13);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, 20);
        sheet.addView(sub);

        final EditText pinInput = new EditText(this);
        pinInput.setHint("أدخل رمز التوثيق هنا...");
        pinInput.setTextColor(TEXT_PRIMARY);
        pinInput.setHintTextColor(TEXT_MUTED);
        pinInput.setBackground(makeGlassDrawable(GLASS_CARD_BG, GOLD_COLOR, 16, 2));
        pinInput.setPadding(20, 16, 20, 16);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(-1, -2);
        inputLp.setMargins(0, 0, 0, 20);
        pinInput.setLayoutParams(inputLp);
        sheet.addView(pinInput);

        Button btnVerify = makeButtonWithThickBorder("تحقق ودخول", GOLD_COLOR, 0, 0xFF1B1407, 13, 20, dp(48));
        sheet.addView(btnVerify);

        btnVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String code = pinInput.getText().toString().trim();
                if (code.equals("33002007")) {
                    SharedPreferences prefs = getSharedPreferences("DaleelUserProfile", MODE_PRIVATE);
                    prefs.edit().putBoolean("is_daleel_owner", true).apply();
                    Toast.makeText(MainActivity.this, "✅ تم التحقق بنجاح! تم تفعيل صلاحيات إنشاء الكتب في تبويب الكتب.", Toast.LENGTH_LONG).show();
                    dialog.dismiss();
                    setupMainUI(); 
                } else {
                    Toast.makeText(MainActivity.this, "❌ رمز التوثيق غير صحيح.", Toast.LENGTH_LONG).show();
                }
            }
        });

        dialog.setContentView(sheet);
        dialog.show();
    }

    private void showOwnerAddBookDialog() {
        final Dialog addDialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(36, 40, 36, 40);
        sheet.setBackgroundColor(OLED_BG_END);

        TextView title = new TextView(this);
        title.setText("✍️ إنشاء كتاب جديد (صلاحيات المالك)");
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(17);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 16);
        sheet.addView(title);

        ScrollView sv = new ScrollView(this);
        LinearLayout contentLayout = new LinearLayout(this);
        contentLayout.setOrientation(LinearLayout.VERTICAL);

        final EditText titleInput = new EditText(this);
        titleInput.setHint("عنوان الكتاب...");
        titleInput.setTextColor(TEXT_PRIMARY);
        titleInput.setHintTextColor(TEXT_MUTED);
        titleInput.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 16, 2));
        titleInput.setPadding(20, 16, 20, 16);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, 12);
        titleInput.setLayoutParams(lp);
        contentLayout.addView(titleInput);

        final EditText subInput = new EditText(this);
        subInput.setHint("الوصف الفرعي أو الجزء...");
        subInput.setTextColor(TEXT_PRIMARY);
        subInput.setHintTextColor(TEXT_MUTED);
        subInput.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 16, 2));
        subInput.setPadding(20, 16, 20, 16);
        subInput.setLayoutParams(lp);
        contentLayout.addView(subInput);

        final EditText descInput = new EditText(this);
        descInput.setHint("محتوى الكتاب أو تفاصيله كاملة...");
        descInput.setTextColor(TEXT_PRIMARY);
        descInput.setHintTextColor(TEXT_MUTED);
        descInput.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 16, 2));
        descInput.setPadding(20, 16, 20, 16);
        descInput.setMinLines(5);
        descInput.setLayoutParams(lp);
        contentLayout.addView(descInput);

        sv.addView(contentLayout);
        sheet.addView(sv, new LinearLayout.LayoutParams(-1, 800));

        Button btnSavePublicBook = makeButtonWithThickBorder("نشر وإضافة الكتاب للمكتبة العامة", FAIENCE_GREEN, 0, Color.WHITE, 13, 20, dp(48));
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, -2);
        btnLp.setMargins(0, 16, 0, 0);
        btnSavePublicBook.setLayoutParams(btnLp);
        sheet.addView(btnSavePublicBook);

        btnSavePublicBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String bTitle = titleInput.getText().toString().trim();
                String bSub = subInput.getText().toString().trim();
                String bDesc = descInput.getText().toString().trim();

                if (!bTitle.isEmpty() && !bDesc.isEmpty()) {
                    PublicStoreBook newStoreBook = new PublicStoreBook(bTitle, bSub.isEmpty() ? "إصدار المالك" : bSub, bDesc, "كتاب", "4.0 م.ب");
                    publicStoreList.add(newStoreBook);
                    savePublicStoreBooks();

                    NoteItem newAppBook = new NoteItem(bTitle, bDesc, getDate(), "كتاب");
                    newAppBook.subtitle = bSub.isEmpty() ? "إصدار المالك" : bSub;
                    newAppBook.category = "المكتبة";
                    newAppBook.isSaved = true;
                    newAppBook.fileSizeInfo = "4.0 م.ب";
                    newAppBook.fileTypeInfo = "كتاب";
                    itemsList.add(0, newAppBook);
                    saveNotesLocally();

                    Toast.makeText(MainActivity.this, "🎉 تم إنشاء الكتاب بنجاح وأصبح محفوظاً وفي متناول المستخدمين!", Toast.LENGTH_LONG).show();
                    addDialog.dismiss();
                    currentFilterTab = "الكتب";
                    setupMainUI();
                } else {
                    Toast.makeText(MainActivity.this, "⚠️ يرجى ملء عنوان الكتاب ومحتواه على الأقل", Toast.LENGTH_SHORT).show();
                }
            }
        });

        addDialog.setContentView(sheet);
        addDialog.show();
    }

    private void showCloudStorageDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 36, 36, 36);
        layout.setBackgroundColor(OLED_BG_END);

        TextView title = new TextView(this);
        title.setText("السحابة التخزينية المرتبطة بدليل");
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(16);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setPadding(0, 0, 0, 16);
        layout.addView(title);

        int syncedCount = 0;
        for (NoteItem item : itemsList) {
            if (item.isSyncedToCloud) syncedCount++;
        }

        TextView info = new TextView(this);
        info.setText("إجمالي المستندات: " + itemsList.size() + "\nالمستندات المتزامنة مع السحابة: " + syncedCount);
        info.setTextColor(LILAC_SOFT);
        info.setTextSize(13);
        info.setPadding(0, 0, 0, 20);
        layout.addView(info);

        Button btnSyncAll = makeButtonWithThickBorder("مزامنة ورفع الكل للسحابة", 0xFF3B82F6, GLASS_BORDER, Color.WHITE, 13, 16, dp(48));
        Button btnRestore = makeButtonWithThickBorder("استرجاع الملفات من السحابة", 0xFF2FBF9F, GLASS_BORDER, Color.WHITE, 13, 16, dp(48));

        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, -2);
        btnLp.setMargins(0, 8, 0, 8);
        btnSyncAll.setLayoutParams(btnLp);
        btnRestore.setLayoutParams(btnLp);

        layout.addView(btnSyncAll);
        layout.addView(btnRestore);

        final AlertDialog cloudDialog = new AlertDialog.Builder(this)
                .setView(layout)
                .setNegativeButton("إغلاق", null)
                .create();

        btnSyncAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (NoteItem item : itemsList) {
                    item.isSyncedToCloud = true;
                }
                saveNotesLocally();
                Toast.makeText(MainActivity.this, "تمت مزامنة جميع ملفات المكتبة بنجاح", Toast.LENGTH_SHORT).show();
                cloudDialog.dismiss();
            }
        });

        btnRestore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "السحابة متصلة، تم استرجاع البيانات المحدثة.", Toast.LENGTH_SHORT).show();
                cloudDialog.dismiss();
            }
        });

        cloudDialog.show();
    }

    private void showAddLinkDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 36, 36, 36);
        layout.setBackgroundColor(OLED_BG_END);

        TextView titleTv = new TextView(this);
        titleTv.setText("إضافة رابط مرجعي جديد");
        titleTv.setTextColor(TEXT_PRIMARY);
        titleTv.setTextSize(16);
        titleTv.setTypeface(currentTypeface, Typeface.BOLD);
        titleTv.setPadding(0, 0, 0, 16);
        layout.addView(titleTv);

        final EditText titleInput = new EditText(this);
        titleInput.setHint("عنوان الرابط...");
        titleInput.setTextColor(TEXT_PRIMARY);
        titleInput.setHintTextColor(TEXT_MUTED);
        titleInput.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 20, 2));
        titleInput.setPadding(24, 18, 24, 18);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, 16);
        titleInput.setLayoutParams(lp);
        layout.addView(titleInput);

        final EditText urlInput = new EditText(this);
        urlInput.setHint("https://...");
        urlInput.setTextColor(TEXT_PRIMARY);
        urlInput.setHintTextColor(TEXT_MUTED);
        urlInput.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 20, 2));
        urlInput.setPadding(24, 18, 24, 18);
        urlInput.setLayoutParams(lp);
        layout.addView(urlInput);

        new AlertDialog.Builder(this)
                .setView(layout)
                .setPositiveButton("إضافة", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String title = titleInput.getText().toString().trim();
                        String url = urlInput.getText().toString().trim();
                        if (title.isEmpty()) title = "رابط مهم";
                        if (!url.startsWith("http")) url = "https://" + url;

                        NoteItem linkItem = new NoteItem(
                                title,
                                "رابط مرجعي: " + url,
                                getDate(),
                                "كتاب"
                        );
                        linkItem.fileTypeInfo = "رابط إلكتروني";
                        linkItem.isSaved = true;
                        itemsList.add(0, linkItem);
                        saveNotesLocally();
                        filterData("");
                        setupMainUI();
                        Toast.makeText(MainActivity.this, "تمت إضافة الرابط بنجاح", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private String dayKey(int daysAgo) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, -daysAgo);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    private int getSecondsReadOn(int daysAgo) {
        return getSharedPreferences(READ_PREFS, MODE_PRIVATE).getInt("sec_" + dayKey(daysAgo), 0);
    }

    private int getDailyGoalMinutes() {
        return getSharedPreferences(READ_PREFS, MODE_PRIVATE).getInt("daily_goal_min", 10);
    }

    private int computeStreak() {
        int goalSec = getDailyGoalMinutes() * 60;
        int day = (getSecondsReadOn(0) >= goalSec) ? 0 : 1;
        int streak = 0;
        while (day < 3650 && getSecondsReadOn(day) >= goalSec) {
            streak++;
            day++;
        }
        return streak;
    }

    private int updateAndGetBestStreak(int currentStreak) {
        SharedPreferences p = getSharedPreferences(READ_PREFS, MODE_PRIVATE);
        int best = p.getInt("best_streak", 0);
        if (currentStreak > best) {
            best = currentStreak;
            p.edit().putInt("best_streak", best).apply();
        }
        return best;
    }

    private String arabicMinutes(int n) {
        if (n == 1) return "دقيقة واحدة";
        if (n == 2) return "دقيقتان";
        if (n >= 3 && n <= 10) return n + " دقائق";
        return n + " دقيقة";
    }

    private void showGoalDialog() {
        final int[] options = {5, 10, 15, 20, 30};
        CharSequence[] labels = new CharSequence[options.length];
        for (int i = 0; i < options.length; i++) {
            labels[i] = arabicMinutes(options[i]) + (options[i] == getDailyGoalMinutes() ? "   ✓" : "");
        }
        new AlertDialog.Builder(this)
                .setTitle("الهدف اليومي للقراءة")
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        getSharedPreferences(READ_PREFS, MODE_PRIVATE).edit().putInt("daily_goal_min", options[which]).apply();
                        setupMainUI();
                    }
                })
                .show();
    }

    private View buildStreakCard() {
        int streak = computeStreak();
        int best = updateAndGetBestStreak(streak);
        int goalMin = getDailyGoalMinutes();
        int goalSec = goalMin * 60;
        int minsToday = getSecondsReadOn(0) / 60;

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(16));
        card.setBackground(makeGlassDrawable(GLASS_CARD_BG, GOLD_COLOR, dp(24), 2));
        card.setElevation(6f);

        TextView title = new TextView(this);
        title.setText("سلسلة القراءة");
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(16);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        card.addView(title);

        LinearLayout numRow = new LinearLayout(this);
        numRow.setOrientation(LinearLayout.HORIZONTAL);
        numRow.setGravity(Gravity.CENTER_VERTICAL);
        numRow.setPadding(0, dp(8), 0, dp(12));

        TextView num = new TextView(this);
        num.setText(String.valueOf(streak));
        num.setTextColor(GOLD_COLOR);
        num.setTextSize(38);
        num.setTypeface(currentTypeface, Typeface.BOLD);
        numRow.addView(num);

        TextView unit = new TextView(this);
        unit.setText("  يوم متتالية");
        unit.setTextColor(TEXT_MUTED);
        unit.setTextSize(13);
        numRow.addView(unit);

        View spacer = new View(this);
        numRow.addView(spacer, new LinearLayout.LayoutParams(0, 0, 1.0f));

        LinearLayout bestCol = new LinearLayout(this);
        bestCol.setOrientation(LinearLayout.VERTICAL);
        bestCol.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView bestLabel = new TextView(this);
        bestLabel.setText("أفضل سلسلة");
        bestLabel.setTextColor(TEXT_MUTED);
        bestLabel.setTextSize(11);
        bestCol.addView(bestLabel);

        TextView bestVal = new TextView(this);
        bestVal.setText(best + " يوم");
        bestVal.setTextColor(TEXT_PRIMARY);
        bestVal.setTextSize(15);
        bestVal.setTypeface(currentTypeface, Typeface.BOLD);
        bestCol.addView(bestVal);
        numRow.addView(bestCol);

        card.addView(numRow);

        String[] letters = {"س", "ح", "ن", "ث", "ر", "خ", "ج"};
        int dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK);
        int offset = dow % 7;

        LinearLayout week = new LinearLayout(this);
        week.setOrientation(LinearLayout.HORIZONTAL);
        week.setWeightSum(7f);

        for (int i = 0; i < 7; i++) {
            int daysAgo = offset - i;
            boolean future = daysAgo < 0;
            boolean isToday = daysAgo == 0;
            boolean met = !future && getSecondsReadOn(daysAgo) >= goalSec;

            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);

            TextView dot = new TextView(this);
            dot.setGravity(Gravity.CENTER);
            dot.setTextSize(14);
            GradientDrawable dotBg = new GradientDrawable();
            dotBg.setShape(GradientDrawable.OVAL);
            if (met) {
                dotBg.setColor(FAIENCE_GREEN);
                dot.setText("✓");
                dot.setTextColor(Color.WHITE);
                dot.setTypeface(currentTypeface, Typeface.BOLD);
            } else {
                dotBg.setColor(Color.TRANSPARENT);
                dotBg.setStroke(dp(2), isToday ? GOLD_COLOR : TRACK_COLOR);
            }
            dot.setBackground(dotBg);
            cell.addView(dot, new LinearLayout.LayoutParams(dp(32), dp(32)));

            TextView letter = new TextView(this);
            letter.setText(letters[i]);
            letter.setTextSize(12);
            letter.setTextColor(isToday ? TEXT_PRIMARY : TEXT_MUTED);
            if (isToday) letter.setTypeface(currentTypeface, Typeface.BOLD);
            letter.setPadding(0, dp(4), 0, 0);
            cell.addView(letter);

            week.addView(cell, new LinearLayout.LayoutParams(0, -2, 1.0f));
        }
        card.addView(week);

        TextView foot = new TextView(this);
        foot.setText("اليوم: " + minsToday + " من " + arabicMinutes(goalMin));
        foot.setTextColor(TEXT_MUTED);
        foot.setTextSize(12);
        foot.setPadding(0, dp(12), 0, 0);
        card.addView(foot);

        return card;
    }

    private View buildSunriseCard() {
        final int goalMin = getDailyGoalMinutes();
        int goalSec = goalMin * 60;
        int secToday = getSecondsReadOn(0);
        int minsToday = secToday / 60;
        boolean done = secToday >= goalSec;
        float target = Math.min(1f, secToday / (float) goalSec);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(18), dp(16), dp(14));
        card.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, dp(28), 2));
        card.setElevation(6f);

        SunriseGaugeView gauge = new SunriseGaugeView(this, currentTypeface, TRACK_COLOR, GOLD_COLOR, TEXT_PRIMARY, TEXT_MUTED);
        gauge.setLabels(String.valueOf(minsToday), done ? "أنجزت هدف اليوم" : "من " + arabicMinutes(goalMin));
        gauge.setProgressImmediate(lastShownGoalProgress < 0f ? 0f : lastShownGoalProgress);
        card.addView(gauge, new LinearLayout.LayoutParams(-1, -2));
        gauge.animateTo(target);
        lastShownGoalProgress = target;

        TextView msg = new TextView(this);
        if (done) {
            msg.setText("أحسنت! أنجزت هدف اليوم");
        } else {
            int remainingMin = (int) Math.ceil((goalSec - secToday) / 60.0);
            msg.setText("باقي " + arabicMinutes(remainingMin) + " لهدف اليوم");
        }
        msg.setTextColor(TEXT_PRIMARY);
        msg.setTextSize(15);
        msg.setTypeface(currentTypeface, Typeface.BOLD);
        msg.setGravity(Gravity.CENTER);
        msg.setPadding(0, dp(8), 0, 0);
        card.addView(msg);

        TextView hint = new TextView(this);
        hint.setText("المس لتغيير الهدف اليومي");
        hint.setTextColor(TEXT_MUTED);
        hint.setTextSize(11);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(4), 0, 0);
        card.addView(hint);

        card.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showGoalDialog(); }
        });
        return card;
    }

    private void showAdminLoginOrDashboard() {
        SharedPreferences prefs = getSharedPreferences(ADMIN_PREFS, MODE_PRIVATE);
        if (prefs.getBoolean("admin_authenticated", false)) {
            showAdminDashboard();
            return;
        }

        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(36, 28, 36, 18);
        box.setBackground(makeGlassDrawable(GLASS_CARD_BG, 0x66EF4444, 28, 2));

        TextView title = new TextView(this);
        title.setText("🛡 دخول المشرف");
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        box.addView(title);

        TextView hint = new TextView(this);
        hint.setText("أدخل عنوان REST API ورمز المشرف. يمكن استخدام اللوحة محلياً حتى دون اتصال.");
        hint.setTextColor(TEXT_MUTED);
        hint.setTextSize(12);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 12, 0, 18);
        box.addView(hint);

        final EditText apiUrlInput = new EditText(this);
        apiUrlInput.setHint("https://example.com/api");
        apiUrlInput.setSingleLine(true);
        apiUrlInput.setText(getSharedPreferences(ADMIN_PREFS, MODE_PRIVATE).getString("api_base_url", ""));
        apiUrlInput.setTextColor(TEXT_PRIMARY);
        apiUrlInput.setHintTextColor(TEXT_MUTED);
        apiUrlInput.setBackground(makeGlassDrawable(0x33111827, GLASS_BORDER, 14, 1));
        apiUrlInput.setPadding(18, 12, 18, 12);
        box.addView(apiUrlInput);

        final EditText tokenInput = new EditText(this);
        tokenInput.setHint("رمز Bearer / Admin Token");
        tokenInput.setSingleLine(true);
        tokenInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        tokenInput.setText(getSharedPreferences(ADMIN_PREFS, MODE_PRIVATE).getString("admin_token", ""));
        tokenInput.setTextColor(TEXT_PRIMARY);
        tokenInput.setHintTextColor(TEXT_MUTED);
        tokenInput.setBackground(makeGlassDrawable(0x33111827, GLASS_BORDER, 14, 1));
        tokenInput.setPadding(18, 12, 18, 12);
        LinearLayout.LayoutParams tokenLp = new LinearLayout.LayoutParams(-1, -2);
        tokenLp.setMargins(0, 12, 0, 0);
        box.addView(tokenInput, tokenLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, 20, 0, 0);
        Button localButton = makeButtonWithThickBorder("دخول محلي", 0x553B82F6, GLASS_BORDER, TEXT_PRIMARY, 12, 16, dp(46));
        Button connectButton = makeButtonWithThickBorder("حفظ والاتصال", 0x55EF4444, 0x66EF4444, TEXT_PRIMARY, 12, 16, dp(46));
        actions.addView(localButton, new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams connectLp = new LinearLayout.LayoutParams(0, -2, 1f);
        connectLp.setMargins(8, 0, 0, 0);
        actions.addView(connectButton, connectLp);
        box.addView(actions);

        final AlertDialog dialog = new AlertDialog.Builder(this).setView(box).setNegativeButton("إلغاء", null).create();
        localButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                getSharedPreferences(ADMIN_PREFS, MODE_PRIVATE).edit().putBoolean("admin_authenticated", true).apply();
                dialog.dismiss();
                showAdminDashboard();
            }
        });
        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String baseUrl = apiUrlInput.getText().toString().trim();
                String token = tokenInput.getText().toString().trim();
                if (baseUrl.isEmpty() || token.isEmpty()) {
                    Toast.makeText(MainActivity.this, "أدخل عنوان API والرمز أولاً", Toast.LENGTH_SHORT).show();
                    return;
                }
                getSharedPreferences(ADMIN_PREFS, MODE_PRIVATE).edit()
                        .putString("api_base_url", normalizeAdminUrl(baseUrl))
                        .putString("admin_token", token)
                        .putBoolean("admin_authenticated", true).apply();
                dialog.dismiss();
                showAdminDashboard();
                syncAdminDashboardFromApi();
            }
        });
        dialog.show();
    }

    private String normalizeAdminUrl(String value) {
        String result = value == null ? "" : value.trim();
        while (result.endsWith("/")) result = result.substring(0, result.length() - 1);
        return result;
    }

    private void showAdminDashboard() {
        if (rootContainer == null) return;
        rootContainer.removeAllViews();
        rootContainer.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{OLED_BG_START, OLED_BG_END}));
        rootContainer.setLayoutDirection("en".equals(currentAppLanguage) ? View.LAYOUT_DIRECTION_LTR : View.LAYOUT_DIRECTION_RTL);

        final LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setPadding(24, 32, 24, dp(100));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(18, 14, 18, 14);
        header.setBackground(makeGlassDrawable(GLASS_CARD_BG, 0x66EF4444, 24, 2));
        TextView title = new TextView(this);
        title.setText("لوحة تحكم المشرف");
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(19);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        Button sync = makeButtonWithThickBorder("مزامنة", 0x553B82F6, GLASS_BORDER, TEXT_PRIMARY, 11, 14, dp(42));
        sync.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { syncAdminDashboardFromApi(); } });
        header.addView(sync);
        Button logout = makeButtonWithThickBorder("خروج", 0x55EF4444, 0x66EF4444, TEXT_PRIMARY, 11, 14, dp(42));
        logout.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                getSharedPreferences(ADMIN_PREFS, MODE_PRIVATE).edit().putBoolean("admin_authenticated", false).apply();
                setupMainUI();
            }
        });
        LinearLayout.LayoutParams logoutLp = new LinearLayout.LayoutParams(-2, -2);
        logoutLp.setMargins(8, 0, 0, 0);
        header.addView(logout, logoutLp);
        screen.addView(header);

        TextView status = new TextView(this);
        status.setText(getAdminConnectionStatus());
        status.setTextColor(TEXT_MUTED);
        status.setTextSize(11);
        status.setPadding(8, 10, 8, 10);
        screen.addView(status);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        String[][] tabData = {{"overview", "الإحصائيات"}, {"users", "المستخدمون"}, {"books", "الكتب"}, {"reports", "البلاغات"}, {"notifications", "الإشعارات"}};
        for (final String[] tab : tabData) {
            Button tabButton = makeButtonWithThickBorder(tab[1], adminActiveSection.equals(tab[0]) ? NEON_BLUE : GLASS_CARD_BG, GLASS_BORDER, TEXT_PRIMARY, 10, 14, dp(44));
            tabButton.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { adminActiveSection = tab[0]; showAdminDashboard(); }
            });
            LinearLayout.LayoutParams tabLp = new LinearLayout.LayoutParams(0, -2, 1f);
            tabLp.setMargins(3, 0, 3, 0);
            tabs.addView(tabButton, tabLp);
        }
        screen.addView(tabs);

        ScrollView bodyScroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(0, 16, 0, 0);
        if ("overview".equals(adminActiveSection)) buildAdminOverview(body);
        else if ("users".equals(adminActiveSection)) buildAdminUsers(body);
        else if ("books".equals(adminActiveSection)) buildAdminBooks(body);
        else if ("reports".equals(adminActiveSection)) buildAdminReports(body);
        else buildAdminNotifications(body);
        bodyScroll.addView(body);
        screen.addView(bodyScroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        rootContainer.addView(screen);
    }

    private String getAdminConnectionStatus() {
        SharedPreferences p = getSharedPreferences(ADMIN_PREFS, MODE_PRIVATE);
        String url = p.getString("api_base_url", "");
        return url.isEmpty() ? "وضع محلي: البيانات محفوظة على الجهاز" : "REST API: " + url + " | آخر تحديث: " + p.getString("last_sync", "لم تتم المزامنة");
    }

    private TextView adminSectionLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(TEXT_PRIMARY);
        tv.setTextSize(16);
        tv.setTypeface(currentTypeface, Typeface.BOLD);
        tv.setPadding(4, 10, 4, 10);
        return tv;
    }

    private void buildAdminOverview(LinearLayout body) {
        body.addView(adminSectionLabel("نظرة عامة على الاستخدام"));
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(makeStatCard("المستخدمون", String.valueOf(adminDashboardData.users.size()), NEON_BLUE), new LinearLayout.LayoutParams(0, -2, 1f));
        row1.addView(makeStatCard("الكتب", String.valueOf(adminDashboardData.books.size()), FAIENCE_GREEN), new LinearLayout.LayoutParams(0, -2, 1f));
        row1.addView(makeStatCard("البلاغات", String.valueOf(adminDashboardData.reports.size()), 0xFFEF4444), new LinearLayout.LayoutParams(0, -2, 1f));
        body.addView(row1);
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(makeStatCard("القراءات", String.valueOf(adminDashboardData.totalReads), GOLD_COLOR), new LinearLayout.LayoutParams(0, -2, 1f));
        row2.addView(makeStatCard("النشطون اليوم", String.valueOf(adminDashboardData.activeToday), PURPLE_COLOR), new LinearLayout.LayoutParams(0, -2, 1f));
        row2.addView(makeStatCard("الإشعارات", String.valueOf(adminDashboardData.notifications.size()), LILAC_SOFT), new LinearLayout.LayoutParams(0, -2, 1f));
        body.addView(row2);
        body.addView(adminInfoCard("حالة البيانات", adminDashboardData.fromApi ? "تم تحميل البيانات من REST API" : "بيانات محلية / وضع عدم الاتصال"));
    }

    private void buildAdminUsers(LinearLayout body) {
        body.addView(adminSectionLabel("إدارة المستخدمين (" + adminDashboardData.users.size() + ")"));
        if (adminDashboardData.users.isEmpty()) body.addView(adminInfoCard("لا توجد بيانات", "نفّذ المزامنة أو أضف مستخدمين من الخادم."));
        for (final AdminUser user : adminDashboardData.users) {
            LinearLayout card = adminListCard(user.name, user.email, user.active ? "نشط" : "موقوف", user.active ? FAIENCE_GREEN : 0xFFEF4444);
            Button action = makeButtonWithThickBorder(user.active ? "إيقاف" : "تفعيل", Color.TRANSPARENT, GLASS_BORDER, TEXT_PRIMARY, 10, 12, dp(38));
            action.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { user.active = !user.active; saveAdminDashboardCache(); showAdminDashboard(); } });
            card.addView(action);
            body.addView(card);
        }
    }

    private void buildAdminBooks(LinearLayout body) {
        body.addView(adminSectionLabel("إدارة الكتب (" + adminDashboardData.books.size() + ")"));
        for (final AdminBook book : adminDashboardData.books) {
            LinearLayout card = adminListCard(book.title, book.author, book.published ? "منشور" : "مسودة", book.published ? FAIENCE_GREEN : GOLD_COLOR);
            Button action = makeButtonWithThickBorder(book.published ? "إلغاء النشر" : "نشر", Color.TRANSPARENT, GLASS_BORDER, TEXT_PRIMARY, 10, 12, dp(38));
            action.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { book.published = !book.published; saveAdminDashboardCache(); showAdminDashboard(); } });
            card.addView(action);
            body.addView(card);
        }
        Button add = makeButtonWithThickBorder("+ إضافة كتاب محلياً", 0x553B82F6, GLASS_BORDER, TEXT_PRIMARY, 12, 16, dp(46));
        add.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showAdminAddBookDialog(); } });
        body.addView(add);
    }

    private void buildAdminReports(LinearLayout body) {
        body.addView(adminSectionLabel("البلاغات الواردة (" + adminDashboardData.reports.size() + ")"));
        for (final AdminReport report : adminDashboardData.reports) {
            LinearLayout card = adminListCard(report.subject, report.details, report.status, 0xFFEF4444);
            Button action = makeButtonWithThickBorder("تمت المعالجة", Color.TRANSPARENT, GLASS_BORDER, TEXT_PRIMARY, 10, 12, dp(38));
            action.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { report.status = "مغلق"; saveAdminDashboardCache(); showAdminDashboard(); } });
            card.addView(action);
            body.addView(card);
        }
        if (adminDashboardData.reports.isEmpty()) body.addView(adminInfoCard("لا توجد بلاغات", "ممتاز، لا توجد بلاغات معلقة حالياً."));
    }

    private void buildAdminNotifications(LinearLayout body) {
        body.addView(adminSectionLabel("الإشعارات العامة"));
        final EditText input = new EditText(this);
        input.setHint("اكتب نص الإشعار العام...");
        input.setTextColor(TEXT_PRIMARY);
        input.setHintTextColor(TEXT_MUTED);
        input.setMinLines(3);
        input.setGravity(Gravity.TOP);
        input.setPadding(16, 14, 16, 14);
        input.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 18, 2));
        body.addView(input);
        Button send = makeButtonWithThickBorder("إضافة وإرسال الإشعار", 0x55F59E0B, GLASS_BORDER, TEXT_PRIMARY, 12, 16, dp(46));
        send.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String text = input.getText().toString().trim();
                if (text.isEmpty()) { Toast.makeText(MainActivity.this, "اكتب نص الإشعار أولاً", Toast.LENGTH_SHORT).show(); return; }
                AdminNotification n = new AdminNotification(); n.message = text; n.createdAt = getDate();
                adminDashboardData.notifications.add(0, n); saveAdminDashboardCache(); input.setText(""); showAdminDashboard();
                postAdminNotificationToApi(n);
            }
        });
        body.addView(send);
        for (AdminNotification n : adminDashboardData.notifications) body.addView(adminInfoCard(n.createdAt, n.message));
    }

    private LinearLayout adminInfoCard(String title, String detail) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18, 14, 18, 14);
        card.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 18, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 8, 0, 8); card.setLayoutParams(lp);
        TextView a = new TextView(this); a.setText(title); a.setTextColor(TEXT_PRIMARY); a.setTextSize(13); a.setTypeface(currentTypeface, Typeface.BOLD); card.addView(a);
        TextView b = new TextView(this); b.setText(detail); b.setTextColor(TEXT_MUTED); b.setTextSize(12); b.setPadding(0, 6, 0, 0); card.addView(b);
        return card;
    }

    private LinearLayout adminListCard(String title, String detail, String badge, int badgeColor) {
        LinearLayout card = adminInfoCard(title, detail);
        TextView badgeTv = new TextView(this); badgeTv.setText(badge); badgeTv.setTextColor(Color.WHITE); badgeTv.setTextSize(10); badgeTv.setPadding(10, 5, 10, 5); GradientDrawable bg = new GradientDrawable(); bg.setColor(badgeColor); bg.setCornerRadius(14); badgeTv.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.gravity = Gravity.END; card.addView(badgeTv, lp);
        return card;
    }

    private void showAdminAddBookDialog() {
        final EditText input = new EditText(this); input.setHint("العنوان | المؤلف"); input.setSingleLine(true); input.setTextColor(TEXT_PRIMARY); input.setHintTextColor(TEXT_MUTED);
        new AlertDialog.Builder(this).setTitle("إضافة كتاب محلياً").setView(input).setNegativeButton("إلغاء", null).setPositiveButton("إضافة", new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int w) { String[] p = input.getText().toString().split("\\|", 2); if (p.length == 0 || p[0].trim().isEmpty()) return; AdminBook b = new AdminBook(); b.title = p[0].trim(); b.author = p.length > 1 ? p[1].trim() : "غير محدد"; b.published = true; adminDashboardData.books.add(0, b); saveAdminDashboardCache(); showAdminDashboard(); }
        }).show();
    }

    private void syncAdminDashboardFromApi() {
        final String baseUrl = normalizeAdminUrl(getSharedPreferences(ADMIN_PREFS, MODE_PRIVATE).getString("api_base_url", ""));
        final String token = getSharedPreferences(ADMIN_PREFS, MODE_PRIVATE).getString("admin_token", "");
        if (baseUrl.isEmpty()) { saveAdminDashboardCache(); return; }
        adminExecutor.execute(new Runnable() {
            @Override public void run() {
                try {
                    JSONObject data = adminApiRequest(baseUrl + "/admin/dashboard", "GET", null, token);
                    final AdminDashboardData parsed = AdminDashboardData.fromJson(data);
                    parsed.fromApi = true;
                    adminDashboardData = parsed;
                    saveAdminDashboardCache();
                    getSharedPreferences(ADMIN_PREFS, MODE_PRIVATE).edit().putString("last_sync", getDate()).apply();
                    adminHandler.post(new Runnable() { @Override public void run() { showAdminDashboard(); Toast.makeText(MainActivity.this, "تمت مزامنة لوحة المشرف", Toast.LENGTH_SHORT).show(); } });
                } catch (final Exception e) {
                    adminHandler.post(new Runnable() { @Override public void run() { Toast.makeText(MainActivity.this, "تعذر الاتصال؛ تم استخدام البيانات المحلية", Toast.LENGTH_LONG).show(); } });
                }
            }
        });
    }

    private void postAdminNotificationToApi(final AdminNotification notification) {
        final String baseUrl = normalizeAdminUrl(getSharedPreferences(ADMIN_PREFS, MODE_PRIVATE).getString("api_base_url", ""));
        final String token = getSharedPreferences(ADMIN_PREFS, MODE_PRIVATE).getString("admin_token", "");
        if (baseUrl.isEmpty()) return;
        adminExecutor.execute(new Runnable() { @Override public void run() { try { adminApiRequest(baseUrl + "/admin/notifications", "POST", notification.toJson(), token); } catch (Exception ignored) {} } });
    }

    private JSONObject adminApiRequest(String urlText, String method, JSONObject body, String token) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(urlText).openConnection();
        connection.setRequestMethod(method); connection.setConnectTimeout(10000); connection.setReadTimeout(15000); connection.setRequestProperty("Accept", "application/json");
        if (token != null && !token.isEmpty()) connection.setRequestProperty("Authorization", token.startsWith("Bearer ") ? token : "Bearer " + token);
        if (body != null) { connection.setDoOutput(true); connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8"); OutputStream os = connection.getOutputStream(); os.write(body.toString().getBytes("UTF-8")); os.close(); }
        int code = connection.getResponseCode(); InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
        if (stream == null) throw new IllegalStateException("HTTP " + code);
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8")); StringBuilder result = new StringBuilder(); String line; while ((line = reader.readLine()) != null) result.append(line); reader.close(); connection.disconnect();
        if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + ": " + result.toString());
        return result.length() == 0 ? new JSONObject() : new JSONObject(result.toString());
    }

    private void saveAdminDashboardCache() {
        try { FileOutputStream fos = openFileOutput(ADMIN_CACHE_FILE, Context.MODE_PRIVATE); fos.write(adminDashboardData.toJson().toString().getBytes("UTF-8")); fos.close(); } catch (Exception ignored) {}
    }

    private void loadAdminDashboardCache() {
        try { File f = new File(getFilesDir(), ADMIN_CACHE_FILE); if (!f.exists()) { seedAdminDashboardData(); return; } FileInputStream fis = openFileInput(ADMIN_CACHE_FILE); byte[] b = new byte[(int) fis.available()]; fis.read(b); fis.close(); adminDashboardData = AdminDashboardData.fromJson(new JSONObject(new String(b, "UTF-8"))); if (adminDashboardData.users.isEmpty() && adminDashboardData.books.isEmpty()) seedAdminDashboardData(); } catch (Exception e) { seedAdminDashboardData(); }
    }

    private void seedAdminDashboardData() {
        adminDashboardData = new AdminDashboardData();
        SharedPreferences profile = getSharedPreferences("DaleelUserProfile", MODE_PRIVATE);
        AdminUser u = new AdminUser(); u.name = profile.getString("user_profile_name", "مستخدم دليل"); u.email = "local@daleel.app"; u.active = true; adminDashboardData.users.add(u);
        for (NoteItem item : itemsList) { AdminBook b = new AdminBook(); b.title = item.title; b.author = item.subtitle; b.published = true; adminDashboardData.books.add(b); }
        adminDashboardData.totalReads = itemsList.size(); adminDashboardData.activeToday = 1; saveAdminDashboardCache();
    }

    public static class AdminDashboardData {
        public ArrayList<AdminUser> users = new ArrayList<AdminUser>(); public ArrayList<AdminBook> books = new ArrayList<AdminBook>(); public ArrayList<AdminReport> reports = new ArrayList<AdminReport>(); public ArrayList<AdminNotification> notifications = new ArrayList<AdminNotification>(); public int totalReads = 0; public int activeToday = 0; public boolean fromApi = false;
        public JSONObject toJson() throws Exception { JSONObject o = new JSONObject(); JSONArray us = new JSONArray(), bs = new JSONArray(), rs = new JSONArray(), ns = new JSONArray(); for (AdminUser x: users) us.put(x.toJson()); for (AdminBook x: books) bs.put(x.toJson()); for (AdminReport x: reports) rs.put(x.toJson()); for (AdminNotification x: notifications) ns.put(x.toJson()); o.put("users", us); o.put("books", bs); o.put("reports", rs); o.put("notifications", ns); o.put("totalReads", totalReads); o.put("activeToday", activeToday); return o; }
        public static AdminDashboardData fromJson(JSONObject o) { AdminDashboardData d = new AdminDashboardData(); try { if (o == null) return d; JSONObject wrapped = o.optJSONObject("data"); if (wrapped == null) wrapped = o.optJSONObject("dashboard"); if (wrapped != null) o = wrapped; JSONArray a = o.optJSONArray("users"); if (a != null) for (int i=0;i<a.length();i++) d.users.add(AdminUser.fromJson(a.optJSONObject(i))); a=o.optJSONArray("books"); if(a!=null)for(int i=0;i<a.length();i++)d.books.add(AdminBook.fromJson(a.optJSONObject(i))); a=o.optJSONArray("reports"); if(a!=null)for(int i=0;i<a.length();i++)d.reports.add(AdminReport.fromJson(a.optJSONObject(i))); a=o.optJSONArray("notifications"); if(a!=null)for(int i=0;i<a.length();i++)d.notifications.add(AdminNotification.fromJson(a.optJSONObject(i))); d.totalReads=o.optInt("totalReads",0); d.activeToday=o.optInt("activeToday",0); } catch(Exception ignored){} return d; }
    }
    public static class AdminUser { public String name="", email=""; public boolean active=true; JSONObject toJson() throws Exception { JSONObject o=new JSONObject(); o.put("name",name);o.put("email",email);o.put("active",active);return o;} static AdminUser fromJson(JSONObject o){AdminUser x=new AdminUser();if(o!=null){x.name=o.optString("name","");x.email=o.optString("email","");x.active=o.optBoolean("active",true);}return x;} }
    public static class AdminBook { public String title="", author=""; public boolean published=true; JSONObject toJson() throws Exception {JSONObject o=new JSONObject();o.put("title",title);o.put("author",author);o.put("published",published);return o;} static AdminBook fromJson(JSONObject o){AdminBook x=new AdminBook();if(o!=null){x.title=o.optString("title","");x.author=o.optString("author","");x.published=o.optBoolean("published",true);}return x;} }
    public static class AdminReport { public String subject="", details="", status="مفتوح"; JSONObject toJson() throws Exception {JSONObject o=new JSONObject();o.put("subject",subject);o.put("details",details);o.put("status",status);return o;} static AdminReport fromJson(JSONObject o){AdminReport x=new AdminReport();if(o!=null){x.subject=o.optString("subject","");x.details=o.optString("details","");x.status=o.optString("status","مفتوح");}return x;} }
    public static class AdminNotification { public String message="", createdAt=""; JSONObject toJson() throws Exception {JSONObject o=new JSONObject();o.put("message",message);o.put("createdAt",createdAt);return o;} static AdminNotification fromJson(JSONObject o){AdminNotification x=new AdminNotification();if(o!=null){x.message=o.optString("message","");x.createdAt=o.optString("createdAt","");}return x;} }

    private void showAccountProfileScreen() {
        if (rootContainer == null) return;
        rootContainer.removeAllViews();
        rootContainer.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{OLED_BG_START, OLED_BG_END}));
        rootContainer.setLayoutDirection("en".equals(currentAppLanguage) ? View.LAYOUT_DIRECTION_LTR : View.LAYOUT_DIRECTION_RTL);
        final SharedPreferences prefs = getSharedPreferences("DaleelUserProfile", MODE_PRIVATE);
        final String userName = prefs.getString("user_profile_name", "مستخدم دليل (Yahya)");
        final String avatar = prefs.getString("user_profile_avatar", "");
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(20, 28, 20, 130);

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(8, 8, 8, 18);
        TextView nameTop = new TextView(this); nameTop.setText(userName); nameTop.setTextColor(TEXT_PRIMARY); nameTop.setTextSize(18); nameTop.setTypeface(currentTypeface, Typeface.BOLD);
        top.addView(nameTop, new LinearLayout.LayoutParams(0, -2, 1));
        Button menu = makeGlassButton("☰", Color.TRANSPARENT, 0, TEXT_PRIMARY, 18, 12); menu.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ openDrawer(); }}); top.addView(menu);
        page.addView(top);

        LinearLayout identity = new LinearLayout(this); identity.setGravity(Gravity.CENTER_VERTICAL); identity.setPadding(8, 4, 8, 14);
        final ImageView avatarIv = new ImageView(this); avatarIv.setScaleType(ImageView.ScaleType.CENTER_CROP); avatarIv.setPadding(5,5,5,5);
        GradientDrawable avatarBg = new GradientDrawable(); avatarBg.setShape(GradientDrawable.OVAL); avatarBg.setColor(GLASS_CARD_BG); avatarBg.setStroke(dp(3), GOLD_COLOR); avatarIv.setBackground(avatarBg);
        if (!avatar.isEmpty()) try { avatarIv.setImageURI(Uri.parse(avatar)); } catch(Exception ignored) {} else avatarIv.setImageResource(android.R.drawable.ic_menu_myplaces);
        avatarIv.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); try{startActivityForResult(i,PICK_PROFILE_IMAGE_REQUEST);}catch(Exception ignored){} }});
        identity.addView(avatarIv, new LinearLayout.LayoutParams(dp(92), dp(92)));
        LinearLayout bio = new LinearLayout(this); bio.setOrientation(LinearLayout.VERTICAL); bio.setPadding(16,0,16,0);
        TextView n = new TextView(this); n.setText(userName); n.setTextColor(TEXT_PRIMARY); n.setTextSize(17); n.setTypeface(currentTypeface, Typeface.BOLD); bio.addView(n);
        TextView b = new TextView(this); b.setText("باحث أكاديمي • مكتبة دليل"); b.setTextColor(TEXT_MUTED); b.setTextSize(12); bio.addView(b);
        LinearLayout buttons = new LinearLayout(this); Button edit=makeGlassButton("تعديل الملف الشخصي",0x443B82F6,LILAC_SOFT,Color.WHITE,11,12); edit.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showEditProfileNameDialog();}}); buttons.addView(edit); Button share=makeGlassButton("مشاركة الحساب",0x443B82F6,LILAC_SOFT,Color.WHITE,11,12); share.setOnClickListener(new View.OnClickListener(){public void onClick(View v){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,"حساب " + userName + " في دليل");startActivity(Intent.createChooser(i,"مشاركة الحساب"));}}); buttons.addView(share); bio.addView(buttons);
        identity.addView(bio, new LinearLayout.LayoutParams(0,-2,1)); page.addView(identity);
        Button messagesButton = makeButtonWithThickBorder("💬 الرسائل", NEON_BLUE, 0, Color.WHITE, 14, 18, dp(52));
        messagesButton.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ showChatEntryDialog(); }});
        LinearLayout.LayoutParams messageLp = new LinearLayout.LayoutParams(-1, -2); messageLp.setMargins(8, 4, 8, 14); page.addView(messagesButton, messageLp);

        LinearLayout stats = new LinearLayout(this); stats.setWeightSum(3); stats.addView(makeStatCard("المنشورات",String.valueOf(itemsList.size()),NEON_BLUE),new LinearLayout.LayoutParams(0,-2,1)); stats.addView(makeStatCard("المحفوظات",String.valueOf(countSavedItems()),PURPLE_COLOR),new LinearLayout.LayoutParams(0,-2,1)); final View streakHighlight=makeStatCard("السلسلة 🔥",String.valueOf(computeStreak()),GOLD_COLOR); streakHighlight.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showStreakDetailsDialog();}}); stats.addView(streakHighlight,new LinearLayout.LayoutParams(0,-2,1)); page.addView(stats);

        LinearLayout highlights = new LinearLayout(this); highlights.setPadding(0,18,0,12); String[] hs={"السلسلة 🔥","الهدف 🎯","السحابة ☁️","الترجمة 🌐","Y-DALEEL 🤖"}; for(String h:hs){ TextView t=new TextView(this); t.setText(h); t.setTextColor(TEXT_PRIMARY); t.setTextSize(11); t.setGravity(Gravity.CENTER); t.setPadding(5,12,5,12); t.setBackground(makeGlassDrawable(GLASS_CARD_BG,GOLD_COLOR,22,1)); highlights.addView(t,new LinearLayout.LayoutParams(0,dp(58),1)); } page.addView(highlights);
        page.addView(buildStreakCard());
        TextView tabs = new TextView(this); tabs.setText("منشورات                                      محفوظات"); tabs.setTextColor(TEXT_PRIMARY); tabs.setTextSize(14); tabs.setTypeface(currentTypeface,Typeface.BOLD); tabs.setPadding(8,22,8,12); page.addView(tabs);
        FullGridView grid = new FullGridView(this); grid.setNumColumns(3); grid.setHorizontalSpacing(8); grid.setVerticalSpacing(8); grid.setSelector(new ColorDrawable(Color.TRANSPARENT)); ArrayList<NoteItem> posts=new ArrayList<NoteItem>(); for(NoteItem it:itemsList) if(it.isSaved || !"الملاحظات".equals(it.category)) posts.add(it); final ArrayAdapter<NoteItem> postAdapter=new ArrayAdapter<NoteItem>(this,0,posts){ public View getView(int pos,View cv,ViewGroup parent){ final NoteItem it=getItem(pos); TextView cover=new TextView(MainActivity.this); cover.setText(it.title); cover.setTextColor(Color.WHITE); cover.setTextSize(11); cover.setGravity(Gravity.CENTER); cover.setPadding(5,5,5,5); cover.setBackground(makeGlassDrawable(typeColorOf(it),GOLD_COLOR,12,1)); cover.setOnClickListener(new View.OnClickListener(){public void onClick(View v){openDocumentDirectly(it);}}); cover.setOnLongClickListener(new View.OnLongClickListener(){public boolean onLongClick(View v){showCardOptionsDialog(it);return true;}}); return cover; }}; grid.setAdapter(postAdapter); page.addView(grid);
        final LinearLayout settings = new LinearLayout(this); settings.setOrientation(LinearLayout.VERTICAL); settings.setVisibility(View.GONE); String[] labels={"⚙ مكتبة دليل العامة","⚙ الهدف اليومي للقراءة","⚙ المظهر","⚙ ارتفاع شريط القارئ","⚙ اللغة","⚙ الترجمة والقاموس","⚙ السحابة التخزينية","⚙ مفاتيح الذكاء الاصطناعي","⚙ مقياس البطاقات","⚙ سياسة الخصوصية"}; View.OnClickListener[] actions={new View.OnClickListener(){public void onClick(View v){showDaleelLibraryStoreDialog();}},new View.OnClickListener(){public void onClick(View v){showGoalDialog();}},new View.OnClickListener(){public void onClick(View v){showThemeSelectionDialog();}},new View.OnClickListener(){public void onClick(View v){showReaderBottomBarHeightDialog();}},new View.OnClickListener(){public void onClick(View v){showLanguageDialog();}},new View.OnClickListener(){public void onClick(View v){showTranslationDialog(null);}},new View.OnClickListener(){public void onClick(View v){showCloudStorageDialog();}},new View.OnClickListener(){public void onClick(View v){showApiKeyDialog();}},new View.OnClickListener(){public void onClick(View v){showSettingsDialog();}},new View.OnClickListener(){public void onClick(View v){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://sites.google.com/view/daleel-official")));}catch(Exception ignored){}}}}; for(int i=0;i<labels.length;i++) settings.addView(makeSettingItemRow(labels[i],actions[i])); TextView settingsToggle=new TextView(this); settingsToggle.setText("⚙ خيارات التطبيق"); settingsToggle.setTextColor(TEXT_PRIMARY); settingsToggle.setTextSize(16); settingsToggle.setTypeface(currentTypeface,Typeface.BOLD); settingsToggle.setPadding(8,24,8,14); settingsToggle.setOnClickListener(new View.OnClickListener(){public void onClick(View v){settings.setVisibility(settings.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE);}}); page.addView(settingsToggle); page.addView(settings);
        scroll.addView(page); rootContainer.addView(scroll); setupFloatingDockBar();
        n.setOnClickListener(new View.OnClickListener(){public void onClick(View v){handleSecretOwnerTap(v);}});
    }

    private String localChatKey(String other){
        String me=getSharedPreferences("DaleelLocalChat",MODE_PRIVATE).getString("local_user","مستخدم دليل");
        return "chat_"+me+"_"+other;
    }
    private void showChatEntryDialog(){
        final EditText user=new EditText(this); user.setHint("اسم الطرف الآخر"); user.setTextColor(TEXT_PRIMARY); user.setHintTextColor(TEXT_MUTED); user.setSingleLine(true); user.setPadding(24,16,24,16); user.setBackground(makeGlassDrawable(GLASS_CARD_BG,GLASS_BORDER,18,2));
        new AlertDialog.Builder(this).setTitle("الرسائل المحلية").setMessage("هذه النسخة مستقلة؛ الرسائل والصور تحفظ على هذا الجهاز فقط.").setView(user).setPositiveButton("فتح المحادثة",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){String other=user.getText().toString().trim();if(!other.isEmpty())showChatScreen(other);}}).setNegativeButton("إلغاء",null).show();
    }
    private void showChatScreen(final String other){
        rootContainer.removeAllViews(); final String key=localChatKey(other); final SharedPreferences store=getSharedPreferences("DaleelLocalChat",MODE_PRIVATE);
        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(16,22,16,110); page.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{OLED_BG_START,OLED_BG_END}));
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); Button back=makeGlassButton("‹",Color.TRANSPARENT,GOLD_COLOR,TEXT_PRIMARY,22,10); back.setOnClickListener(v->{currentBottomTab="الحساب";setupMainUI();}); header.addView(back); TextView title=new TextView(this); title.setText("المحادثة • "+other); title.setTextColor(TEXT_PRIMARY); title.setTextSize(17); title.setGravity(Gravity.CENTER); header.addView(title,new LinearLayout.LayoutParams(0,-2,1)); page.addView(header);
        final LinearLayout messages=new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL); final ScrollView history=new ScrollView(this); history.setFillViewport(true); history.addView(messages); page.addView(history,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout composer=new LinearLayout(this); composer.setGravity(Gravity.CENTER_VERTICAL); final EditText input=new EditText(this); input.setHint("اكتب رسالة..."); input.setTextColor(TEXT_PRIMARY); input.setHintTextColor(TEXT_MUTED); input.setBackground(makeGlassDrawable(GLASS_CARD_BG,GLASS_BORDER,22,2)); input.setPadding(22,12,22,12); composer.addView(input,new LinearLayout.LayoutParams(0,-2,1));
        Button photo=makeGlassButton("＋",Color.TRANSPARENT,LILAC_SOFT,TEXT_PRIMARY,20,8); photo.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");try{startActivityForResult(i,PICK_CHAT_IMAGE_REQUEST);}catch(Exception ignored){}}); composer.addView(photo);
        Button send=makeGlassButton("إرسال",NEON_BLUE,Color.TRANSPARENT,Color.WHITE,12,12); send.setOnClickListener(v->{String text=input.getText().toString().trim();if(!text.isEmpty()){appendLocalMessage(key,"me",text,"");input.setText("");renderLocalMessages(messages,store.getString(key,""));history.post(()->history.fullScroll(View.FOCUS_DOWN));}}); composer.addView(send); page.addView(composer); rootContainer.addView(page); setupFloatingDockBar(); renderLocalMessages(messages,store.getString(key,""));
        activeLocalChatKey=key;
    }
    private void appendLocalMessage(String key,String sender,String text,String image){SharedPreferences st=getSharedPreferences("DaleelLocalChat",MODE_PRIVATE);String old=st.getString(key,"");String safe=text.replace("|"," ").replace("\\"," ");String safeImage=image==null?"":image.replace("|"," ");st.edit().putString(key,old+(old.isEmpty()?"":"\n")+sender+"|"+safe+"|"+safeImage).apply();}
    private void renderLocalMessages(LinearLayout box,String raw){box.removeAllViews();if(raw==null||raw.isEmpty())return;for(String row:raw.split("\\n")){String[] p=row.split("\\|",-1);if(p.length<3)continue;boolean mine="me".equals(p[0]);LinearLayout bubble=new LinearLayout(this);bubble.setOrientation(LinearLayout.VERTICAL);bubble.setPadding(18,12,18,12);bubble.setBackground(makeGlassDrawable(mine?0xFF2563EB:GLASS_CARD_BG,mine?0xFF60A5FA:GOLD_COLOR,18,1));TextView t=new TextView(this);t.setText(p[1]);t.setTextColor(Color.WHITE);t.setTextSize(15);bubble.addView(t);if(!p[2].isEmpty()){TextView im=new TextView(this);im.setText("🖼 صورة已发送 • اضغط لفتحها");im.setTextColor(Color.WHITE);im.setPadding(0,8,0,0);final String uri=p[2];im.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(uri)));}catch(Exception ignored){}});bubble.addView(im);}LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.setMargins(mine?dp(50):dp(4),6,mine?dp(4):dp(50),6);bubble.setLayoutParams(lp);box.addView(bubble);}}
    private void sendLocalChatImage(Uri uri){if(uri==null||activeLocalChatKey==null||activeLocalChatKey.isEmpty())return;appendLocalMessage(activeLocalChatKey,"me","",uri.toString());Toast.makeText(this,"تم حفظ الصورة في المحادثة المحلية",Toast.LENGTH_SHORT).show();}

    private int countSavedItems(){int n=0;for(NoteItem i:itemsList)if(i.isSaved)n++;return n;}
    private void showStreakDetailsDialog(){StringBuilder b=new StringBuilder("تفاصيل آخر 7 أيام:\n\n");String[] names={"الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"};Calendar c=Calendar.getInstance();int today=c.get(Calendar.DAY_OF_WEEK)-1;for(int i=6;i>=0;i--){int ago=6-i;int idx=(today-ago+7)%7;b.append(names[idx]).append(": ").append(getSecondsReadOn(ago)/60).append(" دقيقة ").append(getSecondsReadOn(ago)>=getDailyGoalMinutes()*60?"🔥":"—").append("\n");}b.append("\nالسلسلة: ").append(computeStreak()).append(" يوم\nالأفضل: ").append(updateAndGetBestStreak(computeStreak())).append(" يوم\nقراءة اليوم: ").append(getSecondsReadOn(0)/60).append(" دقيقة");new AlertDialog.Builder(this).setTitle("سلسلة القراءة").setMessage(b.toString()).setPositiveButton("تم",null).show();}

    // دالة ارتفاع شريط القارئ السفلي التي كانت مفقودة وتسببت في خطأ البناء
    private void showReaderBottomBarHeightDialog() {
        final SharedPreferences prefs = getSharedPreferences("DaleelTextReaderPrefs", MODE_PRIVATE);
        int currentHeight = prefs.getInt("reader_bottom_bar_height", 64);
        
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 36, 36, 36);
        layout.setBackgroundColor(OLED_BG_END);

        TextView title = new TextView(this);
        title.setText("ارتفاع الأزرار السفلى لقارئ النص");
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(17);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setPadding(0, 0, 0, 16);
        layout.addView(title);

        final TextView valText = new TextView(this);
        valText.setText("الارتفاع الحالي: " + currentHeight + " dp");
        valText.setTextColor(LILAC_SOFT);
        valText.setTextSize(13);
        layout.addView(valText);

        final SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(40);
        seekBar.setProgress(currentHeight - 48);
        LinearLayout.LayoutParams seekLp = new LinearLayout.LayoutParams(-1, -2);
        seekLp.setMargins(0, 16, 0, 24);
        seekBar.setLayoutParams(seekLp);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int newHeight = progress + 48;
                valText.setText("الارتفاع الحالي: " + newHeight + " dp");
                prefs.edit().putInt("reader_bottom_bar_height", newHeight).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        layout.addView(seekBar);

        new AlertDialog.Builder(this)
                .setView(layout)
                .setPositiveButton("تم", null)
                .show();
    }

    private void showApiKeyDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 36, 36, 36);
        layout.setBackgroundColor(OLED_BG_END);

        TextView title = new TextView(this);
        title.setText("مفاتيح الربط السحابي");
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(17);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setPadding(0, 0, 0, 16);
        layout.addView(title);

        TextView lbl1 = new TextView(this);
        lbl1.setText("مفتاح Gemini API:");
        lbl1.setTextColor(TEXT_MUTED);
        lbl1.setTextSize(12);
        layout.addView(lbl1);

        final EditText geminiInput = new EditText(this);
        SharedPreferences prefs = getSharedPreferences("DaleelUserProfile", MODE_PRIVATE);
        geminiInput.setText(prefs.getString("gemini_api_key", ""));
        geminiInput.setHint("AIzaSy...");
        geminiInput.setTextColor(TEXT_PRIMARY);
        geminiInput.setHintTextColor(TEXT_MUTED);
        geminiInput.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 20, 2));
        geminiInput.setPadding(24, 14, 24, 14);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 4, 0, 16);
        geminiInput.setLayoutParams(lp);
        layout.addView(geminiInput);

        TextView lbl2 = new TextView(this);
        lbl2.setText("مفتاح ChatGPT (OpenAI API Key):");
        lbl2.setTextColor(TEXT_MUTED);
        lbl2.setTextSize(12);
        layout.addView(lbl2);

        final EditText openaiInput = new EditText(this);
        openaiInput.setText(prefs.getString("openai_api_key", ""));
        openaiInput.setHint("sk-proj-...");
        openaiInput.setTextColor(TEXT_PRIMARY);
        openaiInput.setHintTextColor(TEXT_MUTED);
        openaiInput.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 20, 2));
        openaiInput.setPadding(24, 14, 24, 14);
        openaiInput.setLayoutParams(lp);
        layout.addView(openaiInput);

        new AlertDialog.Builder(this)
                .setView(layout)
                .setPositiveButton("حفظ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        prefs.edit()
                                .putString("gemini_api_key", geminiInput.getText().toString().trim())
                                .putString("openai_api_key", openaiInput.getText().toString().trim())
                                .apply();
                        Toast.makeText(MainActivity.this, "تم حفظ مفاتيح الذكاء الاصطناعي بنجاح", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void showEditProfileNameDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 36, 36, 36);
        layout.setBackgroundColor(OLED_BG_END);

        TextView title = new TextView(this);
        title.setText("تعديل اسم المستخدم");
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(17);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setPadding(0, 0, 0, 16);
        layout.addView(title);

        final EditText nameInput = new EditText(this);
        SharedPreferences prefs = getSharedPreferences("DaleelUserProfile", MODE_PRIVATE);
        nameInput.setText(prefs.getString("user_profile_name", "مستخدم دليل (Yahya)"));
        nameInput.setTextColor(TEXT_PRIMARY);
        nameInput.setHintTextColor(TEXT_MUTED);
        nameInput.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 20, 2));
        nameInput.setPadding(24, 18, 24, 18);
        layout.addView(nameInput);

        new AlertDialog.Builder(this)
                .setView(layout)
                .setPositiveButton("حفظ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String newName = nameInput.getText().toString().trim();
                        if (!newName.isEmpty()) {
                            prefs.edit().putString("user_profile_name", newName).apply();
                            setupMainUI();
                            Toast.makeText(MainActivity.this, "تم تحديث الاسم بنجاح", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void showThemeSelectionDialog() {
        final CharSequence[] themes = {"الوضع العادي (OLED)", "الوضع الداكن التام (Pure Dark)", "الوضع الفاتح (Light Mode)"};
        new AlertDialog.Builder(this)
                .setTitle("اختر مظهر التطبيق")
                .setItems(themes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        getSharedPreferences("DaleelUserProfile", MODE_PRIVATE)
                                .edit().putInt("app_theme_mode", which).apply();
                        setupThemeColors(which);
                        setupMainUI();
                        Toast.makeText(MainActivity.this, "تم تطبيق المظهر بنجاح", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private LinearLayout makeStatCard(String label, String val, int accentColor) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(16, 20, 16, 20);
        card.setBackground(makeGlassDrawable(GLASS_CARD_BG, accentColor, 24, 2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(6, 0, 6, 0);
        card.setLayoutParams(lp);

        TextView valTv = new TextView(this);
        valTv.setText(val);
        valTv.setTextColor(TEXT_PRIMARY);
        valTv.setTextSize(15);
        valTv.setGravity(Gravity.CENTER);
        valTv.setTypeface(currentTypeface, Typeface.BOLD);
        card.addView(valTv);

        TextView labelTv = new TextView(this);
        labelTv.setText(label);
        labelTv.setTextColor(TEXT_MUTED);
        labelTv.setTextSize(11);
        labelTv.setGravity(Gravity.CENTER);
        card.addView(labelTv);

        return card;
    }

    private LinearLayout makeSettingItemRow(String title, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(24, 20, 24, 20);
        row.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 24, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 8, 0, 8);
        row.setLayoutParams(lp);

        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(TEXT_PRIMARY);
        tv.setTextSize(13);
        tv.setTypeface(currentTypeface, Typeface.BOLD);
        row.addView(tv, new LinearLayout.LayoutParams(0, -2, 1.0f));

        TextView arrow = new TextView(this);
        arrow.setText("←");
        arrow.setTextColor(LILAC_SOFT);
        arrow.setTextSize(14);
        row.addView(arrow);

        row.setOnClickListener(listener);
        return row;
    }

    private void showReaderIndexDialog() {
        final Dialog indexDialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_TranslucentDecor);
        LinearLayout sheet = new LinearLayout(this);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(36, 40, 36, 40);
        sheet.setBackgroundColor(0xFF1E293B);

        TextView title = new TextView(this);
        title.setText("الفهرس");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 24);
        sheet.addView(title);

        String[] chapters = {
                "١     صفحة العنوان",
                "٢     فصل في النيل وأثره",
                "٣     فصل في العمائر والكتابة"
        };

        for (final String ch : chapters) {
            TextView chTv = new TextView(this);
            chTv.setText(ch);
            chTv.setTextColor(Color.WHITE);
            chTv.setTextSize(15);
            chTv.setPadding(20, 20, 20, 20);
            GradientDrawable cBg = new GradientDrawable();
            cBg.setColor(0x22FFFFFF);
            cBg.setCornerRadius(16f);
            chTv.setBackground(cBg);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 8, 0, 8);
            chTv.setLayoutParams(lp);
            chTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(MainActivity.this, "الانتقال إلى: " + ch, Toast.LENGTH_SHORT).show();
                    indexDialog.dismiss();
                }
            });
            sheet.addView(chTv);
        }

        indexDialog.setContentView(sheet);
        indexDialog.show();
    }

    private int typeColorOf(NoteItem item) {
        if ("مخطوط".equals(item.itemType)) return GOLD_COLOR;
        if ("كتاب".equals(item.itemType)) return PURPLE_COLOR;
        if ("ملاحظة".equals(item.itemType)) return 0xFFF59E0B;
        return NEON_BLUE;
    }

    private TextView makeSectionTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(TEXT_PRIMARY);
        tv.setTextSize(18);
        tv.setTypeface(currentTypeface, Typeface.BOLD);
        tv.setPadding(dp(4), 0, dp(4), dp(10));
        return tv;
    }

    private TextView makeBadge(String text, int color) {
        TextView badge = new TextView(this);
        badge.setText(text);
        badge.setTextColor(Color.WHITE);
        badge.setTextSize(11);
        badge.setTypeface(currentTypeface, Typeface.BOLD);
        badge.setPadding(dp(10), dp(2), dp(10), dp(2));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(8));
        badge.setBackground(bg);
        return badge;
    }

    private FrameLayout buildCoverContainer(NoteItem item, boolean compact) {
        FrameLayout coverContainer = new FrameLayout(this);

        ImageView coverImageView = new ImageView(this);
        coverImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        coverImageView.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));

        boolean coverLoaded = false;

        if (item.coverImageUri != null && !item.coverImageUri.isEmpty()) {
            try {
                coverImageView.setImageURI(Uri.parse(item.coverImageUri));
                coverLoaded = true;
            } catch (Exception ignored) {}
        } else if (item.pdfUri != null && !item.pdfUri.isEmpty()) {
            Bitmap cached = coverCache.get(item.pdfUri);
            if (cached == null) {
                try {
                    ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(Uri.parse(item.pdfUri), "r");
                    if (pfd != null) {
                        PdfRenderer renderer = new PdfRenderer(pfd);
                        if (renderer.getPageCount() > 0) {
                            PdfRenderer.Page page = renderer.openPage(0);
                            Bitmap bmp = Bitmap.createBitmap(page.getWidth(), page.getHeight(), Bitmap.Config.ARGB_8888);
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                            page.close();
                            renderer.close();
                            cached = bmp;
                            coverCache.put(item.pdfUri, bmp);
                        }
                        pfd.close();
                    }
                } catch (Exception ignored) {}
            }
            if (cached != null) {
                coverImageView.setImageBitmap(cached);
                coverLoaded = true;
            }
        }

        if (coverLoaded) {
            coverContainer.addView(coverImageView);
        } else {
            LinearLayout coverBox = new LinearLayout(this);
            coverBox.setOrientation(LinearLayout.VERTICAL);
            coverBox.setGravity(Gravity.CENTER);

            GradientDrawable coverBg = new GradientDrawable();
            if ("مخطوط".equals(item.itemType)) {
                coverBg.setColor(0xFF2C221E);
                coverBg.setStroke(2, GOLD_COLOR);
            } else if ("ملاحظة".equals(item.itemType)) {
                coverBg.setColor(0xFFFFF9C4);
                coverBg.setStroke(2, 0xFFEAB308);
            } else {
                coverBg.setColor(0xFF1E293B);
                coverBg.setStroke(2, NEON_BLUE);
            }
            coverBg.setCornerRadius(20f);
            coverBox.setBackground(coverBg);
            coverBox.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));

            TextView coverArtText = new TextView(this);
            if ("مخطوط".equals(item.itemType)) {
                coverArtText.setText(compact ? "مخطوط" : "مخطوطة أثرية هيروغليفية");
                coverArtText.setTextColor(Color.WHITE);
            } else if ("ملاحظة".equals(item.itemType)) {
                coverArtText.setText(compact ? "ملاحظة" : "ملاحظة شخصية مدونة");
                coverArtText.setTextColor(0xFF854D0E);
            } else {
                coverArtText.setText(compact ? "مستند" : "مستند بحثي مرجعي");
                coverArtText.setTextColor(Color.WHITE);
            }
            coverArtText.setTextSize(compact ? 12 : 14);
            coverArtText.setGravity(Gravity.CENTER);
            coverArtText.setTypeface(currentTypeface, Typeface.BOLD);
            coverBox.addView(coverArtText);
            coverContainer.addView(coverBox);
        }
        return coverContainer;
    }

    private View buildWelcomeCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        card.setBackground(makeGlassDrawable(GLASS_CARD_BG, NEON_BLUE, dp(24), 2));
        card.setElevation(6f);

        TextView title = new TextView(this);
        title.setText(L("welcome_title"));
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(17);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        card.addView(title);

        TextView desc = new TextView(this);
        desc.setText(L("welcome_desc"));
        desc.setTextColor(TEXT_MUTED);
        desc.setTextSize(13);
        desc.setPadding(0, dp(6), 0, 0);
        card.addView(desc);

        return card;
    }

    private NoteItem pickResumeItem() {
        if (itemsList.isEmpty()) return null;
        NoteItem best = null;
        for (NoteItem it : itemsList) {
            if (it.lastOpened > 0 && (best == null || it.lastOpened > best.lastOpened)) best = it;
        }
        if (best != null) return best;
        for (NoteItem it : itemsList) {
            if (it.progressPercent > 0 && it.progressPercent < 100) return it;
        }
        return null;
    }

    private View buildResumeSection() {
        final NoteItem item = pickResumeItem();
        if (item == null) return null;
        int typeColor = typeColorOf(item);

        LinearLayout section = new LinearLayout(this);
        section.setOrientation(LinearLayout.VERTICAL);
        section.addView(makeSectionTitle("كمل من وين وقفت"));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(12), dp(12), dp(12));
        card.setBackground(makeGlassDrawable(GLASS_CARD_BG, typeColor, dp(22), 3));
        card.setElevation(6f);

        String smartResumeText;
        if (item.pdfUri != null && !item.pdfUri.isEmpty()) {
            int pageNum = item.lastPage + 1;
            smartResumeText = "أكمل من الصفحة (" + pageNum + ")";
        } else {
            int lineNum = Math.max(1, (item.lastScrollY / 50) + 1);
            smartResumeText = "أكمل من السطر (" + lineNum + ")";
        }

        TextView bannerTv = new TextView(this);
        bannerTv.setText(smartResumeText);
        bannerTv.setTextColor(0xFF1B1407);
        bannerTv.setTextSize(13);
        bannerTv.setTypeface(currentTypeface, Typeface.BOLD);
        bannerTv.setPadding(20, 10, 20, 10);
        GradientDrawable bannerBg = new GradientDrawable();
        bannerBg.setColor(GOLD_COLOR);
        bannerBg.setCornerRadius(16f);
        bannerTv.setBackground(bannerBg);
        LinearLayout.LayoutParams bannerLp = new LinearLayout.LayoutParams(-1, -2);
        bannerLp.setMargins(0, 0, 0, 12);
        bannerTv.setLayoutParams(bannerLp);
        card.addView(bannerTv);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);

        FrameLayout cover = buildCoverContainer(item, true);
        cover.setClipToOutline(true);
        cover.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(12));
            }
        });
        LinearLayout.LayoutParams coverLp = new LinearLayout.LayoutParams(dp(84), dp(112));
        coverLp.setMarginEnd(dp(12));
        row.addView(cover, coverLp);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);

        info.addView(makeBadge(item.itemType, typeColor));

        TextView titleTv = new TextView(this);
        titleTv.setText(item.title);
        titleTv.setTextColor(TEXT_PRIMARY);
        titleTv.setTextSize(17);
        titleTv.setMaxLines(2);
        titleTv.setTypeface(currentTypeface, Typeface.BOLD);
        titleTv.setPadding(0, dp(6), 0, 0);
        info.addView(titleTv);

        TextView subTv = new TextView(this);
        subTv.setText(item.subtitle);
        subTv.setTextColor(TEXT_MUTED);
        subTv.setTextSize(12);
        info.addView(subTv);

        TextView pagesTv = new TextView(this);
        pagesTv.setText("نسبة الإنجاز " + item.progressPercent + "%");
        pagesTv.setTextColor(TEXT_MUTED);
        pagesTv.setTextSize(12);
        pagesTv.setPadding(0, dp(6), 0, 0);
        info.addView(pagesTv);

        row.addView(info, new LinearLayout.LayoutParams(0, -2, 1.0f));
        card.addView(row);

        ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(100);
        pb.setProgress(item.progressPercent);
        pb.setProgressTintList(ColorStateList.valueOf(FAIENCE_GREEN));
        LinearLayout.LayoutParams pbLp = new LinearLayout.LayoutParams(-1, dp(6));
        pbLp.setMargins(0, dp(14), 0, dp(4));
        card.addView(pb, pbLp);

        TextView pct = new TextView(this);
        pct.setText(item.progressPercent == 0 ? "جديد" : item.progressPercent + "% مكتمل");
        pct.setTextColor(FAIENCE_GREEN);
        pct.setTextSize(12);
        pct.setTypeface(currentTypeface, Typeface.BOLD);
        pct.setPadding(0, 0, 0, dp(10));
        card.addView(pct);

        int currentPageNum = (item.pdfUri != null && !item.pdfUri.isEmpty()) ? (item.lastPage + 1) : Math.max(1, (item.lastScrollY / 50) + 1);
        String mainAmberButtonText = "أكمل القراءة  (" + item.progressPercent + "% - من الصفحة " + currentPageNum + ")";
        
        Button go = makeButtonWithThickBorder(mainAmberButtonText, GOLD_COLOR, 0xFFD97706, 0xFF1B1407, 14, 20, dp(52));
        go.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openDocumentDirectly(item); }
        });
        card.addView(go, new LinearLayout.LayoutParams(-1, dp(54)));

        section.addView(card);
        return section;
    }

    private void updateHomeExtrasVisibility(String query) {
        if (homeExtras == null) return;
        boolean show = "الكل".equals(currentFilterTab) && (query == null || query.trim().isEmpty());
        homeExtras.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private void setupMainUI() {
        try {
            setupMainUIUnsafe();
        } catch (Throwable error) {
            showSafeRecoveryScreen();
        }
    }

    private void showSafeRecoveryScreen() {
        if (rootContainer == null || !activityAlive) return;
        try {
            rootContainer.removeAllViews();
            LinearLayout safe = new LinearLayout(this);
            safe.setOrientation(LinearLayout.VERTICAL);
            safe.setGravity(Gravity.CENTER);
            safe.setPadding(32, 32, 32, 140);
            safe.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{OLED_BG_START, OLED_BG_END}));
            TextView title = new TextView(this);
            title.setText("تم تشغيل وضع الاسترداد الآمن");
            title.setTextColor(TEXT_PRIMARY);
            title.setTextSize(18);
            title.setGravity(Gravity.CENTER);
            safe.addView(title);
            TextView detail = new TextView(this);
            detail.setText("حدث خطأ في بناء الواجهة فقط، ولم تُحذف بياناتك. اضغط إعادة المحاولة.");
            detail.setTextColor(TEXT_MUTED);
            detail.setTextSize(13);
            detail.setGravity(Gravity.CENTER);
            detail.setPadding(0, 14, 0, 20);
            safe.addView(detail);
            Button retry = makeButtonWithThickBorder("إعادة المحاولة", NEON_BLUE, 0, Color.WHITE, 13, 18, dp(48));
            retry.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { setupMainUI(); } });
            safe.addView(retry);
            rootContainer.addView(safe);
            setupFloatingDockBar();
        } catch (Throwable ignored) {}
    }

    private void setupMainUIUnsafe() {
        if (rootContainer == null) return;

        if ("الحساب".equals(currentBottomTab)) {
            showAccountProfileScreen();
            return;
        }
        if ("الأخبار".equals(currentBottomTab)) {
            showNewsScreen();
            return;
        }

        rootContainer.removeAllViews();
        rootContainer.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{OLED_BG_START, OLED_BG_END}));
        rootContainer.setLayoutDirection("en".equals(currentAppLanguage) ? View.LAYOUT_DIRECTION_LTR : View.LAYOUT_DIRECTION_RTL);

        mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(24, 40, 24, 0);

        LinearLayout topBar = new LinearLayout(this);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setPadding(20, 14, 20, 14);
        topBar.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 32, 3));
        LinearLayout.LayoutParams topBarLp = new LinearLayout.LayoutParams(-1, -2);
        topBarLp.setMargins(0, 0, 0, 16);
        topBar.setLayoutParams(topBarLp);

        Button btnMenuTop = makeButtonWithThickBorder("قائمة", Color.TRANSPARENT, 0, TEXT_PRIMARY, 12, 16, dp(44));
        btnMenuTop.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openDrawer(); }
        });
        topBar.addView(btnMenuTop);

        TextView daleelFreeTitle = new TextView(this);
        daleelFreeTitle.setText("دليل - Daleel");
        daleelFreeTitle.setTextColor(TEXT_PRIMARY);
        daleelFreeTitle.setTextSize(16);
        daleelFreeTitle.setTypeface(currentTypeface, Typeface.BOLD);
        daleelFreeTitle.setPadding(16, 0, 16, 0);
        topBar.addView(daleelFreeTitle);
        daleelFreeTitle.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { handleAdminTitleTap(v); }
        });

        View topSpacer = new View(this);
        topBar.addView(topSpacer, new LinearLayout.LayoutParams(0, 0, 1.0f));

        mainLayout.addView(topBar);

        LinearLayout pillSearchBar = new LinearLayout(this);
        pillSearchBar.setOrientation(LinearLayout.HORIZONTAL);
        pillSearchBar.setGravity(Gravity.CENTER_VERTICAL);
        pillSearchBar.setPadding(16, 12, 16, 12);

        GradientDrawable pillBg = new GradientDrawable();
        pillBg.setColor(GLASS_CARD_BG);
        pillBg.setCornerRadius(36f);
        pillBg.setStroke(2, 0x553B82F6);
        pillSearchBar.setBackground(pillBg);
        pillSearchBar.setElevation(8f);

        LinearLayout.LayoutParams pillLp = new LinearLayout.LayoutParams(-1, -2);
        pillLp.setMargins(0, 0, 0, 12);
        pillSearchBar.setLayoutParams(pillLp);

        LinearLayout micButtonBox = new LinearLayout(this);
        micButtonBox.setGravity(Gravity.CENTER);
        GradientDrawable micBg = new GradientDrawable();
        micBg.setColor(NEON_BLUE);
        micBg.setCornerRadius(20f);
        micButtonBox.setBackground(micBg);
        LinearLayout.LayoutParams micLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        micLp.setMarginEnd(12);
        micButtonBox.setLayoutParams(micLp);

        GoogleMicIconView micIconView = new GoogleMicIconView(this);
        LinearLayout.LayoutParams micIconLp = new LinearLayout.LayoutParams(dp(22), dp(22));
        micIconView.setLayoutParams(micIconLp);
        micButtonBox.addView(micIconView);

        micButtonBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent voiceIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                voiceIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                voiceIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, currentAppLanguage);
                voiceIntent.putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدث للبحث في مكتبة دليل...");
                try {
                    startActivityForResult(voiceIntent, VOICE_RECOGNITION_REQUEST_CODE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "ميزة البحث الصوتي غير مدعومة", Toast.LENGTH_SHORT).show();
                }
            }
        });
        pillSearchBar.addView(micButtonBox);

        searchBox = new EditText(this);
        searchBox.setHint("ابحث في ملفاتك وكتبك أو اسألها...");
        searchBox.setHintTextColor(TEXT_MUTED);
        searchBox.setTextColor(TEXT_PRIMARY);
        searchBox.setTextSize(14);
        searchBox.setTypeface(currentTypeface);
        searchBox.setBackgroundColor(Color.TRANSPARENT);
        searchBox.setSingleLine(true);
        searchBox.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        pillSearchBar.addView(searchBox);

        TextView searchIconTv = new TextView(this);
        searchIconTv.setText("🔍");
        searchIconTv.setTextColor(LILAC_SOFT);
        searchIconTv.setTextSize(16);
        searchIconTv.setPadding(12, 0, 4, 0);
        pillSearchBar.addView(searchIconTv);

        mainLayout.addView(pillSearchBar);

        searchSuggestionsContainer = new LinearLayout(this);
        searchSuggestionsContainer.setOrientation(LinearLayout.VERTICAL);
        searchSuggestionsContainer.setBackground(makeGlassDrawable(OLED_BG_END, GLASS_BORDER, 24, 2));
        searchSuggestionsContainer.setPadding(20, 16, 20, 16);
        searchSuggestionsContainer.setVisibility(View.GONE);
        LinearLayout.LayoutParams suggestionsLp = new LinearLayout.LayoutParams(-1, -2);
        suggestionsLp.setMargins(0, 0, 0, 16);
        searchSuggestionsContainer.setLayoutParams(suggestionsLp);
        mainLayout.addView(searchSuggestionsContainer);

        searchBox.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus && searchBox.getText().toString().isEmpty()) {
                    showRecentSearches();
                }
            }
        });

        searchBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (searchBox.getText().toString().isEmpty()) {
                    showRecentSearches();
                }
            }
        });

        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString().trim();
                filterData(query);
                updateHomeExtrasVisibility(query);
                if (!query.isEmpty()) {
                    showDynamicSuggestions(query);
                } else {
                    showRecentSearches();
                }
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        ScrollView homeScroll = new ScrollView(this);
        homeScroll.setVerticalScrollBarEnabled(false);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, dp(120));

        homeExtras = new LinearLayout(this);
        homeExtras.setOrientation(LinearLayout.VERTICAL);

        View resumeSection = buildResumeSection();
        if (resumeSection != null) {
            LinearLayout.LayoutParams resumeLp = new LinearLayout.LayoutParams(-1, -2);
            resumeLp.setMargins(0, 0, 0, dp(16));
            homeExtras.addView(resumeSection, resumeLp);
        } else {
            LinearLayout.LayoutParams welcomeLp = new LinearLayout.LayoutParams(-1, -2);
            welcomeLp.setMargins(0, 0, 0, dp(16));
            homeExtras.addView(buildWelcomeCard(), welcomeLp);
        }
        content.addView(homeExtras);

        LinearLayout tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        tabsRow.setGravity(Gravity.CENTER);
        tabsRow.setPadding(0, 0, 0, 16);

        final Button tabAll = makeButtonWithThickBorder(L("tab_all"), currentFilterTab.equals("الكل") ? NEON_BLUE : GLASS_CARD_BG, GLASS_BORDER, TEXT_PRIMARY, 12, 16, dp(44));
        final Button tabLib = makeButtonWithThickBorder(L("tab_books"), currentFilterTab.equals("الكتب") ? NEON_BLUE : GLASS_CARD_BG, GLASS_BORDER, TEXT_PRIMARY, 12, 16, dp(44));
        final Button tabSaved = makeButtonWithThickBorder(L("tab_saved"), currentFilterTab.equals("المحفوظات") ? NEON_BLUE : GLASS_CARD_BG, GLASS_BORDER, TEXT_PRIMARY, 12, 16, dp(44));

        LinearLayout.LayoutParams tabLp = new LinearLayout.LayoutParams(0, -2, 1.0f);
        tabLp.setMargins(6, 0, 6, 0);
        tabAll.setLayoutParams(tabLp);
        tabLib.setLayoutParams(tabLp);
        tabSaved.setLayoutParams(tabLp);

        tabAll.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { currentFilterTab = "الكل"; filterData(""); setupMainUI(); }
        });
        tabLib.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { currentFilterTab = "الكتب"; filterData(""); setupMainUI(); }
        });
        tabSaved.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { currentFilterTab = "المحفوظات"; filterData(""); setupMainUI(); }
        });

        tabsRow.addView(tabAll);
        tabsRow.addView(tabLib);
        tabsRow.addView(tabSaved);
        content.addView(tabsRow);

        FullGridView gridView = new FullGridView(this);
        gridView.setNumColumns(2);
        gridView.setHorizontalSpacing(14);
        gridView.setVerticalSpacing(18);
        gridView.setSelector(new ColorDrawable(Color.TRANSPARENT));

        SharedPreferences cardPrefs = getSharedPreferences("DaleelUserProfile", MODE_PRIVATE);
        final int customCardHeight = cardPrefs.getInt("card_size_height", 380);

        adapter = new ArrayAdapter<NoteItem>(this, 0, filteredList) {
            @Override
            public View getView(int pos, View cv, ViewGroup p) {
                final NoteItem item = getItem(pos);
                LinearLayout card = new LinearLayout(getContext());
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(12, 12, 12, 12);

                int typeColor = typeColorOf(item);

                GradientDrawable cBg = makeGlassDrawable(0xEE1E293B, typeColor, 32, 3);
                card.setBackground(new RippleDrawable(ColorStateList.valueOf(0x448B5CF6), cBg, cBg));
                card.setElevation(8f);

                card.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        showCardOptionsDialog(item);
                        return true;
                    }
                });

                LinearLayout cardHeaderRow = new LinearLayout(getContext());
                cardHeaderRow.setOrientation(LinearLayout.HORIZONTAL);
                cardHeaderRow.setGravity(Gravity.CENTER_VERTICAL);
                cardHeaderRow.setPadding(8, 6, 8, 8);

                TextView typeBadge = new TextView(getContext());
                typeBadge.setText(item.itemType);
                typeBadge.setTextColor(Color.WHITE);
                typeBadge.setTextSize(11);
                typeBadge.setTypeface(currentTypeface, Typeface.BOLD);
                typeBadge.setPadding(12, 4, 12, 4);
                GradientDrawable badgeBg = new GradientDrawable();
                badgeBg.setColor(typeColor);
                badgeBg.setCornerRadius(16f);
                typeBadge.setBackground(badgeBg);
                cardHeaderRow.addView(typeBadge);

                View sp = new View(getContext());
                cardHeaderRow.addView(sp, new LinearLayout.LayoutParams(0, 0, 1.0f));

                TextView saveBadge = new TextView(getContext());
                saveBadge.setText(item.isSyncedToCloud ? "سحابة" : (item.isSaved ? "محفوظ" : "حفظ"));
                saveBadge.setTextColor(item.isSyncedToCloud ? 0xFF60A5FA : (item.isSaved ? 0xFF00FFC8 : Color.WHITE));
                saveBadge.setTextSize(11);
                saveBadge.setTypeface(currentTypeface, Typeface.BOLD);
                saveBadge.setPadding(10, 4, 10, 4);
                GradientDrawable sBg = new GradientDrawable();
                sBg.setColor(0x66000000);
                sBg.setCornerRadius(16f);
                saveBadge.setBackground(sBg);
                cardHeaderRow.addView(saveBadge);

                card.addView(cardHeaderRow);

                FrameLayout coverContainer = buildCoverContainer(item, false);
                coverContainer.setLayoutParams(new LinearLayout.LayoutParams(-1, customCardHeight - 200));
                card.addView(coverContainer);

                TextView titleView = new TextView(getContext());
                titleView.setText(item.title);
                titleView.setTextColor(TEXT_PRIMARY);
                titleView.setTextSize(14);
                titleView.setMaxLines(1);
                titleView.setTypeface(currentTypeface, Typeface.BOLD);
                titleView.setPadding(4, 8, 4, 2);
                card.addView(titleView);

                LinearLayout infoRow = new LinearLayout(getContext());
                infoRow.setOrientation(LinearLayout.HORIZONTAL);
                infoRow.setGravity(Gravity.CENTER_VERTICAL);
                infoRow.setPadding(4, 2, 4, 6);

                TextView pageInfo = new TextView(getContext());
                pageInfo.setText("صفحة " + item.pageCount);
                pageInfo.setTextColor(TEXT_MUTED);
                pageInfo.setTextSize(11);
                infoRow.addView(pageInfo, new LinearLayout.LayoutParams(0, -2, 1.0f));

                TextView sizeInfo = new TextView(getContext());
                sizeInfo.setText(item.fileSizeInfo);
                sizeInfo.setTextColor(TEXT_MUTED);
                sizeInfo.setTextSize(11);
                infoRow.addView(sizeInfo);

                card.addView(infoRow);

                LinearLayout progressRow = new LinearLayout(getContext());
                progressRow.setOrientation(LinearLayout.VERTICAL);
                progressRow.setPadding(4, 2, 4, 8);

                TextView progLabel = new TextView(getContext());
                progLabel.setText(item.progressPercent == 0 ? "جديد" : item.progressPercent + "%");
                progLabel.setTextColor(typeColor);
                progLabel.setTextSize(11);
                progLabel.setTypeface(currentTypeface, Typeface.BOLD);
                progressRow.addView(progLabel);

                ProgressBar progressBar = new ProgressBar(getContext(), null, android.R.attr.progressBarStyleHorizontal);
                progressBar.setMax(100);
                progressBar.setProgress(item.progressPercent);
                progressBar.setLayoutParams(new LinearLayout.LayoutParams(-1, 10));
                progressRow.addView(progressBar);

                card.addView(progressRow);

                Button actionBtn = makeButtonWithThickBorder((item.progressPercent == 0) ? "ابدأ القراءة" : "أكمل القراءة", typeColor, typeColor - 0x11000000, Color.WHITE, 13, 22, dp(48));
                actionBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openDocumentDirectly(item);
                    }
                });

                card.addView(actionBtn);
                return card;
            }
        };

        gridView.setAdapter(adapter);
        content.addView(gridView, new LinearLayout.LayoutParams(-1, -2));

        homeScroll.addView(content);
        mainLayout.addView(homeScroll, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        rootContainer.addView(mainLayout);

        updateHomeExtrasVisibility("");
        setupFloatingDockBar();
        setupAdvancedNavigationDrawer();
        filterData("");
    }

    private void showRecentSearches() {
        if (searchSuggestionsContainer == null) return;
        searchSuggestionsContainer.removeAllViews();
        searchSuggestionsContainer.setVisibility(View.VISIBLE);

        SharedPreferences prefs = getSharedPreferences("DaleelSearchHistory", MODE_PRIVATE);
        Set<String> historySet = prefs.getStringSet("history", new HashSet<String>());

        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);
        headerRow.setPadding(0, 0, 0, 8);

        TextView title = new TextView(this);
        title.setText("جرّب البحث عن");
        title.setTextColor(LILAC_SOFT);
        title.setTextSize(14);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        headerRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1.0f));

        TextView clearBtn = new TextView(this);
        clearBtn.setText("مسح السجل");
        clearBtn.setTextColor(Color.RED);
        clearBtn.setTextSize(11);
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSharedPreferences("DaleelSearchHistory", MODE_PRIVATE).edit().remove("history").apply();
                searchSuggestionsContainer.setVisibility(View.GONE);
                Toast.makeText(MainActivity.this, "تم مسح سجل البحث", Toast.LENGTH_SHORT).show();
            }
        });
        headerRow.addView(clearBtn);
        searchSuggestionsContainer.addView(headerRow);

        if (historySet.isEmpty()) {
            String[] defaults = {"المنطق", "آثار المصريين", "العلوم", "لغتي الجميلة"};
            for (final String def : defaults) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, 10, 0, 10);

                TextView icon = new TextView(this);
                icon.setText("بحث ");
                icon.setTextColor(LILAC_SOFT);
                icon.setTextSize(12);
                row.addView(icon);

                TextView itemTv = new TextView(this);
                itemTv.setText(def);
                itemTv.setTextColor(TEXT_PRIMARY);
                itemTv.setTextSize(14);
                itemTv.setTypeface(currentTypeface);
                row.addView(itemTv, new LinearLayout.LayoutParams(0, -2, 1.0f));

                row.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        searchBox.setText(def);
                        searchSuggestionsContainer.setVisibility(View.GONE);
                    }
                });
                searchSuggestionsContainer.addView(row);
            }
            return;
        }

        for (final String hist : historySet) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, 10, 0, 10);

            TextView icon = new TextView(this);
            icon.setText("بحث ");
            icon.setTextColor(LILAC_SOFT);
            icon.setTextSize(12);
            row.addView(icon);

            TextView itemTv = new TextView(this);
            itemTv.setText(hist);
            itemTv.setTextColor(TEXT_PRIMARY);
            itemTv.setTextSize(14);
            row.addView(itemTv, new LinearLayout.LayoutParams(0, -2, 1.0f));

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    searchBox.setText(hist);
                    searchSuggestionsContainer.setVisibility(View.GONE);
                }
            });
            searchSuggestionsContainer.addView(row);
        }
    }

    private void showDynamicSuggestions(String query) {
        if (searchSuggestionsContainer == null) return;
        searchSuggestionsContainer.removeAllViews();
        searchSuggestionsContainer.setVisibility(View.VISIBLE);

        final ArrayList<String> suggestions = new ArrayList<String>();
        String qLower = query.toLowerCase();

        for (NoteItem item : itemsList) {
            if ((item.title != null && item.title.toLowerCase().contains(qLower)) || pdfTextContains(item, qLower)) {
                if (!suggestions.contains(item.title)) suggestions.add(item.title);
            }
        }

        if (suggestions.isEmpty()) {
            TextView noRes = newTextView("عذراً، لا توجد اقتراحات مطابقة.");
            searchSuggestionsContainer.addView(noRes);
            return;
        }

        TextView header = new TextView(this);
        header.setText("نتائج مطابقة لـ: " + query);
        header.setTextColor(LILAC_SOFT);
        header.setTextSize(13);
        header.setTypeface(currentTypeface, Typeface.BOLD);
        header.setPadding(0, 0, 0, 8);
        searchSuggestionsContainer.addView(header);

        for (final String sug : suggestions) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, 10, 0, 10);

            TextView icon = new TextView(this);
            icon.setText("بحث ");
            icon.setTextColor(LILAC_SOFT);
            icon.setTextSize(12);
            row.addView(icon);

            TextView sugTv = new TextView(this);
            sugTv.setText(sug);
            sugTv.setTextColor(TEXT_PRIMARY);
            sugTv.setTextSize(14);
            row.addView(sugTv, new LinearLayout.LayoutParams(0, -2, 1.0f));

            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    searchBox.setText(sug);
                    searchSuggestionsContainer.setVisibility(View.GONE);
                    saveSearchHistory(sug);
                }
            });
            searchSuggestionsContainer.addView(row);
        }
    }

    private TextView newTextView(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(TEXT_MUTED);
        tv.setTextSize(12);
        return tv;
    }

    private void saveSearchHistory(String query) {
        SharedPreferences prefs = getSharedPreferences("DaleelSearchHistory", MODE_PRIVATE);
        Set<String> historySet = prefs.getStringSet("history", new HashSet<String>());
        Set<String> newSet = new HashSet<String>(historySet);
        newSet.add(query);
        prefs.edit().putStringSet("history", newSet).apply();
    }

    private void showSettingsDialog() {
        final SharedPreferences prefs = getSharedPreferences("DaleelUserProfile", MODE_PRIVATE);
        int currentCardHeight = prefs.getInt("card_size_height", 380);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 36, 36, 36);
        layout.setBackgroundColor(OLED_BG_END);

        TextView title = new TextView(this);
        title.setText("إعدادات مقياس حجم البطاقات");
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(17);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setPadding(0, 0, 0, 16);
        layout.addView(title);

        final TextView sizeValText = new TextView(this);
        sizeValText.setText("ارتفاع البطاقة: " + currentCardHeight + " بكسل");
        sizeValText.setTextColor(LILAC_SOFT);
        sizeValText.setTextSize(13);
        layout.addView(sizeValText);

        final SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(200);
        seekBar.setProgress(currentCardHeight - 300);
        LinearLayout.LayoutParams seekLp = new LinearLayout.LayoutParams(-1, -2);
        seekLp.setMargins(0, 16, 0, 24);
        seekBar.setLayoutParams(seekLp);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int newHeight = progress + 300;
                sizeValText.setText("ارتفاع البطاقة: " + newHeight + " بكسل");
                prefs.edit().putInt("card_size_height", newHeight).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                setupMainUI();
            }
        });
        layout.addView(seekBar);

        new AlertDialog.Builder(this)
                .setView(layout)
                .setPositiveButton("تم", null)
                .show();
    }

    private void showNewsScreen() {
        if (rootContainer == null) return;
        rootContainer.removeAllViews();
        rootContainer.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{OLED_BG_START, OLED_BG_END}));
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(20, 28, 20, 120);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this); title.setText("الأخبار الدراسية والعالمية"); title.setTextColor(TEXT_PRIMARY); title.setTextSize(20); title.setTypeface(currentTypeface, Typeface.BOLD); header.addView(title, new LinearLayout.LayoutParams(0,-2,1));
        Button refresh = makeGlassButton("تحديث", Color.TRANSPARENT, GOLD_COLOR, TEXT_PRIMARY, 12, 12); refresh.setOnClickListener(new View.OnClickListener(){public void onClick(View v){loadNewsIntoScreen(page);}}); header.addView(refresh); page.addView(header);
        TextView note = new TextView(this); note.setText("مصادر عامة • آخر الأخبار التعليمية والعالمية"); note.setTextColor(TEXT_MUTED); note.setTextSize(12); note.setPadding(0,8,0,16); page.addView(note);
        loadNewsIntoScreen(page);
        ScrollView scroll = new ScrollView(this); scroll.setVerticalScrollBarEnabled(false); scroll.addView(page); rootContainer.addView(scroll); setupFloatingDockBar();
    }
    private void loadNewsIntoScreen(final LinearLayout page) {
        while(page.getChildCount()>2) page.removeViewAt(2);
        ArrayList<NewsItem> cachedSnapshot;
        synchronized (cachedNews) { cachedSnapshot = new ArrayList<NewsItem>(cachedNews); }
        if (!cachedSnapshot.isEmpty()) addNewsCards(page, cachedSnapshot); else { TextView loading=new TextView(this); loading.setText("جاري تحميل الأخبار..."); loading.setTextColor(TEXT_MUTED); loading.setGravity(Gravity.CENTER); loading.setPadding(0,40,0,40); page.addView(loading); }
        try { newsExecutor.execute(new Runnable(){public void run(){ArrayList<NewsItem> fresh=fetchNews();if(!fresh.isEmpty()){synchronized(cachedNews){cachedNews.clear();cachedNews.addAll(fresh);}new Handler(Looper.getMainLooper()).post(new Runnable(){public void run(){if(activityAlive&&"الأخبار".equals(currentBottomTab)){while(page.getChildCount()>2)page.removeViewAt(2);ArrayList<NewsItem> freshSnapshot; synchronized(cachedNews){freshSnapshot=new ArrayList<NewsItem>(cachedNews);} addNewsCards(page,freshSnapshot);}}});}}}); } catch (Throwable ignored) {}
    }
    private void addNewsCards(LinearLayout page, ArrayList<NewsItem> news) {
        for(final NewsItem n: news){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(18,16,18,16);card.setBackground(makeGlassDrawable(GLASS_CARD_BG,n.educational?FAIENCE_GREEN:NEON_BLUE,20,2));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,0,0,12);card.setLayoutParams(cp);TextView tag=new TextView(this);tag.setText(n.educational?"تعليمي":"عالمي");tag.setTextColor(n.educational?FAIENCE_GREEN:NEON_BLUE);tag.setTextSize(11);tag.setTypeface(currentTypeface,Typeface.BOLD);card.addView(tag);TextView t=new TextView(this);t.setText(n.title);t.setTextColor(TEXT_PRIMARY);t.setTextSize(15);t.setTypeface(currentTypeface,Typeface.BOLD);t.setPadding(0,8,0,6);card.addView(t);TextView d=new TextView(this);d.setText(n.description);d.setTextColor(TEXT_MUTED);d.setTextSize(12);card.addView(d);card.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(n.link)));}catch(Exception ignored){}}});page.addView(card);}
    }
    private ArrayList<NewsItem> fetchNews(){ArrayList<NewsItem> result=new ArrayList<NewsItem>();String[] urls={
            "https://feeds.bbci.co.uk/arabic/rss.xml",
            "https://www.sciencedaily.com/rss/top/science.xml",
            "https://news.google.com/rss/search?q=%D9%88%D8%B2%D8%A7%D8%B1%D8%A9+%D8%A7%D9%84%D8%AA%D8%B1%D8%A8%D9%8A%D8%A9+%D8%A7%D9%84%D8%B9%D8%B1%D8%A7%D9%82&hl=ar&gl=IQ&ceid=IQ:ar",
            "https://news.google.com/rss/search?q=%D9%88%D8%B2%D8%A7%D8%B1%D8%A9+%D8%A7%D9%84%D8%AA%D8%B1%D8%A8%D9%8A%D8%A9+%D8%A7%D9%84%D8%B3%D9%88%D8%B1%D9%8A%D8%A9&hl=ar&gl=SY&ceid=SY:ar",
            "https://news.google.com/rss/search?q=%D9%88%D8%B2%D8%A7%D8%B1%D8%A9+%D8%A7%D9%84%D8%AA%D8%B9%D9%84%D9%8A%D9%85+%D8%A7%D9%84%D8%B3%D8%B9%D9%88%D8%AF%D9%8A%D8%A9&hl=ar&gl=SA&ceid=SA:ar",
            "https://news.google.com/rss/search?q=%D9%88%D8%B2%D8%A7%D8%B1%D8%A9+%D8%A7%D9%84%D8%AA%D8%B1%D8%A8%D9%8A%D8%A9+%D8%A7%D9%84%D8%A3%D8%B1%D8%AF%D9%86%D9%8A%D8%A9&hl=ar&gl=JO&ceid=JO:ar",
            "https://news.google.com/rss/search?q=%D9%88%D8%B2%D8%A7%D8%B1%D8%A9+%D8%A7%D9%84%D8%AA%D8%B1%D8%A8%D9%8A%D8%A9+%D9%85%D8%B5%D8%B1&hl=ar&gl=EG&ceid=EG:ar"
        };for(String u:urls){try{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(7000);c.setRequestProperty("User-Agent","Daleel/1.0");InputStream in=c.getInputStream();String xml=new String(PureJavaPdfTextExtractor.readAll(in),"UTF-8");Matcher items=Pattern.compile("(?s)<item>(.*?)</item>",Pattern.CASE_INSENSITIVE).matcher(xml);int count=0;while(items.find()&&count<8){String block=items.group(1);String title=xmlTag(block,"title");String link=xmlTag(block,"link");String desc=stripHtml(xmlTag(block,"description"));if(!title.isEmpty()&&!link.isEmpty()){NewsItem n=new NewsItem();n.title=title;n.link=link;n.description=desc.length()>180?desc.substring(0,180)+"...":desc;n.educational=true;result.add(n);count++;}}c.disconnect();}catch(Exception ignored){}}
        addOfficialEducationLinks(result);
        return result;}
    private void addOfficialEducationLinks(ArrayList<NewsItem> result){
        String[][] official={{"العراق • وزارة التربية","https://moedu.gov.iq/"},{"سوريا • وزارة التربية","https://moed.gov.sy/"},{"السعودية • وزارة التعليم","https://www.moe.gov.sa/"},{"الأردن • وزارة التربية والتعليم","https://moe.gov.jo/"},{"مصر • وزارة التربية والتعليم","https://moe.gov.eg/"}};
        for(String[] x:official){boolean exists=false;for(NewsItem n:result)if(n.link.equals(x[1]))exists=true;if(!exists){NewsItem n=new NewsItem();n.title="أخبار رسمية: "+x[0];n.description="اضغط لفتح آخر الأخبار والإعلانات الرسمية من الجهة التعليمية.";n.link=x[1];n.educational=true;result.add(n);}}
    }
    private String xmlTag(String block,String tag){Matcher m=Pattern.compile("(?s)<"+tag+"[^>]*>(.*?)</"+tag+">").matcher(block);return m.find()?stripHtml(m.group(1)).replace("<![CDATA[","").replace("]]>","").trim():"";}
    private String stripHtml(String v){return v==null?"":v.replaceAll("<[^>]+>"," ").replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replaceAll("\\s+"," ").trim();}
    private static class NewsItem {String title="",link="",description="";boolean educational=false;}

    private void setupFloatingDockBar() {
        if (rootContainer == null) return;
        
        floatingDock = new LinearLayout(this);
        floatingDock.setOrientation(LinearLayout.HORIZONTAL);
        floatingDock.setGravity(Gravity.CENTER_VERTICAL);
        floatingDock.setWeightSum(5.0f);

        GradientDrawable glassDockBg = new GradientDrawable();
        glassDockBg.setColor(GLASS_CARD_BG);
        glassDockBg.setCornerRadius(36f);
        glassDockBg.setStroke(2, GLASS_BORDER);

        floatingDock.setBackground(glassDockBg);
        floatingDock.setElevation(12f);
        floatingDock.setPadding(4, 4, 4, 4);

        FrameLayout.LayoutParams navLp = new FrameLayout.LayoutParams(-1, dp(64), Gravity.BOTTOM);
        navLp.setMargins(dp(16), 0, dp(16), dp(16));
        floatingDock.setLayoutParams(navLp);

        View btnHome = makeDockItemView("الرئيسية", android.R.drawable.ic_menu_compass, currentBottomTab.equals("الرئيسية"), new View.OnClickListener() {
            @Override public void onClick(View v) { currentBottomTab = "الرئيسية"; currentFilterTab = "الكل"; setupMainUI(); }
        });

        View btnNotes = makeDockItemView("ملاحظات", android.R.drawable.ic_menu_agenda, currentBottomTab.equals("الملاحظات"), new View.OnClickListener() {
            @Override public void onClick(View v) { currentBottomTab = "الملاحظات"; showAppleStyleNotesDialog(); }
        });

        View btnPlusItem = makeDockAddView(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAdvancedAddOptionsDialog();
            }
        });

        View btnTools = makeDockItemView("الأخبار", android.R.drawable.ic_menu_info_details, currentBottomTab.equals("الأخبار"), new View.OnClickListener() {
            @Override public void onClick(View v) { currentBottomTab = "الأخبار"; setupMainUI(); }
        });

        View btnAccount = makeDockItemView("الحساب", android.R.drawable.ic_menu_my_calendar, currentBottomTab.equals("الحساب"), new View.OnClickListener() {
            @Override public void onClick(View v) { currentBottomTab = "الحساب"; setupMainUI(); }
        });

        LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(0, -1, 1.0f);
        itemLp.setMargins(2, 0, 2, 0);

        btnHome.setLayoutParams(itemLp);
        btnNotes.setLayoutParams(itemLp);
        btnPlusItem.setLayoutParams(itemLp);
        btnTools.setLayoutParams(itemLp);
        btnAccount.setLayoutParams(itemLp);

        floatingDock.addView(btnHome);
        floatingDock.addView(btnNotes);
        floatingDock.addView(btnPlusItem);
        floatingDock.addView(btnTools);
        floatingDock.addView(btnAccount);

        for (int i = 0; i < rootContainer.getChildCount(); i++) {
            View child = rootContainer.getChildAt(i);
            if (child.getTag() != null && child.getTag().equals("FLOATING_DOCK")) {
                rootContainer.removeView(child);
                break;
            }
        }
        floatingDock.setTag("FLOATING_DOCK");
        rootContainer.addView(floatingDock);
    }

    private View makeDockAddView(View.OnClickListener listener) {
        LinearLayout itemLayout = new LinearLayout(this);
        itemLayout.setOrientation(LinearLayout.VERTICAL);
        itemLayout.setGravity(Gravity.CENTER);
        itemLayout.setPadding(4, 4, 4, 4);

        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF3B82F6, 0xFF8B5CF6});
        bg.setCornerRadius(20f);
        bg.setStroke(2, GLASS_BORDER);
        itemLayout.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), bg, bg));

        TextView tv = new TextView(this);
        tv.setText("+");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(22);
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(currentTypeface, Typeface.BOLD);
        itemLayout.addView(tv);

        itemLayout.setOnClickListener(listener);
        return itemLayout;
    }

    private View makeDockItemView(String text, int iconRes, boolean isSelected, View.OnClickListener listener) {
        LinearLayout itemLayout = new LinearLayout(this);
        itemLayout.setOrientation(LinearLayout.VERTICAL);
        itemLayout.setGravity(Gravity.CENTER);
        itemLayout.setPadding(2, 2, 2, 2);

        GradientDrawable bg = new GradientDrawable();
        if (isSelected) {
            bg.setColor(0x443B82F6);
            bg.setCornerRadius(20f);
        } else {
            bg.setColor(Color.TRANSPARENT);
        }
        itemLayout.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), bg, bg));

        ImageView iconIv = new ImageView(this);
        iconIv.setImageResource(iconRes);
        iconIv.setColorFilter(isSelected ? Color.WHITE : TEXT_MUTED);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(20), dp(20));
        iconLp.setMargins(0, 0, 0, 2);
        iconIv.setLayoutParams(iconLp);
        itemLayout.addView(iconIv);

        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(isSelected ? TEXT_PRIMARY : TEXT_MUTED);
        tv.setTextSize(11);
        tv.setSingleLine(true);
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(currentTypeface, isSelected ? Typeface.BOLD : Typeface.NORMAL);
        itemLayout.addView(tv);

        itemLayout.setOnClickListener(listener);
        return itemLayout;
    }

    private void setupAdvancedNavigationDrawer() {
        if (rootContainer == null) return;
        overlayView = new View(this);
        overlayView.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        overlayView.setBackgroundColor(0xAA000000);
        overlayView.setVisibility(View.GONE);
        overlayView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeDrawer(); }
        });
        rootContainer.addView(overlayView);

        drawerPanel = new LinearLayout(this);
        drawerPanel.setOrientation(LinearLayout.VERTICAL);
        drawerPanel.setBackground(makeGlassDrawable(OLED_BG_END, GLASS_BORDER, 0, 0));
        drawerPanel.setPadding(30, 50, 30, 30);
        FrameLayout.LayoutParams drawerLp = new FrameLayout.LayoutParams(800, -1, Gravity.START);
        drawerPanel.setLayoutParams(drawerLp);
        drawerPanel.setVisibility(View.GONE);
        drawerPanel.setTranslationX(-800f);

        TextView drawerHeader = new TextView(this);
        drawerHeader.setText("قائمة التنقل لدليل");
        drawerHeader.setTextColor(TEXT_PRIMARY);
        drawerHeader.setTextSize(16);
        drawerHeader.setTypeface(currentTypeface, Typeface.BOLD);
        drawerHeader.setPadding(0, 0, 0, 24);
        drawerPanel.addView(drawerHeader);
        drawerHeader.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { handleSecretOwnerTap(v); }
        });

        Button btnDaleelStore = makeButtonWithThickBorder("📚 مكتبة دليل (تحميل الكتب)", 0x552FBF9F, GLASS_BORDER, TEXT_PRIMARY, 13, 18, dp(48));
        btnDaleelStore.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeDrawer(); showDaleelLibraryStoreDialog(); }
        });
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, -2);
        btnLp.setMargins(0, 8, 0, 8);
        btnDaleelStore.setLayoutParams(btnLp);
        drawerPanel.addView(btnDaleelStore);

        Button btnAiDrawer = makeButtonWithThickBorder("🤖 Y-DALEEL", 0x558B5CF6, GLASS_BORDER, TEXT_PRIMARY, 13, 18, dp(48));
        btnAiDrawer.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeDrawer(); showAIAssistantDialog(); }
        });
        btnAiDrawer.setLayoutParams(btnLp);
        drawerPanel.addView(btnAiDrawer);

        Button btnAlarmTab = makeButtonWithThickBorder("المنبه والتنبيهات", 0x55F59E0B, GLASS_BORDER, TEXT_PRIMARY, 13, 18, dp(48));
        btnAlarmTab.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeDrawer(); showAlarmManagementScreen(); }
        });
        btnAlarmTab.setLayoutParams(btnLp);
        drawerPanel.addView(btnAlarmTab);

        Button btnNotesDrawer = makeButtonWithThickBorder("ملاحظة جديدة", 0x553B82F6, GLASS_BORDER, TEXT_PRIMARY, 13, 18, dp(48));
        btnNotesDrawer.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeDrawer(); showAppleStyleNotesDialog(); }
        });
        btnNotesDrawer.setLayoutParams(btnLp);
        drawerPanel.addView(btnNotesDrawer);

        Button btnTranslateDrawer = makeButtonWithThickBorder("الترجمة الفورية والقاموس", 0x553B82F6, GLASS_BORDER, TEXT_PRIMARY, 13, 18, dp(48));
        btnTranslateDrawer.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeDrawer(); showTranslationDialog(null); }
        });
        btnTranslateDrawer.setLayoutParams(btnLp);
        drawerPanel.addView(btnTranslateDrawer);

        Button btnCloudDrawer = makeButtonWithThickBorder("السحابة التخزينية ومزامنة المكتبة", 0x552FBF9F, GLASS_BORDER, TEXT_PRIMARY, 13, 18, dp(48));
        btnCloudDrawer.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeDrawer(); showCloudStorageDialog(); }
        });
        btnCloudDrawer.setLayoutParams(btnLp);
        drawerPanel.addView(btnCloudDrawer);

        Button btnThemeDrawer = makeButtonWithThickBorder("تغيير مظهر التطبيق", 0x558B5CF6, GLASS_BORDER, TEXT_PRIMARY, 13, 18, dp(48));
        btnThemeDrawer.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeDrawer(); showThemeSelectionDialog(); }
        });
        btnThemeDrawer.setLayoutParams(btnLp);
        drawerPanel.addView(btnThemeDrawer);

        Button btnSet = makeButtonWithThickBorder("إعدادات مقياس البطاقات", 0x551E293B, GLASS_BORDER, TEXT_PRIMARY, 13, 18, dp(48));
        btnSet.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeDrawer(); showSettingsDialog(); }
        });
        btnSet.setLayoutParams(btnLp);
        drawerPanel.addView(btnSet);

        rootContainer.addView(drawerPanel);
    }

    private void handleSecretOwnerTap(View v){long now=System.currentTimeMillis();if(now-lastSecretTapAt>1800)secretTapCount=0;lastSecretTapAt=now;secretTapCount++;if(secretTapCount>=5){secretTapCount=0;showOwnerVerificationDialog();}}
    private void beginReadingSession(NoteItem item){activeReadingItem=item;readingSessionStartedAt=System.currentTimeMillis();addReadSeconds(20);}
    private void endReadingSession(NoteItem item){if(activeReadingItem==item && readingSessionStartedAt>0){int elapsed=(int)((System.currentTimeMillis()-readingSessionStartedAt)/1000L);if(elapsed>0)addReadSeconds(elapsed);activeReadingItem=null;readingSessionStartedAt=0;}}
    private void addReadSeconds(int seconds){if(seconds<=0)return;SharedPreferences p=getSharedPreferences(READ_PREFS,MODE_PRIVATE);String k="sec_"+dayKey(0);p.edit().putInt(k,p.getInt(k,0)+seconds).apply();}
    private String getPdfText(NoteItem item){return item==null||item.pdfUri==null?"":pdfTextIndex.containsKey(item.pdfUri)?pdfTextIndex.get(item.pdfUri):"";}
    private boolean pdfTextContains(NoteItem item,String q){String t=getPdfText(item);return !t.isEmpty()&&!q.isEmpty()&&t.toLowerCase().contains(q.toLowerCase());}
    private int findPdfPage(NoteItem item,String query,int totalPages){String all=getPdfText(item).toLowerCase();if(all.isEmpty())return -1;String[] pages=all.split("\\f",-1);for(int i=0;i<pages.length&&i<totalPages;i++)if(pages[i].contains(query.toLowerCase()))return i;return -1;}
    private void loadPdfTextIndex(){try{File f=new File(getFilesDir(),PDF_INDEX_FILE);if(!f.exists())return;DataInputStream in=new DataInputStream(new BufferedInputStream(new FileInputStream(f)));int n=in.readInt();for(int i=0;i<n;i++)pdfTextIndex.put(in.readUTF(),in.readUTF());in.close();}catch(Exception ignored){}}
    private synchronized void savePdfTextIndex(){try{DataOutputStream out=new DataOutputStream(new FileOutputStream(new File(getFilesDir(),PDF_INDEX_FILE)));out.writeInt(pdfTextIndex.size());for(Map.Entry<String,String> e:pdfTextIndex.entrySet()){out.writeUTF(e.getKey());out.writeUTF(e.getValue()==null?"":e.getValue());}out.close();}catch(Exception ignored){}}
    private void startPdfIndexing(){
        if (!activityAlive || pdfIndexExecutor.isShutdown()) return;
        final ArrayList<NoteItem> snapshot = new ArrayList<NoteItem>(itemsList);
        try { pdfIndexExecutor.execute(new Runnable(){public void run(){
            for(final NoteItem item:snapshot){
                if(!activityAlive) return;
                if(item.pdfUri!=null&&!item.pdfUri.isEmpty()&&!pdfTextIndex.containsKey(item.pdfUri)){
                    try { String text=PureJavaPdfTextExtractor.extract(MainActivity.this,item.pdfUri); if(text.length()>0) { pdfTextIndex.put(item.pdfUri,text); savePdfTextIndex(); } }
                    catch(Throwable ignored) {}
                }
            }
            if(activityAlive) new Handler(Looper.getMainLooper()).post(new Runnable(){public void run(){if(activityAlive) filterData("");}});
        }}); } catch (Throwable ignored) {}
    }
    private static class PureJavaPdfTextExtractor{
        static String extract(Context c,String uri){try{InputStream raw=c.getContentResolver().openInputStream(Uri.parse(uri));if(raw==null)return "";byte[] data=readAllLimited(raw, 12 * 1024 * 1024); if(data.length==0) return ""; String source=new String(data,"ISO-8859-1");StringBuilder out=new StringBuilder();Pattern p=Pattern.compile("(?s)(<<.*?/FlateDecode.*?>>)\\s*stream\\s*(.*?)\\s*endstream");Matcher m=p.matcher(source);while(m.find()){byte[] compressed=m.group(2).getBytes("ISO-8859-1");try{ByteArrayOutputStream b=new ByteArrayOutputStream();InflaterInputStream inf=new InflaterInputStream(new java.io.ByteArrayInputStream(compressed));byte[] buf=new byte[4096];int n;while((n=inf.read(buf))!=-1)b.write(buf,0,n);String page=readOperators(b.toByteArray());if(!page.trim().isEmpty())out.append(page).append('\f');}catch(Exception ignored){}}if(out.length()==0)out.append(readOperators(data));return out.toString();}catch(Exception e){return "";}}
        static byte[] readAll(InputStream in)throws Exception{ return readAllLimited(in, 16 * 1024 * 1024); }
        static byte[] readAllLimited(InputStream in,int max)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int n,total=0;while((n=in.read(x))!=-1){total+=n;if(total>max)break;b.write(x,0,n);}in.close();return b.toByteArray();}
        static String readOperators(byte[] bytes){String s;try{s=new String(bytes,"ISO-8859-1");}catch(Exception e){return "";}StringBuilder out=new StringBuilder();Matcher tj=Pattern.compile("\\((.*?)\\)\\s*Tj",Pattern.DOTALL).matcher(s);while(tj.find())out.append(decode(tj.group(1))).append(' ');Matcher arr=Pattern.compile("\\[(.*?)\\]\\s*TJ",Pattern.DOTALL).matcher(s);while(arr.find()){Matcher str=Pattern.compile("\\((.*?)\\)",Pattern.DOTALL).matcher(arr.group(1));while(str.find())out.append(decode(str.group(1)));out.append(' ');}return out.toString();}
        static String decode(String x){try{String z=x.replace("\\(","(").replace("\\)",")").replace("\\n","\n").replace("\\r","\r").replace("\\\\","\\");byte[] b=z.getBytes("ISO-8859-1");if(b.length>=2&&(b[0]&255)==0xFE&&(b[1]&255)==0xFF)return new String(b,"UTF-16BE");return z;}catch(Exception e){return x;}}
    }

    private String generateLocalAiResponse(String query) {
        String q = query.toLowerCase().trim();
        StringBuilder analysis = new StringBuilder();
        
        analysis.append("🔬 **تقرير التحليل العميق والمنطقي (Y-DALEEL Local Engine)**:\n\n");
        analysis.append("1️⃣ **مرحلة معالجة ودلالة الاستعلام:** تم تحليل الكلمات المفتاحية لمسألتك (\"").append(query).append("\") واستخلاص الأبعاد الأكاديمية.\n");
        analysis.append("2️⃣ **فحص محتوى المكتبة المحلية:** جاري فحص ").append(itemsList.size()).append(" مستنداً ومخطوطة مسجلة في قاعدة بيانات دليل.\n\n");

        int matchedCount = 0;
        StringBuilder matchedDetails = new StringBuilder();
        for (NoteItem item : itemsList) {
            if ((item.title != null && item.title.toLowerCase().contains(q)) || 
                (item.content != null && item.content.toLowerCase().contains(q))) {
                matchedCount++;
                matchedDetails.append("• **العنوان:** ").append(item.title).append(" (النوع: ").append(item.itemType).append(")\n");
                if (item.content != null && item.content.length() > 0) {
                    String snippet = item.content.length() > 90 ? item.content.substring(0, 90) + "..." : item.content;
                    matchedDetails.append("  *مقتطف محتوى:* ").append(snippet).append("\n");
                }
            }
        }

        if (matchedCount > 0) {
            analysis.append("3️⃣ **النتائج المطابقة في مستنداتك:** تم العثور على ارتباطات مباشرة في ").append(matchedCount).append(" ملفاً:\n");
            analysis.append(matchedDetails.toString());
        } else {
            analysis.append("3️⃣ **التدقيق التحليلي:** لم يتم العثور على مطابقة حرفية مباشرة في العناوين الحالية، لكن السياق يشير إلى مفاهيم بحثية عامة متصلة بأرشفة النصوص ومراجع القراءة.\n");
        }

        analysis.append("\n4️⃣ **التوصية الأكاديمية والاستنتاج النهائي:**\n");
        if (q.contains("مرحبا") || q.contains("السلام") || q.contains("أهلاً")) {
            analysis.append("وعليكم السلام ورحمة الله وبركاته يا باحثنا Yahya! نظام التحليل المحلي جاهز تماماً لدعمك وتدقيق ملفاتك ومخطوطاتك.");
        } else if (q.contains("نبيه") || q.contains("أنبياء") || q.contains("نبي")) {
            analysis.append("بناءً على المخطوطات والتحليل النصي المتاح في التطبيق: عدد الأنبياء الحقيقي وأسماؤهم جميعًا غير محصور بشكل قاطع في الرقم 25، بل هناك تفصيل بين الصريح في القرآن وما ورد في الروايات والكتب التراثية.");
        } else if (q.contains("كتاب") || q.contains("مكتبة") || q.contains("مستند")) {
            analysis.append("مكتبتك تضم حالياً عددًا من الكتب والمخطوطات والملاحظات الشخصية. يُنصح بمراجعة نسبة الإنجاز لكل كتاب والاعتماد على ميزة 'الأسئلة الذكية' لتوليد اختبارات مراجعة فورية.");
        } else {
            analysis.append("هذا الاستفسار يخضع لمنهجية التحليل العميق؛ يمكنك ربط مفتاح Gemini أو ChatGPT السحابي عبر لوحة 'المفاتيح' في الشاشة للحصول على تحليل إضافي واسع النطاق.");
        }

        return analysis.toString();
    }

    private void showAIAssistantDialog() {
        final Dialog aiDialog = new Dialog(this, android.R.style.Theme_Material_Light_NoActionBar_Fullscreen);
        LinearLayout rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(OLED_BG_END);
        rootLayout.setPadding(24, 20, 24, 20);

        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(16, 12, 16, 12);
        topBar.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 24, 2));

        TextView aiTitle = new TextView(this);
        aiTitle.setText("🤖 Y-DALEEL - العقل الذكي والمحلل");
        aiTitle.setTextColor(TEXT_PRIMARY);
        aiTitle.setTextSize(15);
        aiTitle.setTypeface(currentTypeface, Typeface.BOLD);
        topBar.addView(aiTitle, new LinearLayout.LayoutParams(0, -2, 1.0f));

        Button btnApiKey = makeGlassButton("المفاتيح", Color.TRANSPARENT, 0, LILAC_SOFT, 11, 12);
        btnApiKey.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showApiKeyDialog(); }
        });
        topBar.addView(btnApiKey);

        Button btnClose = makeGlassButton("إغلاق", Color.TRANSPARENT, 0, TEXT_PRIMARY, 11, 12);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { aiDialog.dismiss(); }
        });
        topBar.addView(btnClose);
        rootLayout.addView(topBar);

        LinearLayout engineBar = new LinearLayout(this);
        engineBar.setOrientation(LinearLayout.HORIZONTAL);
        engineBar.setGravity(Gravity.CENTER);
        engineBar.setWeightSum(3.0f);
        engineBar.setPadding(0, 12, 0, 12);

        final int[] selectedEngine = {0};

        final Button btnLocal = makeButtonWithThickBorder("Y-DALEEL المحلي (تحليل عميق بدون نت)", 0xFF3B82F6, GLASS_BORDER, Color.WHITE, 11, 12, dp(38));
        final Button btnGemini = makeButtonWithThickBorder("Gemini AI", GLASS_CARD_BG, GLASS_BORDER, TEXT_MUTED, 11, 12, dp(38));
        final Button btnChatGpt = makeButtonWithThickBorder("ChatGPT", GLASS_CARD_BG, GLASS_BORDER, TEXT_MUTED, 11, 12, dp(38));

        LinearLayout.LayoutParams engLp = new LinearLayout.LayoutParams(0, -2, 1.0f);
        engLp.setMargins(4, 0, 4, 0);
        btnLocal.setLayoutParams(engLp);
        btnGemini.setLayoutParams(engLp);
        btnChatGpt.setLayoutParams(engLp);

        engineBar.addView(btnLocal);
        engineBar.addView(btnGemini);
        engineBar.addView(btnChatGpt);
        rootLayout.addView(engineBar);

        btnLocal.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                selectedEngine[0] = 0;
                btnLocal.setBackgroundColor(0xFF3B82F6); btnLocal.setTextColor(Color.WHITE);
                btnGemini.setBackgroundColor(GLASS_CARD_BG); btnGemini.setTextColor(TEXT_MUTED);
                btnChatGpt.setBackgroundColor(GLASS_CARD_BG); btnChatGpt.setTextColor(TEXT_MUTED);
                Toast.makeText(MainActivity.this, "تم تفعيل محرك التحليل العميق المحلي", Toast.LENGTH_SHORT).show();
            }
        });

        btnGemini.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                selectedEngine[0] = 1;
                btnGemini.setBackgroundColor(0xFF3B82F6); btnGemini.setTextColor(Color.WHITE);
                btnLocal.setBackgroundColor(GLASS_CARD_BG); btnLocal.setTextColor(TEXT_MUTED);
                btnChatGpt.setBackgroundColor(GLASS_CARD_BG); btnChatGpt.setTextColor(TEXT_MUTED);
                Toast.makeText(MainActivity.this, "تم التفعيل على سحابة Gemini AI", Toast.LENGTH_SHORT).show();
            }
        });

        btnChatGpt.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                selectedEngine[0] = 2;
                btnChatGpt.setBackgroundColor(0xFF3B82F6); btnChatGpt.setTextColor(Color.WHITE);
                btnLocal.setBackgroundColor(GLASS_CARD_BG); btnLocal.setTextColor(TEXT_MUTED);
                btnGemini.setBackgroundColor(GLASS_CARD_BG); btnGemini.setTextColor(TEXT_MUTED);
                Toast.makeText(MainActivity.this, "تم التفعيل على سحابة ChatGPT", Toast.LENGTH_SHORT).show();
            }
        });

        final ScrollView chatScroll = new ScrollView(this);
        chatScroll.setVerticalScrollBarEnabled(false);
        final LinearLayout chatContainer = new LinearLayout(this);
        chatContainer.setOrientation(LinearLayout.VERTICAL);
        chatContainer.setPadding(12, 12, 12, 12);

        addAIChatBubble(chatContainer, "أهلاً بك يا باحثنا Yahya! أنا Y-DALEEL، مساعدك الذكي المزود بقدرات التحليل العميق للمستندات والمكتبة. اطرح سؤالك وسأقوم بدراسته وفحصه بدقة.", false);

        chatScroll.addView(chatContainer);
        rootLayout.addView(chatScroll, new LinearLayout.LayoutParams(-1, 0, 1.0f));

        LinearLayout inputBar = new LinearLayout(this);
        inputBar.setOrientation(LinearLayout.HORIZONTAL);
        inputBar.setGravity(Gravity.CENTER_VERTICAL);
        inputBar.setPadding(16, 12, 16, 12);
        inputBar.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 28, 2));

        final EditText questionInput = new EditText(this);
        questionInput.setHint("اكتب سؤالك أو تساؤلك للتحليل العميق...");
        questionInput.setHintTextColor(TEXT_MUTED);
        questionInput.setTextColor(TEXT_PRIMARY);
        questionInput.setTextSize(14);
        questionInput.setTypeface(currentTypeface);
        questionInput.setBackgroundColor(Color.TRANSPARENT);
        inputBar.addView(questionInput, new LinearLayout.LayoutParams(0, -2, 1.0f));

        Button btnSend = makeButtonWithThickBorder("إرسال", FAIENCE_GREEN, 0, Color.WHITE, 12, 16, dp(44));
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String query = questionInput.getText().toString().trim();
                if (!query.isEmpty()) {
                    addAIChatBubble(chatContainer, query, true);
                    questionInput.setText("");

                    SharedPreferences prefs = getSharedPreferences("DaleelUserProfile", MODE_PRIVATE);

                    final LinearLayout loadingBubble = new LinearLayout(MainActivity.this);
                    loadingBubble.setOrientation(LinearLayout.VERTICAL);
                    loadingBubble.setPadding(20, 16, 20, 16);
                    GradientDrawable loadBg = new GradientDrawable();
                    loadBg.setColor(GLASS_CARD_BG);
                    loadBg.setCornerRadius(20f);
                    loadBg.setStroke(2, GLASS_BORDER);
                    loadingBubble.setBackground(loadBg);
                    LinearLayout.LayoutParams loadLp = new LinearLayout.LayoutParams(-1, -2);
                    loadLp.setMargins(0, 8, 0, 8);
                    loadingBubble.setLayoutParams(loadLp);

                    final TextView loadTv = new TextView(MainActivity.this);
                    loadTv.setTextColor(LILAC_SOFT);
                    loadTv.setTextSize(13);
                    loadingBubble.addView(loadTv);
                    chatContainer.addView(loadingBubble);

                    chatScroll.post(new Runnable() {
                        @Override public void run() { chatScroll.fullScroll(View.FOCUS_DOWN); }
                    });

                    if (selectedEngine[0] == 0) {
                        loadTv.setText("🔬 Y-DALEEL يقوم بالمسح والتحليل العميق محلياً...");
                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                chatContainer.removeView(loadingBubble);
                                String localReply = generateLocalAiResponse(query);
                                addAIChatBubble(chatContainer, localReply, false);
                                chatScroll.post(new Runnable() {
                                    @Override public void run() { chatScroll.fullScroll(View.FOCUS_DOWN); }
                                });
                            }
                        }, 800);
                        return;
                    }

                    loadTv.setText(selectedEngine[0] == 1 ? "🤖 Y-DALEEL يعالج الإجابة عبر Gemini AI..." : "🤖 Y-DALEEL يعالج الإجابة عبر ChatGPT...");

                    if (selectedEngine[0] == 1) {
                        final String apiKey = prefs.getString("gemini_api_key", "");
                        if (apiKey.isEmpty()) {
                            chatContainer.removeView(loadingBubble);
                            addAIChatBubble(chatContainer, "⚠️ تنبيه: يرجى إدخال مفتاح Gemini API عبر زر 'المفاتيح' بالأعلى.", false);
                            return;
                        }

                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + apiKey);
                                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                                    conn.setRequestMethod("POST");
                                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                                    conn.setDoOutput(true);

                                    JSONObject jsonBody = new JSONObject();
                                    JSONArray contentsArr = new JSONArray();
                                    JSONObject contentObj = new JSONObject();
                                    JSONArray partsArr = new JSONArray();
                                    JSONObject partObj = new JSONObject();
                                    partObj.put("text", "أنت Y-DALEEL، مساعد ذكاء اصطناعي أكاديمي ذو تفكر عميق ومحلل. أجب عن التالي بدقة واحرافية: " + query);
                                    partsArr.put(partObj);
                                    contentObj.put("parts", partsArr);
                                    contentsArr.put(contentObj);
                                    jsonBody.put("contents", contentsArr);

                                    OutputStream os = conn.getOutputStream();
                                    os.write(jsonBody.toString().getBytes("UTF-8"));
                                    os.close();

                                    int responseCode = conn.getResponseCode();
                                    if (responseCode == 200) {
                                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                                        StringBuilder responseStr = new StringBuilder();
                                        String line;
                                        while ((line = br.readLine()) != null) responseStr.append(line);
                                        br.close();

                                        JSONObject respJson = new JSONObject(responseStr.toString());
                                        String answerText = respJson.getJSONArray("candidates")
                                                .getJSONObject(0)
                                                .getJSONObject("content")
                                                .getJSONArray("parts")
                                                .getJSONObject(0)
                                                .getString("text");

                                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                                            @Override
                                            public void run() {
                                                chatContainer.removeView(loadingBubble);
                                                addAIChatBubble(chatContainer, answerText, false);
                                                chatScroll.post(new Runnable() {
                                                    @Override public void run() { chatScroll.fullScroll(View.FOCUS_DOWN); }
                                                });
                                            }
                                        });
                                    } else {
                                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                                            @Override
                                            public void run() {
                                                chatContainer.removeView(loadingBubble);
                                                addAIChatBubble(chatContainer, "❌ خطأ في الاتصال بـ Gemini (رمز الخطأ: " + responseCode + ")", false);
                                            }
                                        });
                                    }
                                } catch (Exception e) {
                                    final String errMsg = e.getMessage();
                                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                                        @Override
                                        public void run() {
                                            chatContainer.removeView(loadingBubble);
                                            addAIChatBubble(chatContainer, "❌ حدث خطأ: " + errMsg, false);
                                        }
                                    });
                                }
                            }
                        }).start();
                    } else if (selectedEngine[0] == 2) {
                        final String openAiKey = prefs.getString("openai_api_key", "");
                        if (openAiKey.isEmpty()) {
                            chatContainer.removeView(loadingBubble);
                            addAIChatBubble(chatContainer, "⚠️ تنبيه: يرجى إدخال مفتاح OpenAI API (ChatGPT) عبر زر 'المفاتيح' بالأعلى.", false);
                            return;
                        }

                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    URL url = new URL("https://api.openai.com/v1/chat/completions");
                                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                                    conn.setRequestMethod("POST");
                                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                                    conn.setRequestProperty("Authorization", "Bearer " + openAiKey);
                                    conn.setDoOutput(true);

                                    JSONObject jsonBody = new JSONObject();
                                    jsonBody.put("model", "gpt-3.5-turbo");
                                    JSONArray messagesArr = new JSONArray();
                                    JSONObject sysObj = new JSONObject();
                                    sysObj.put("role", "system");
                                    sysObj.put("content", "أنت Y-DALEEL، مساعد ذكاء اصطناعي أكاديمي ذو قدرات تحليلية وتفكير عميق.");
                                    messagesArr.put(sysObj);

                                    JSONObject msgObj = new JSONObject();
                                    msgObj.put("role", "user");
                                    msgObj.put("content", query);
                                    messagesArr.put(msgObj);
                                    jsonBody.put("messages", messagesArr);

                                    OutputStream os = conn.getOutputStream();
                                    os.write(jsonBody.toString().getBytes("UTF-8"));
                                    os.close();

                                    int responseCode = conn.getResponseCode();
                                    if (responseCode == 200) {
                                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                                        StringBuilder responseStr = new StringBuilder();
                                        String line;
                                        while ((line = br.readLine()) != null) responseStr.append(line);
                                        br.close();

                                        JSONObject respJson = new JSONObject(responseStr.toString());
                                        String answerText = respJson.getJSONArray("choices")
                                                .getJSONObject(0)
                                                .getJSONObject("message")
                                                .getString("content");

                                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                                            @Override
                                            public void run() {
                                                chatContainer.removeView(loadingBubble);
                                                addAIChatBubble(chatContainer, answerText, false);
                                                chatScroll.post(new Runnable() {
                                                    @Override public void run() { chatScroll.fullScroll(View.FOCUS_DOWN); }
                                                });
                                            }
                                        });
                                    } else {
                                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                                            @Override
                                            public void run() {
                                                chatContainer.removeView(loadingBubble);
                                                addAIChatBubble(chatContainer, "❌ خطأ في الاتصال بـ ChatGPT (رمز الخطأ: " + responseCode + ")", false);
                                            }
                                        });
                                    }
                                } catch (Exception e) {
                                    final String errMsg = e.getMessage();
                                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                                        @Override
                                        public void run() {
                                            chatContainer.removeView(loadingBubble);
                                            addAIChatBubble(chatContainer, "❌ حدث خطأ: " + errMsg, false);
                                        }
                                    });
                                }
                            }
                        }).start();
                    }
                }
            }
        });
        inputBar.addView(btnSend);
        rootLayout.addView(inputBar);

        aiDialog.setContentView(rootLayout);
        aiDialog.show();
    }

    private void addAIChatBubble(LinearLayout container, String message, boolean isUser) {
        LinearLayout bubble = new LinearLayout(this);
        bubble.setOrientation(LinearLayout.VERTICAL);
        bubble.setPadding(20, 16, 20, 16);
        
        GradientDrawable bg = new GradientDrawable();
        if (isUser) {
            bg.setColor(0x443B82F6);
            bg.setCornerRadius(20f);
            bg.setStroke(2, NEON_BLUE);
        } else {
            bg.setColor(GLASS_CARD_BG);
            bg.setCornerRadius(20f);
            bg.setStroke(2, GLASS_BORDER);
        }
        bubble.setBackground(bg);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 8, 0, 8);
        bubble.setLayoutParams(lp);

        TextView sender = new TextView(this);
        sender.setText(isUser ? "أنت (الباحث):" : "🤖 Y-DALEEL (المساعد المحلل):");
        sender.setTextColor(isUser ? LILAC_SOFT : FAIENCE_GREEN);
        sender.setTextSize(11);
        sender.setTypeface(currentTypeface, Typeface.BOLD);
        bubble.addView(sender);

        TextView msgTv = new TextView(this);
        msgTv.setText(message);
        msgTv.setTextColor(TEXT_PRIMARY);
        msgTv.setTextSize(14);
        msgTv.setTypeface(currentTypeface);
        msgTv.setPadding(0, 4, 0, 0);
        bubble.addView(msgTv);

        container.addView(bubble);
    }

    private void buildLocalizationStrings() {
        localizedStrings.put("ar", new String[]{
                "دليل - Daleel", "ابحث في ملفاتك وكتبك أو اسألها...", "الكل", "الكتب", "المحفوظات",
                "إضافة محتوى جديد", "إضافة ملف", "ملاحظة جديدة", "إضافة كتاب", "إضافة رابط",
                "الترجمة الفورية", "اللغة (العربية)", "أهلاً بك في تطبيق دليل",
                "ابدأ بقراءة الكتب والمخطوطات أدناه أو اختر كتاباً لتتابع رحلتك المعرفية.",
                "كمل من وين وقفت"
        });
        localizedStrings.put("en", new String[]{
                "Daleel", "Search files & books...", "All", "Books", "Saved",
                "Add New Content", "Add File", "New Note", "Add Book", "Add Link",
                "Instant Translation", "Language (English)", "Welcome to Daleel",
                "Start reading books below or select one to continue your journey.",
                "Continue Reading"
        });
    }

    private String L(String key) {
        int idx = 0;
        if (key.equals("search_hint")) idx = 1;
        else if (key.equals("tab_all")) idx = 2;
        else if (key.equals("tab_books")) idx = 3;
        else if (key.equals("tab_saved")) idx = 4;
        else if (key.equals("add_content_title")) idx = 5;
        else if (key.equals("add_file")) idx = 6;
        else if (key.equals("add_note")) idx = 7;
        else if (key.equals("add_book")) idx = 8;
        else if (key.equals("add_link")) idx = 9;
        else if (key.equals("translation_title")) idx = 10;
        else if (key.equals("language_row")) idx = 11;
        else if (key.equals("welcome_title")) idx = 12;
        else if (key.equals("welcome_desc")) idx = 13;
        else if (key.equals("resume_title")) idx = 14;

        String[] set = localizedStrings.get(currentAppLanguage);
        if (set != null && idx < set.length) return set[idx];
        return key;
    }

    private void buildRichOfflineDictionary() {
        String[] arWords = {
                "مرحبا", "كتاب", "مستند", "تاريخ", "علم", "جامعة", "طالب", "مكتبة", "صفحة", "فصل",
                "ملاحظة", "امتحان", "استثمار", "تقنية", "برمجة", "تطبيق", "ذكاء", "اصطناعي", "صيانة",
                "بيانات", "اتصال", "شبكة", "سحابة", "تخزين", "حماية", "خصوصية", "إعدادات", "لغة", "ترجمة",
                "قراءة", "سلسلة", "هدف", "يوم", "شهر", "سنة", "تفاصيل", "رابط", "صورة", "ملف", "مخطوط",
                "منزل", "سيارة", "طريق", "عمل", "شركة", "مشروع", "سؤال", "جواب", "فكرة", "دليل", "بحث"
        };
        String[] enWords = {
                "hello", "book", "document", "history", "science", "university", "student", "library", "page", "chapter",
                "note", "exam", "investment", "technology", "programming", "application", "intelligence", "artificial", "maintenance",
                "data", "connection", "network", "cloud", "storage", "security", "privacy", "settings", "language", "translation",
                "reading", "streak", "goal", "day", "month", "year", "details", "link", "image", "file", "manuscript",
                "home", "car", "road", "work", "company", "project", "question", "answer", "idea", "guide", "research"
        };

        for (int i = 0; i < arWords.length; i++) {
            offlineDictArToEn.put(arWords[i], enWords[i]);
            offlineDictEnToAr.put(enWords[i], arWords[i]);
        }

        String[] arPhrases = {
                "كيف حالك", "صباح الخير", "مساء الخير", "شكرا جزيلا", "من فضلك ساعدني",
                "ما اسمك", "أين المكتبة", "أريد قراءة كتاب", "مرحباً بك يا صديقي", "حظاً سعيداً",
                "كيف يمكنني مساعدتك", "إلى اللقاء", "أتمنى لك يوم سعيد", "ما هذا الملف", "جارٍ التحميل"
        };
        String[] enPhrases = {
                "how are you", "good morning", "good evening", "thank you very much", "please help me",
                "what is your name", "where is the library", "i want to read a book", "welcome my friend", "good luck",
                "how can i help you", "goodbye", "have a nice day", "what is this file", "loading"
        };

        for (int i = 0; i < arPhrases.length; i++) {
            offlineDictArToEn.put(arPhrases[i], enPhrases[i]);
            offlineDictEnToAr.put(enPhrases[i], arPhrases[i]);
        }
    }

    private void showLanguageDialog() {
        final CharSequence[] langs = {"العربية (Arabic)", "English (الإنجليزية)"};
        new AlertDialog.Builder(this)
                .setTitle("اختر لغة التطبيق / Select Language")
                .setItems(langs, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String lang = (which == 0) ? "ar" : "en";
                        getSharedPreferences("DaleelUserProfile", MODE_PRIVATE)
                                .edit().putString("app_language", lang).apply();
                        currentAppLanguage = lang;
                        recreate();
                    }
                })
                .show();
    }

    private void showTranslationDialog(String initialText) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 36, 36, 36);
        layout.setBackgroundColor(OLED_BG_END);

        TextView title = new TextView(this);
        title.setText("الترجمة الفورية والقاموس المحلي الموسع");
        title.setTextColor(TEXT_PRIMARY);
        title.setTextSize(17);
        title.setTypeface(currentTypeface, Typeface.BOLD);
        title.setPadding(0, 0, 0, 16);
        layout.addView(title);

        final EditText input = new EditText(this);
        input.setHint("اكتب الكلمة أو العبارة للترجمة...");
        if (initialText != null && !initialText.isEmpty()) {
            input.setText(initialText);
        }
        input.setTextColor(TEXT_PRIMARY);
        input.setHintTextColor(TEXT_MUTED);
        input.setBackground(makeGlassDrawable(GLASS_CARD_BG, GLASS_BORDER, 20, 2));
        input.setPadding(24, 18, 24, 18);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, 16);
        input.setLayoutParams(lp);
        layout.addView(input);

        final TextView resultTv = new TextView(this);
        resultTv.setText("النتيجة ستظهر هنا فوراً...");
        resultTv.setTextColor(LILAC_SOFT);
        resultTv.setTextSize(14);
        resultTv.setPadding(0, 10, 0, 16);
        layout.addView(resultTv);

        Button btnTranslateOffline = makeButtonWithThickBorder("بحث بالقاموس المحلي الموسع (بدون إنترنت)", 0x443B82F6, GLASS_BORDER, Color.WHITE, 13, 16, dp(48));
        Button btnTranslateOnline = makeButtonWithThickBorder("ترجمة سحابية عبر الإنترنت", 0xEE3B82F6, 0, Color.WHITE, 13, 16, dp(48));
        
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, -2);
        btnLp.setMargins(0, 8, 0, 8);
        btnTranslateOffline.setLayoutParams(btnLp);
        btnTranslateOnline.setLayoutParams(btnLp);

        layout.addView(btnTranslateOffline);
        layout.addView(btnTranslateOnline);

        final AlertDialog transDialog = new AlertDialog.Builder(this)
                .setView(layout)
                .setNegativeButton("إغلاق", null)
                .create();

        btnTranslateOffline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = input.getText().toString().trim().toLowerCase();
                if (text.isEmpty()) return;
                if (offlineDictArToEn.containsKey(text)) {
                    resultTv.setText("الترجمة المحلية: " + offlineDictArToEn.get(text));
                } else if (offlineDictEnToAr.containsKey(text)) {
                    resultTv.setText("الترجمة المحلية: " + offlineDictEnToAr.get(text));
                } else {
                    resultTv.setText("عذراً، العبارة أو الكلمة غير موجودة في القاموس المحلي الموسع.");
                }
            }
        });

        btnTranslateOnline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String text = input.getText().toString().trim();
                if (text.isEmpty()) return;
                resultTv.setText("جاري الترجمة عبر السحابة...");

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            String urlStr = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=" + URLEncoder.encode(text, "UTF-8");
                            URL url = new URL(urlStr);
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            conn.setRequestMethod("GET");
                            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                            StringBuilder sb = new StringBuilder();
                            String line;
                            while ((line = reader.readLine()) != null) sb.append(line);
                            reader.close();

                            JSONArray jsonArray = new JSONArray(sb.toString());
                            String translated = jsonArray.getJSONArray(0).getJSONArray(0).getString(0);

                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    resultTv.setText("الترجمة عبر السحابة: " + translated);
                                }
                            });
                        } catch (Exception e) {
                            new Handler(Looper.getMainLooper()).post(new Runnable() {
                                @Override
                                public void run() {
                                    resultTv.setText("فشلت الترجمة عبر الإنترنت، تأكد من الاتصال.");
                                }
                            });
                        }
                    }
                }).start();
            }
        });

        transDialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == VOICE_RECOGNITION_REQUEST_CODE) {
                ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (results != null && !results.isEmpty()) {
                    String spokenText = results.get(0);
                    if (searchBox != null) {
                        searchBox.setText(spokenText);
                        searchBox.setSelection(spokenText.length());
                    }
                }
                return;
            }

            if (requestCode == PICK_NOTE_IMAGE_REQUEST && activeNoteForImage != null) {
                Uri imageUri = data.getData();
                if (imageUri != null) {
                    try {
                        getContentResolver().takePersistableUriPermission(imageUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } catch (Exception ignored) {}
                    activeNoteForImage.attachedImages.add(imageUri.toString());
                    Toast.makeText(this, "تم إرفاق الصورة الحقيقية بالملاحظة بنجاح", Toast.LENGTH_SHORT).show();
                }
                activeNoteForImage = null;
                return;
            }

            if (data.getData() != null) {
                Uri uri = data.getData();
                try {
                    getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}

                if (requestCode == PICK_PDF_DOCUMENT_REQUEST) {
                    String fileName = "مستند PDF";
                    try {
                        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
                        if (cursor != null && cursor.moveToFirst()) {
                            int nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                            if (nameIndex != -1) fileName = cursor.getString(nameIndex);
                            cursor.close();
                        }
                    } catch (Exception ignored) {}

                    fileName = normalizePdfFileName(fileName);
                    NoteItem newPdfItem = new NoteItem(
                            fileName,
                            "محتوى مستند PDF المرفق حديثاً.",
                            getDate(),
                            "ملف"
                    );
                    newPdfItem.subtitle = "الجزء الأول";
                    newPdfItem.category = "مستندات PDF";
                    newPdfItem.pdfUri = uri.toString();
                    newPdfItem.isSaved = true;
                    newPdfItem.isSyncedToCloud = true;
                    newPdfItem.progressPercent = 0;
                    newPdfItem.fileSizeInfo = "4.5 م.ب";
                    newPdfItem.fileTypeInfo = "ملف PDF";

                    itemsList.add(0, newPdfItem);
                    saveNotesLocally();
                    filterData("");
                    setupMainUI();
                    Toast.makeText(this, "تم إرفاق الملف وربطه بالسحابة بنجاح", Toast.LENGTH_LONG).show();
                } else if (requestCode == PICK_COVER_IMAGE_REQUEST && activeTargetItemForCover != null) {
                    activeTargetItemForCover.coverImageUri = uri.toString();
                    saveNotesLocally();
                    filterData("");
                    setupMainUI();
                    Toast.makeText(this, "تم تحديث غلاف البطاقة بنجاح", Toast.LENGTH_SHORT).show();
                    activeTargetItemForCover = null;
                } else if (requestCode == PICK_CHAT_IMAGE_REQUEST) {
                    sendLocalChatImage(uri);
                } else if (requestCode == PICK_PROFILE_IMAGE_REQUEST) {
                    getSharedPreferences("DaleelUserProfile", MODE_PRIVATE)
                            .edit().putString("user_profile_avatar", uri.toString()).apply();
                    setupMainUI();
                    Toast.makeText(this, "تم تحديث صورة الملف الشخصي بنجاح", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private Button makeButtonWithThickBorder(String text, int bgColor, int borderColor, int txtColor, int textSize, int radius, int minHeight) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(txtColor);
        b.setTextSize(textSize);
        b.setTypeface(currentTypeface, Typeface.BOLD);
        b.setPadding(16, 12, 16, 16);
        b.setGravity(Gravity.CENTER);
        b.setMinimumHeight(Math.max(dp(48), minHeight));

        GradientDrawable base = new GradientDrawable();
        base.setColor(bgColor);
        base.setCornerRadius(radius);
        if (borderColor != 0) {
            base.setStroke(4, borderColor);
        } else {
            base.setStroke(2, 0x44FFFFFF);
        }

        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), base, base));
        b.setElevation(6f);

        b.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, android.view.MotionEvent event) {
                if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    v.animate().translationY(4f).scaleX(0.98f).scaleY(0.98f).setDuration(80).start();
                } else if (event.getAction() == android.view.MotionEvent.ACTION_UP || event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
                    v.animate().translationY(0f).scaleX(1f).scaleY(1f).setDuration(120).start();
                }
                return false;
            }
        });

        return b;
    }

    private Button makeGlassButton(String text, int bgColor, int borderColor, int txtColor, int textSize, int radius) {
        return makeButtonWithThickBorder(text, bgColor, borderColor, txtColor, textSize, radius, dp(44));
    }

    private GradientDrawable makeGlassDrawable(int bgColor, int bColor, int radius, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(bgColor);
        d.setCornerRadius(radius);
        if (bColor != 0) d.setStroke(strokeWidth, bColor);
        return d;
    }

    private String normalizePdfFileName(String name) {
        if (name == null || name.trim().isEmpty()) return "مستند PDF";
        String clean = name.trim().replaceAll("[\\/:*?\"<>|]", "_");
        if (!clean.toLowerCase(Locale.US).endsWith(".pdf")) clean += ".pdf";
        return clean;
    }
    private void handleAdminTitleTap(View v) {
        long now = System.currentTimeMillis();
        if (now - lastAdminTapAt > 1800) adminTapCount = 0;
        lastAdminTapAt = now;
        adminTapCount++;
        if (adminTapCount >= 5) {
            adminTapCount = 0;
            showAdminLoginOrDashboard();
        }
    }

    private void filterData(String query) {
        filteredList.clear();
        String q = query != null ? query.toLowerCase().trim() : "";
        for (NoteItem item : itemsList) {
            boolean matchesTab = true;
            if (currentFilterTab.equals("الكتب")) matchesTab = (item.category != null && item.category.equals("المكتبة"));
            else if (currentFilterTab.equals("المحفوظات")) matchesTab = item.isSaved;

            if (matchesTab && (q.isEmpty() || (item.title != null && item.title.toLowerCase().contains(q)) || (item.content != null && item.content.toLowerCase().contains(q)) || pdfTextContains(item, q))) {
                filteredList.add(item);
            }
        }
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void saveNotesLocally() {
        try {
            StringBuilder sb = new StringBuilder();
            for (NoteItem item : itemsList) {
                sb.append(item.title).append("|||")
                  .append(item.content).append("|||")
                  .append(item.dateAdded).append("|||")
                  .append(item.pdfUri != null ? item.pdfUri : "").append("|||")
                  .append(item.isSaved ? "1" : "0").append("|||")
                  .append(item.itemType).append("|||")
                  .append(item.progressPercent).append("|||")
                  .append(item.coverImageUri != null ? item.coverImageUri : "").append("|||")
                  .append(item.lastOpened).append("|||")
                  .append(item.lastPage).append("|||")
                  .append(item.isSyncedToCloud ? "1" : "0").append("|||")
                  .append(item.lastScrollY).append("|||")
                  .append(item.readerNotes.size());
                for (String rn : item.readerNotes) {
                    sb.append("###").append(rn);
                }
                sb.append("\n---\n");
            }
            FileOutputStream fos = openFileOutput(STORAGE_FILE, Context.MODE_PRIVATE);
            fos.write(sb.toString().getBytes("UTF-8"));
            fos.close();
        } catch (Exception ignored) {}
    }

    private void loadNotesLocally() {
        try {
            File f = new File(getFilesDir(), STORAGE_FILE);
            if (f.exists()) {
                FileInputStream fis = openFileInput(STORAGE_FILE);
                byte[] buf = new byte[(int) fis.available()];
                fis.read(buf);
                fis.close();
                String[] notes = new String(buf, "UTF-8").split("\n---\n");
                for (String n : notes) {
                    String[] p = n.split("\\|\\|\\|");
                    if (p.length >= 3) {
                        String type = (p.length >= 6 && !p[5].isEmpty()) ? p[5] : "ملف";
                        NoteItem item = new NoteItem(p[0], p[1], p[2], type);
                        if (p.length >= 4 && !p[3].isEmpty()) item.pdfUri = p[3];
                        if (p.length >= 5) item.isSaved = p[4].equals("1");
                        if (p.length >= 7) {
                            try { item.progressPercent = Integer.parseInt(p[6]); } catch (Exception ignored) {}
                        }
                        if (p.length >= 8 && !p[7].isEmpty()) item.coverImageUri = p[7];
                        if (p.length >= 9 && !p[8].isEmpty()) {
                            try { item.lastOpened = Long.parseLong(p[8]); } catch (Exception ignored) {}
                        }
                        if (p.length >= 10 && !p[9].isEmpty()) {
                            try { item.lastPage = Integer.parseInt(p[9]); } catch (Exception ignored) {}
                        }
                        if (p.length >= 11) {
                            item.isSyncedToCloud = p[10].equals("1");
                        }
                        if (p.length >= 12 && !p[11].isEmpty()) {
                            try { item.lastScrollY = Integer.parseInt(p[11]); } catch (Exception ignored) {}
                        }
                        int notesIndex = p.length >= 13 ? 12 : 11;
                        if (p.length > notesIndex) {
                            String[] rNotesParts = p[notesIndex].split("###");
                            if (rNotesParts.length > 1) {
                                item.readerNotes.clear();
                                for (int i = 1; i < rNotesParts.length; i++) {
                                    item.readerNotes.add(rNotesParts[i]);
                                }
                            }
                        }

                        itemsList.add(item);
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private String getDate() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }

    private void openDrawer() {
        if (drawerPanel != null) {
            drawerPanel.setVisibility(View.VISIBLE);
            drawerPanel.animate().translationX(0).setDuration(200).start();
            if (overlayView != null) overlayView.setVisibility(View.VISIBLE);
        }
    }

    private void closeDrawer() {
        if (drawerPanel != null) {
            drawerPanel.animate().translationX(-800f).setDuration(200).withEndAction(new Runnable() {
                @Override public void run() { drawerPanel.setVisibility(View.GONE); if (overlayView != null) overlayView.setVisibility(View.GONE); }
            }).start();
        }
    }

    private void enableImmersiveMode() {
        try {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN);
        } catch (Exception ignored) {}
    }

    public static class NoteItem {
        public String title;
        public String subtitle = "";
        public String content;
        public String dateAdded;
        public String itemType;
        public String pdfUri = "";
        public String coverImageUri = "";
        public boolean isSaved = false;
        public boolean isPinned = false;
        public boolean isSyncedToCloud = false;
        public int progressPercent = 0;
        public int pageCount = 1;
        public String fileSizeInfo = "1.2 م.ب";
        public String fileTypeInfo = "مستند";
        public long lastOpened = 0;
        public int lastPage = 0;
        public int lastScrollY = 0;
        public String category = "المكتبة";
        public int paperColor = 0xFF000000;
        public String tag = "";
        public String linkedBook = "";
        public ArrayList<String> readerNotes = new ArrayList<String>();
        public ArrayList<String> attachedImages = new ArrayList<String>();
        public ArrayList<String> recordedAudios = new ArrayList<String>();
        public boolean hasAudio = false;

        public NoteItem(String title, String content, String dateAdded, String itemType) {
            this.title = title;
            this.content = content;
            this.dateAdded = dateAdded;
            this.itemType = itemType;
        }
    }

    public static class ZoomablePdfView extends ImageView {
        private Matrix matrix = new Matrix();
        private float scale = 1f;
        private ScaleGestureDetector mScaleDetector;
        private float lastTouchX, lastTouchY;
        private int activePointerId = -1;
        private static final int INVALID_POINTER_ID = -1;
        
        private float mLastTouchX, mLastTouchY;
        private float mPosX, mPosY;

        private OnTouchSideListener sideListener;

        // Explicitly declared as public static to keep the nested type contract unambiguous
        // for javac/desugaring/D8. Interfaces are implicitly public static, but spelling it
        // out makes the generated nest-member relationship easier to inspect.
        public static interface OnTouchSideListener {
            void onTouchSide(boolean isRight);
        }

        public void setOnTouchSideListener(OnTouchSideListener listener) {
            this.sideListener = listener;
        }

        public ZoomablePdfView(Context context) {
            super(context);
            setScaleType(ScaleType.FIT_CENTER);
            mScaleDetector = new ScaleGestureDetector(context, new ScaleListener());
        }

        private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                scale *= detector.getScaleFactor();
                scale = Math.max(1f, Math.min(scale, 5.0f));
                matrix.setScale(scale, scale, detector.getFocusX(), detector.getFocusY());
                setImageMatrix(matrix);
                invalidate();
                return true;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            mScaleDetector.onTouchEvent(ev);
            final int action = ev.getActionMasked();

            switch (action) {
                case MotionEvent.ACTION_DOWN: {
                    final int pointerIndex = ev.getActionIndex();
                    mLastTouchX = ev.getX(pointerIndex);
                    mLastTouchY = ev.getY(pointerIndex);
                    activePointerId = ev.getPointerId(0);
                    lastTouchX = mLastTouchX;
                    lastTouchY = mLastTouchY;
                    break;
                }
                case MotionEvent.ACTION_MOVE: {
                    final int pointerIndex = ev.findPointerIndex(activePointerId);
                    if (pointerIndex >= 0 && scale > 1f) {
                        final float x = ev.getX(pointerIndex);
                        final float y = ev.getY(pointerIndex);
                        final float dx = x - mLastTouchX;
                        final float dy = y - mLastTouchY;

                        mPosX += dx;
                        mPosY += dy;
                        matrix.postTranslate(dx, dy);
                        setImageMatrix(matrix);

                        mLastTouchX = x;
                        mLastTouchY = y;
                    }
                    break;
                }
                case MotionEvent.ACTION_UP: {
                    activePointerId = INVALID_POINTER_ID;
                    if (scale <= 1.05f) {
                        float endX = ev.getX();
                        long duration = ev.getEventTime() - ev.getDownTime();
                        if (Math.abs(endX - lastTouchX) < 30 && duration < 400) {
                            int viewWidth = getWidth();
                            if (lastTouchX > viewWidth * 0.65f) {
                                if (sideListener != null) sideListener.onTouchSide(true);
                            } else if (lastTouchX < viewWidth * 0.35f) {
                                if (sideListener != null) sideListener.onTouchSide(false);
                            }
                        }
                    }
                    break;
                }
                case MotionEvent.ACTION_CANCEL: {
                    activePointerId = INVALID_POINTER_ID;
                    break;
                }
                case MotionEvent.ACTION_POINTER_UP: {
                    final int pointerIndex = ev.getActionIndex();
                    final int pointerId = ev.getPointerId(pointerIndex);
                    if (pointerId == activePointerId) {
                        if (ev.getPointerCount() <= 1) {
                            activePointerId = INVALID_POINTER_ID;
                            break;
                        }
                        final int newPointerIndex = pointerIndex == 0 ? 1 : 0;
                        mLastTouchX = ev.getX(newPointerIndex);
                        mLastTouchY = ev.getY(newPointerIndex);
                        activePointerId = ev.getPointerId(newPointerIndex);
                    }
                    break;
                }
            }
            return true;
        }
    }

    public static class GoogleMicIconView extends View {
        private Paint paint;
        public GoogleMicIconView(Context context) {
            super(context);
            paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            float cx = w / 2f;
            float cy = h * 0.38f;

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            float radiusW = w * 0.16f;
            float radiusH = h * 0.24f;
            RectF capsuleRect = new RectF(cx - radiusW, cy - radiusH, cx + radiusW, cy + radiusH);
            canvas.drawRoundRect(capsuleRect, radiusW, radiusW, paint);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(3.5f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            RectF arcRect = new RectF(cx - w * 0.32f, cy - h * 0.05f, cx + w * 0.32f, cy + h * 0.38f);
            canvas.drawArc(arcRect, 0, 180, false, paint);

            canvas.drawLine(cx, cy + h * 0.38f, cx, h * 0.76f, paint);
            canvas.drawLine(cx - w * 0.22f, h * 0.76f, cx + w * 0.22f, h * 0.76f, paint);
        }
    }

    public static class SunriseGaugeView extends View {
        private String progressText = "0";
        private String subText = "";
        private float animatedProgress = 0f;
        private Typeface typeface;
        private int trackColor, goldColor, textPrimary, textMuted;

        public SunriseGaugeView(Context context, Typeface tf, int track, int gold, int primary, int muted) {
            super(context);
            this.typeface = tf;
            this.trackColor = track;
            this.goldColor = gold;
            this.textPrimary = primary;
            this.textMuted = muted;
        }

        public void setLabels(String prog, String sub) {
            this.progressText = prog;
            this.subText = sub;
            invalidate();
        }

        public void setProgressImmediate(float p) {
            this.animatedProgress = p;
            invalidate();
        }

        public void animateTo(float p) {
            this.animatedProgress = p;
            invalidate();
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int w = MeasureSpec.getSize(widthMeasureSpec);
            setMeasuredDimension(w, (int)(w * 0.55f));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(28f);
            paint.setStrokeCap(Paint.Cap.ROUND);

            RectF rect = new RectF(40, 40, w - 40, h * 2 - 40);
            
            paint.setColor(trackColor);
            canvas.drawArc(rect, 180, 180, false, paint);

            paint.setColor(GOLD_COLOR);
            canvas.drawArc(rect, 180, 180 * animatedProgress, false, paint);

            Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            textPaint.setTextAlign(Paint.Align.CENTER);
            if (typeface != null) textPaint.setTypeface(typeface);

            textPaint.setTextSize(48f);
            textPaint.setColor(textPrimary);
            canvas.drawText(progressText, w / 2f, h * 0.6f, textPaint);

            textPaint.setTextSize(16f);
            textPaint.setColor(textMuted);
            canvas.drawText(subText, w / 2f, h * 0.8f, textPaint);
        }
    }

    @Override protected void onDestroy() {
        activityAlive = false;
        try { newsExecutor.shutdownNow(); pdfIndexExecutor.shutdownNow(); adminExecutor.shutdownNow(); } catch (Exception ignored) {}
        endReadingSession(activeReadingItem);
        super.onDestroy();
    }

    public static class FullGridView extends GridView {
        public FullGridView(Context context) {
            super(context);
        }
        public FullGridView(Context context, android.util.AttributeSet attrs) {
            super(context, attrs);
        }
        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int expandSpec = MeasureSpec.makeMeasureSpec(Integer.MAX_VALUE >> 2, MeasureSpec.AT_MOST);
            super.onMeasure(widthMeasureSpec, expandSpec);
        }
    }
}
&